package com.example.ui.screens

import android.annotation.SuppressLint
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.example.ui.KageViewModel
import com.example.ui.theme.*
import kotlinx.coroutines.delay

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import android.Manifest
import android.content.pm.PackageManager
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PlayerScreen(
    animeId: String,
    episodeIndex: Int,
    viewModel: KageViewModel,
    playOffline: Boolean = false,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val dbState by viewModel.databaseState.collectAsStateWithLifecycle()
    val watchLater by viewModel.watchLaterState.collectAsStateWithLifecycle()
    val downloads by viewModel.downloadsState.collectAsStateWithLifecycle()
    val profile by viewModel.profileState.collectAsStateWithLifecycle()

    val anime = dbState.anime.find { it.id == animeId }
    if (anime == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("Anime not found", color = KageWhite)
        }
        return
    }

    // Keep track of the active episode index inside a mutable state
    var currentEpisodeIndex by remember(episodeIndex) { mutableStateOf(episodeIndex) }
    val episode = anime.episodes.getOrNull(currentEpisodeIndex)

    if (episode == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("Episode not found", color = KageWhite)
        }
        return
    }

    var selectedServer by remember { mutableStateOf("Google Drive") }
    var selectedQuality by remember { mutableStateOf("720p") }

    // Resolve URL based on selection
    val activeUrl = remember(episode, selectedServer, selectedQuality) {
        if (selectedServer == "Google Drive") {
            episode.driveLinks?.get(selectedQuality)
                ?: episode.driveLinks?.get(selectedQuality.lowercase())
                ?: episode.driveLinks?.get(selectedQuality.uppercase())
                ?: episode.mp4
        } else {
            episode.serverLinks?.get("Dailymotion")
                ?: episode.serverLinks?.get("dailymotion")
                ?: "https://www.dailymotion.com/video/x7tg3f0"
        }
    }

    val completedDownload = remember(downloads, currentEpisodeIndex) {
        downloads.find {
            it.animeId == anime.id && it.episodeIndex == currentEpisodeIndex && it.status == "completed"
        }
    }
    var isPlayOfflineSelected by remember(playOffline, completedDownload, currentEpisodeIndex) {
        mutableStateOf(playOffline && completedDownload != null)
    }
    val isOfflineMode = isPlayOfflineSelected && completedDownload != null

    // Interactive Overlay States
    var isOverlayVisible by remember { mutableStateOf(true) }
    var isPlayingVideo by remember { mutableStateOf(true) }
    var currentPositionSec by remember { mutableLongStateOf(0L) }
    var totalDurationSec by remember { mutableLongStateOf(1430L) }
    var isMuted by remember { mutableStateOf(false) }
    var activeTab by remember { mutableStateOf("EPISODES") }
    var refreshKey by remember { mutableIntStateOf(0) }

    // Download state variables for quality selection dialog & permissions
    var showDownloadQualityDialog by remember { mutableStateOf(false) }
    var selectedDownloadEpisode by remember { mutableStateOf<com.example.data.Episode?>(null) }
    var selectedDownloadEpisodeIndex by remember { mutableStateOf(-1) }

    var pendingDownloadEpisode by remember { mutableStateOf<com.example.data.Episode?>(null) }
    var pendingDownloadEpisodeIndex by remember { mutableStateOf(-1) }
    var pendingDownloadQuality by remember { mutableStateOf("") }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        val ep = pendingDownloadEpisode
        if (isGranted && ep != null) {
            val url = ep.driveLinks?.get(pendingDownloadQuality)
                ?: ep.driveLinks?.get(pendingDownloadQuality.lowercase())
                ?: ep.driveLinks?.get(pendingDownloadQuality.uppercase())
                ?: ep.mp4
            viewModel.startDownload(
                id = "download_${anime.id}_ep_${ep.episode}",
                url = url,
                title = "${anime.title} - Episode ${ep.episode} (${pendingDownloadQuality})",
                fileType = "mp4",
                animeId = anime.id,
                episodeIndex = pendingDownloadEpisodeIndex
            )
            Toast.makeText(context, "Started download for Ep ${ep.episode} at ${pendingDownloadQuality}!", Toast.LENGTH_SHORT).show()
        } else if (ep != null) {
            Toast.makeText(context, "Storage permission is required to save downloads", Toast.LENGTH_LONG).show()
        }
        pendingDownloadEpisode = null
        pendingDownloadEpisodeIndex = -1
        pendingDownloadQuality = ""
    }

    val triggerDownloadWithPermission = { ep: com.example.data.Episode, idx: Int, q: String ->
        val hasPermission = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
            true
        } else {
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.WRITE_EXTERNAL_STORAGE
            ) == PackageManager.PERMISSION_GRANTED
        }

        if (hasPermission) {
            val url = ep.driveLinks?.get(q)
                ?: ep.driveLinks?.get(q.lowercase())
                ?: ep.driveLinks?.get(q.uppercase())
                ?: ep.mp4
            viewModel.startDownload(
                id = "download_${anime.id}_ep_${ep.episode}",
                url = url,
                title = "${anime.title} - Episode ${ep.episode} ($q)",
                fileType = "mp4",
                animeId = anime.id,
                episodeIndex = idx
            )
            Toast.makeText(context, "Started download for Ep ${ep.episode} at $q!", Toast.LENGTH_SHORT).show()
        } else {
            pendingDownloadEpisode = ep
            pendingDownloadEpisodeIndex = idx
            pendingDownloadQuality = q
            permissionLauncher.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        }
    }

    // Progress bar calculations
    val videoProgress = remember(currentPositionSec) {
        currentPositionSec.toFloat() / totalDurationSec.toFloat()
    }

    val currentPositionText = remember(currentPositionSec) {
        val m = currentPositionSec / 60
        val s = currentPositionSec % 60
        String.format("%02d:%02d", m, s)
    }

    val totalDurationText = remember(totalDurationSec) {
        val m = totalDurationSec / 60
        val s = totalDurationSec % 60
        String.format("%02d:%02d", m, s)
    }

    // Automatically hide overlay after 4 seconds of inactivity if playing
    LaunchedEffect(isOverlayVisible, isPlayingVideo) {
        if (isOverlayVisible && isPlayingVideo) {
            delay(4000)
            isOverlayVisible = false
        }
    }

    // Automatically save progress to history when starting play or changing episodes
    LaunchedEffect(currentEpisodeIndex) {
        viewModel.saveContinueWatching(
            animeId = anime.id,
            episodeIndex = currentEpisodeIndex,
            title = "Episode ${episode.episode} - ${episode.title}",
            position = currentPositionSec,
            duration = totalDurationSec
        )
    }

    Scaffold(
        containerColor = KageBlack
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(KageBlack),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 1. TOP HEADER NAVIGATION BAR (With Back Arrow, Logo, Search, and Profile Avatar)
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(
                            onClick = onNavigateBack,
                            modifier = Modifier.testTag("player_back_button")
                        ) {
                            Icon(Icons.Filled.ArrowBack, "Back", tint = KageWhite, modifier = Modifier.size(24.dp))
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "KAGE NET",
                            fontWeight = FontWeight.Bold,
                            color = KageWhite,
                            fontSize = 18.sp,
                            letterSpacing = 1.sp
                        )
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        // Search icon in a rounded box
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .border(1.dp, KageNeonBlue.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                                .clip(RoundedCornerShape(8.dp))
                                .clickable { 
                                    Toast.makeText(context, "Search clicked!", Toast.LENGTH_SHORT).show()
                                }
                                .padding(6.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Filled.Search, "Search", tint = KageWhite, modifier = Modifier.size(20.dp))
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        // Avatar circle with border
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .border(1.dp, KageNeonBlue, CircleShape)
                        ) {
                            AsyncImage(
                                model = profile?.profilePicturePath?.ifEmpty { null } 
                                    ?: "https://api.dicebear.com/7.x/adventurer/png?seed=KageNet",
                                contentDescription = "Profile",
                                modifier = Modifier.fillMaxSize(),
                                contentScale = ContentScale.Crop
                            )
                        }
                    }
                }
            }

            // 2. EMBEDDED PLAYER CONTAINER (16:9 Aspect Ratio with Default Browser/Stream Player)
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .aspectRatio(16f / 9f)
                        .background(Color.Black)
                        .testTag("video_player_container")
                ) {
                    key(refreshKey) {
                        if (isOfflineMode && completedDownload != null) {
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .clickable { isOverlayVisible = !isOverlayVisible }
                            ) {
                                OfflineVideoPlayer(
                                    filePath = completedDownload.filePath,
                                    isPlaying = isPlayingVideo,
                                    onPlayingChanged = { isPlayingVideo = it },
                                    currentPositionSec = currentPositionSec,
                                    onPositionChanged = { currentPositionSec = it },
                                    onDurationKnown = { totalDurationSec = it },
                                    isMuted = isMuted,
                                    modifier = Modifier.fillMaxSize()
                                )
                                
                                // Custom controls overlay
                                AnimatedVisibility(
                                    visible = isOverlayVisible,
                                    enter = fadeIn(),
                                    exit = fadeOut()
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .fillMaxSize()
                                            .background(Color.Black.copy(alpha = 0.6f))
                                    ) {
                                        // 1. Center Play/Pause & Seek buttons
                                        Row(
                                            modifier = Modifier.align(Alignment.Center),
                                            horizontalArrangement = Arrangement.spacedBy(24.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            // 10s Rewind
                                            IconButton(
                                                onClick = {
                                                    currentPositionSec = (currentPositionSec - 10).coerceAtLeast(0)
                                                },
                                                modifier = Modifier.size(48.dp)
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Filled.FastRewind,
                                                    contentDescription = "Rewind 10s",
                                                    tint = KageWhite,
                                                    modifier = Modifier.size(32.dp)
                                                )
                                            }
                                            
                                            // Play/Pause
                                            IconButton(
                                                onClick = { isPlayingVideo = !isPlayingVideo },
                                                modifier = Modifier
                                                    .size(64.dp)
                                                    .background(KageNeonBlue, CircleShape)
                                            ) {
                                                Icon(
                                                    imageVector = if (isPlayingVideo) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                                                    contentDescription = if (isPlayingVideo) "Pause" else "Play",
                                                    tint = Color.Black,
                                                    modifier = Modifier.size(36.dp)
                                                )
                                            }
                                            
                                            // 10s Forward
                                            IconButton(
                                                onClick = {
                                                    currentPositionSec = (currentPositionSec + 10).coerceAtMost(totalDurationSec)
                                                },
                                                modifier = Modifier.size(48.dp)
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Filled.FastForward,
                                                    contentDescription = "Forward 10s",
                                                    tint = KageWhite,
                                                    modifier = Modifier.size(32.dp)
                                                )
                                            }
                                        }
                                        
                                        // 2. Bottom progress bar & time displays
                                        Column(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .align(Alignment.BottomCenter)
                                                .padding(16.dp),
                                            verticalArrangement = Arrangement.spacedBy(4.dp)
                                        ) {
                                            // Progress Slider
                                            Slider(
                                                value = if (totalDurationSec > 0) currentPositionSec.toFloat() / totalDurationSec.toFloat() else 0f,
                                                onValueChange = { progress ->
                                                    currentPositionSec = (progress * totalDurationSec).toLong()
                                                },
                                                colors = SliderDefaults.colors(
                                                    thumbColor = KageNeonBlue,
                                                    activeTrackColor = KageNeonBlue,
                                                    inactiveTrackColor = KageGray.copy(alpha = 0.5f)
                                                ),
                                                modifier = Modifier.fillMaxWidth().height(16.dp)
                                            )
                                            
                                            // Time labels & Mute icon
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                val currentText = remember(currentPositionSec) {
                                                    val m = currentPositionSec / 60
                                                    val s = currentPositionSec % 60
                                                    String.format("%02d:%02d", m, s)
                                                }
                                                val totalText = remember(totalDurationSec) {
                                                    val m = totalDurationSec / 60
                                                    val s = totalDurationSec % 60
                                                    String.format("%02d:%02d", m, s)
                                                }
                                                
                                                Text(
                                                    text = "$currentText / $totalText",
                                                    color = KageWhite,
                                                    fontSize = 12.sp,
                                                    fontWeight = FontWeight.Medium
                                                )
                                                
                                                Row(
                                                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    // Mute Button
                                                    IconButton(
                                                        onClick = { isMuted = !isMuted },
                                                        modifier = Modifier.size(24.dp)
                                                    ) {
                                                        Icon(
                                                            imageVector = if (isMuted) Icons.Filled.VolumeOff else Icons.Filled.VolumeUp,
                                                            contentDescription = "Mute",
                                                            tint = KageWhite,
                                                            modifier = Modifier.size(18.dp)
                                                        )
                                                    }
                                                    
                                                    Text(
                                                        text = "OFFLINE PLAY",
                                                        color = KageNeonBlue,
                                                        fontSize = 10.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        letterSpacing = 1.sp
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        } else {
                            // Online mode uses default player with NO custom control overlays
                            VideoWebView(
                                url = activeUrl,
                                modifier = Modifier.fillMaxSize()
                            )
                        }
                    }
                }

                // Sleek Player Utility & Refresh Row
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (isOfflineMode) "Offline Playback Mode" else "Streaming Live via $selectedServer",
                        color = KageGray,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )

                    Button(
                        onClick = {
                            refreshKey++
                            Toast.makeText(context, "Reloading video...", Toast.LENGTH_SHORT).show()
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF1E293B),
                            contentColor = KageNeonBlue
                        ),
                        border = BorderStroke(1.dp, KageNeonBlue.copy(alpha = 0.5f)),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("refresh_video_button")
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Refresh,
                                contentDescription = "Refresh Video",
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                text = "Refresh Video",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            // 3. ANIME TITLE & METADATA SECTION
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Top
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = anime.title,
                                color = KageWhite,
                                fontSize = 22.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Season 1 • Episode ${episode.episode} • ${episode.title}",
                                color = KageGray,
                                fontSize = 13.sp
                            )
                        }

                        // "+ My List" Toggle Button
                        val isWatchLater = watchLater.any { it.animeId == anime.id }
                        Button(
                            onClick = { viewModel.toggleWatchLater(anime.id) },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isWatchLater) KageNeonBlue.copy(alpha = 0.2f) else Color.Transparent,
                                contentColor = if (isWatchLater) KageNeonBlue else KageWhite
                            ),
                            shape = RoundedCornerShape(8.dp),
                            border = BorderStroke(1.dp, if (isWatchLater) KageNeonBlue else KageWhite.copy(alpha = 0.3f)),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                            modifier = Modifier.testTag("player_my_list_button")
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Icon(
                                    imageVector = if (isWatchLater) Icons.Filled.Check else Icons.Filled.Add,
                                    contentDescription = "My List",
                                    modifier = Modifier.size(16.dp)
                                )
                                Text(
                                    text = if (isWatchLater) "In My List" else "My List",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Quality & Accessibility Chips
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .border(1.dp, KageNeonBlue, RoundedCornerShape(4.dp))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text("CC", color = KageNeonBlue, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                        Box(
                            modifier = Modifier
                                .background(KageNeonBlue, RoundedCornerShape(4.dp))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text("1080p", color = Color.Black, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                        Box(
                            modifier = Modifier
                                .background(Color(0xFF1E293B), RoundedCornerShape(4.dp))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text("Sub", color = KageWhite, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            // 4. NEXT EPISODE HIGHLIGHT CARD (Taps instantly play next ep)
            val nextEpisodeIdx = currentEpisodeIndex + 1
            if (nextEpisodeIdx < anime.episodes.size) {
                val nextEp = anime.episodes[nextEpisodeIdx]
                item {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp)
                    ) {
                        Text(
                            text = "NEXT EPISODE",
                            color = KageNeonBlue,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                        Spacer(modifier = Modifier.height(8.dp))

                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { 
                                    currentEpisodeIndex = nextEpisodeIdx 
                                    currentPositionSec = 0L
                                }
                                .testTag("player_next_episode_card"),
                            colors = CardDefaults.cardColors(containerColor = KageDarkCard),
                            border = BorderStroke(0.5.dp, KageNeonBlue.copy(alpha = 0.3f)),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(width = 100.dp, height = 58.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                ) {
                                    AsyncImage(
                                        model = nextEp.thumbnail,
                                        contentDescription = null,
                                        modifier = Modifier.fillMaxSize(),
                                        contentScale = ContentScale.Crop
                                    )
                                }

                                Spacer(modifier = Modifier.width(12.dp))

                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "Episode ${nextEp.episode}",
                                        color = KageWhite,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = nextEp.title,
                                        color = KageGray,
                                        fontSize = 11.sp,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }

                                // Play Icon
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(CircleShape)
                                        .background(KageNeonBlue),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.PlayArrow,
                                        contentDescription = "Play Next",
                                        tint = Color.Black,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Offline Mode Selector if episode is downloaded
            if (completedDownload != null) {
                item {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 6.dp),
                        colors = CardDefaults.cardColors(containerColor = KageDarkCard),
                        border = BorderStroke(0.5.dp, if (isPlayOfflineSelected) KageNeonBlue else Color(0x33FFFFFF))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Download,
                                    contentDescription = "Offline Playback",
                                    tint = if (isPlayOfflineSelected) KageNeonBlue else KageWhite.copy(alpha = 0.5f),
                                    modifier = Modifier.size(24.dp)
                                )
                                Column {
                                    Text(
                                        text = "Offline Mode",
                                        color = KageWhite,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = if (isPlayOfflineSelected) "Playing downloaded file offline" else "Switch to play offline",
                                        color = KageGray,
                                        fontSize = 11.sp
                                    )
                                }
                            }
                            Switch(
                                checked = isPlayOfflineSelected,
                                onCheckedChange = { isPlayOfflineSelected = it },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = Color.Black,
                                    checkedTrackColor = KageNeonBlue,
                                    uncheckedThumbColor = KageGray,
                                    uncheckedTrackColor = Color(0xFF1E293B)
                                )
                            )
                        }
                    }
                }
            }

            // 5. SERVER / QUALITY SELECTION CONTROL BOX
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    colors = CardDefaults.cardColors(containerColor = KageDarkSpace.copy(alpha = 0.5f)),
                    border = BorderStroke(0.5.dp, Color(0x220084FF))
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Active Server: $selectedServer",
                                color = KageWhite,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Quality: $selectedQuality",
                                color = KageNeonBlue,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            listOf("Google Drive", "Dailymotion").forEach { server ->
                                val isSelected = selectedServer == server
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(if (isSelected) KageNeonBlue else Color(0xFF1E293B))
                                        .clickable { selectedServer = server }
                                        .padding(horizontal = 12.dp, vertical = 6.dp)
                                ) {
                                    Text(
                                        text = server,
                                        color = if (isSelected) Color.Black else KageWhite,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                        
                        if (selectedServer == "Google Drive") {
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = "Stream Quality:",
                                color = KageWhite.copy(alpha = 0.7f),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                listOf("1080p", "720p", "480p").forEach { quality ->
                                    val isSelected = selectedQuality == quality
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(if (isSelected) KageNeonBlue else Color(0xFF1E293B))
                                            .clickable { selectedQuality = quality }
                                            .padding(horizontal = 12.dp, vertical = 6.dp)
                                    ) {
                                        Text(
                                            text = quality,
                                            color = if (isSelected) Color.Black else KageWhite,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // 6. TWO TABS SEGMENT (EPISODES, DETAILS)
            val tabs = listOf("EPISODES", "DETAILS")

            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 4.dp)
                        .drawBehind {
                            drawLine(
                                color = Color(0xFF1E293B),
                                start = androidx.compose.ui.geometry.Offset(0f, size.height),
                                end = androidx.compose.ui.geometry.Offset(size.width, size.height),
                                strokeWidth = 1.dp.toPx()
                            )
                        },
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    tabs.forEach { tabName ->
                        val tabKey = tabName.substringBefore(" ")
                        val isSelected = activeTab == tabKey
                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .clickable { activeTab = tabKey }
                                .padding(vertical = 12.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = tabName,
                                color = if (isSelected) KageNeonBlue else KageGray,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 0.5.sp
                            )
                            if (isSelected) {
                                Spacer(modifier = Modifier.height(8.dp))
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth(0.6f)
                                        .height(2.dp)
                                        .background(KageNeonBlue)
                                )
                            }
                        }
                    }
                }
            }

            // 7. TAB BODY CONTENT
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp)
                ) {
                    when (activeTab) {
                        "EPISODES" -> {
                            // Filter row matching screenshot
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(Color(0xFF101F38))
                                        .clickable { }
                                        .padding(horizontal = 8.dp, vertical = 6.dp)
                                ) {
                                    Text("Season 1", color = KageWhite, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Icon(Icons.Filled.ArrowDropDown, null, tint = KageWhite, modifier = Modifier.size(16.dp))
                                }
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Filled.SwapVert, null, tint = KageGray, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Oldest First", color = KageGray, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                                }
                            }
                            
                            // Episodes list inside tab
                            anime.episodes.forEachIndexed { index, ep ->
                                val isPlaying = index == currentEpisodeIndex
                                val isDownloaded = downloads.any { 
                                    it.animeId == anime.id && it.episodeIndex == index && it.status == "completed" 
                                }
                                val isDownloading = downloads.any { 
                                    it.animeId == anime.id && it.episodeIndex == index && (it.status == "downloading" || it.status == "pending") 
                                }

                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { 
                                            currentEpisodeIndex = index 
                                            currentPositionSec = 0L
                                        }
                                        .padding(vertical = 10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(width = 110.dp, height = 65.dp)
                                            .clip(RoundedCornerShape(8.dp))
                                    ) {
                                        AsyncImage(
                                            model = ep.thumbnail,
                                            contentDescription = null,
                                            modifier = Modifier.fillMaxSize(),
                                            contentScale = ContentScale.Crop
                                        )
                                        Box(
                                            modifier = Modifier
                                                .fillMaxSize()
                                                .background(Color.Black.copy(alpha = 0.3f)),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Box(
                                                modifier = Modifier
                                                    .size(28.dp)
                                                    .clip(CircleShape)
                                                    .background(if (isPlaying) KageNeonBlue else Color.Black.copy(alpha = 0.6f))
                                                    .border(1.dp, KageWhite.copy(alpha = 0.8f), CircleShape),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Filled.PlayArrow,
                                                    contentDescription = "Play",
                                                    tint = if (isPlaying) Color.Black else KageWhite,
                                                    modifier = Modifier.size(16.dp)
                                                )
                                            }
                                        }
                                    }
                                    
                                    Spacer(modifier = Modifier.width(12.dp))
                                    
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = "${ep.episode}. ${ep.title}",
                                            color = if (isPlaying) KageNeonBlue else KageWhite,
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.Bold,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = "23m",
                                            color = KageGray,
                                            fontSize = 11.sp
                                        )
                                    }

                                    // Dynamic download button with integrated database state
                                    IconButton(
                                        onClick = {
                                            if (!isDownloaded && !isDownloading) {
                                                selectedDownloadEpisode = ep
                                                selectedDownloadEpisodeIndex = index
                                                showDownloadQualityDialog = true
                                            } else if (isDownloaded) {
                                                Toast.makeText(context, "Episode ${ep.episode} already downloaded!", Toast.LENGTH_SHORT).show()
                                            }
                                        }
                                    ) {
                                        when {
                                            isDownloaded -> {
                                                Icon(
                                                    imageVector = Icons.Filled.CheckCircle,
                                                    contentDescription = "Downloaded",
                                                    tint = KageGreen,
                                                    modifier = Modifier.size(20.dp)
                                                )
                                            }
                                            isDownloading -> {
                                                CircularProgressIndicator(
                                                    color = KageNeonBlue,
                                                    strokeWidth = 2.dp,
                                                    modifier = Modifier.size(16.dp)
                                                )
                                            }
                                            else -> {
                                                Icon(
                                                    imageVector = Icons.Filled.Download,
                                                    contentDescription = "Download",
                                                    tint = KageGray,
                                                    modifier = Modifier.size(20.dp)
                                                )
                                            }
                                        }
                                    }
                                    
                                    IconButton(onClick = { }) {
                                        Icon(
                                            imageVector = Icons.Filled.MoreVert,
                                            contentDescription = "Options",
                                            tint = KageGray,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                }
                            }
                        }
                        
                        "DETAILS" -> {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 8.dp),
                                verticalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Text(
                                    text = "SYNOPSIS",
                                    color = KageNeonBlue,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 1.sp
                                )
                                Text(
                                    text = episode.description ?: anime.description,
                                    color = KageWhite,
                                    fontSize = 13.sp,
                                    lineHeight = 20.sp
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(32.dp)
                                ) {
                                    Column {
                                        Text("STUDIO", color = KageGray, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                        Text(anime.studio, color = KageWhite, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                                    }
                                    Column {
                                        Text("YEAR", color = KageGray, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                        Text(anime.year.toString(), color = KageWhite, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                                    }
                                    Column {
                                        Text("RATING", color = KageGray, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(Icons.Filled.Star, null, tint = KageNeonBlue, modifier = Modifier.size(14.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text(anime.rating.toString(), color = KageWhite, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                                        }
                                    }
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "GENRES",
                                    color = KageNeonBlue,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 1.sp
                                )
                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    anime.genres.forEach { genre ->
                                        Box(
                                            modifier = Modifier
                                                .background(Color(0xFF1E293B).copy(alpha = 0.6f), RoundedCornerShape(6.dp))
                                                .border(0.5.dp, KageNeonBlue.copy(alpha = 0.4f), RoundedCornerShape(6.dp))
                                                .padding(horizontal = 10.dp, vertical = 4.dp)
                                        ) {
                                            Text(genre, color = KageWhite, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // 8. RECOMMENDATIONS ("YOU MAY ALSO LIKE" HORIZONTAL ROW)
            item {
                val recommendations = dbState.anime.filter { it.id != anime.id }
                if (recommendations.isNotEmpty()) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "You May Also Like",
                                color = KageWhite,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Icon(
                                imageVector = Icons.Filled.ChevronRight,
                                contentDescription = "See All",
                                tint = KageNeonBlue,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        
                        Spacer(modifier = Modifier.height(10.dp))
                        
                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            items(recommendations) { rec ->
                                Card(
                                    modifier = Modifier
                                        .width(110.dp)
                                        .clickable {
                                            // Play this recommended anime instead (loads episode 0 or first episode)
                                            Toast.makeText(context, "Loading ${rec.title}", Toast.LENGTH_SHORT).show()
                                            currentEpisodeIndex = 0
                                            currentPositionSec = 0L
                                        },
                                    colors = CardDefaults.cardColors(containerColor = Color.Transparent)
                                ) {
                                    Column {
                                        Box(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .height(150.dp)
                                                .clip(RoundedCornerShape(8.dp))
                                        ) {
                                            AsyncImage(
                                                model = rec.cover,
                                                contentDescription = rec.title,
                                                modifier = Modifier.fillMaxSize(),
                                                contentScale = ContentScale.Crop
                                            )
                                        }
                                        Spacer(modifier = Modifier.height(6.dp))
                                        Text(
                                            text = rec.title,
                                            color = KageWhite,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Text(
                                            text = "${rec.year} • ${rec.rating}",
                                            color = KageGray,
                                            fontSize = 9.sp,
                                            maxLines = 1
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Bottom Spacer
            item {
                Spacer(modifier = Modifier.height(32.dp))
            }
        }
    }

    if (showDownloadQualityDialog && selectedDownloadEpisode != null) {
        AlertDialog(
            onDismissRequest = { 
                showDownloadQualityDialog = false 
                selectedDownloadEpisode = null
            },
            containerColor = KageDarkCard,
            titleContentColor = KageWhite,
            textContentColor = KageGray,
            title = {
                Text(
                    text = "Select Download Quality",
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    color = KageWhite
                )
            },
            text = {
                Column(
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.padding(top = 8.dp)
                ) {
                    Text(
                        text = "Choose a quality to download \"${selectedDownloadEpisode?.title}\" to local storage for offline playback:",
                        fontSize = 13.sp,
                        color = KageGray
                    )
                    
                    listOf("1080p", "720p", "480p").forEach { quality ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFF1E293B))
                                .clickable {
                                    showDownloadQualityDialog = false
                                    val targetEp = selectedDownloadEpisode!!
                                    val targetIdx = selectedDownloadEpisodeIndex
                                    selectedDownloadEpisode = null
                                    
                                    triggerDownloadWithPermission(targetEp, targetIdx, quality)
                                }
                                .padding(horizontal = 16.dp, vertical = 12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = quality,
                                color = KageWhite,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                            Icon(
                                imageVector = Icons.Filled.Download,
                                contentDescription = "Download $quality",
                                tint = KageNeonBlue,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(
                    onClick = { 
                        showDownloadQualityDialog = false 
                        selectedDownloadEpisode = null
                    }
                ) {
                    Text("Cancel", color = KageNeonBlue)
                }
            }
        )
    }
}

@SuppressLint("UnsafeOptInUsageError")
@Composable
fun OfflineVideoPlayer(
    filePath: String,
    isPlaying: Boolean,
    onPlayingChanged: (Boolean) -> Unit,
    currentPositionSec: Long,
    onPositionChanged: (Long) -> Unit,
    onDurationKnown: (Long) -> Unit,
    isMuted: Boolean,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    
    // Create and remember ExoPlayer
    val exoPlayer = remember(context) {
        ExoPlayer.Builder(context).build().apply {
            repeatMode = Player.REPEAT_MODE_OFF
        }
    }
    
    // Set up media item
    LaunchedEffect(filePath) {
        val file = java.io.File(filePath)
        if (file.exists()) {
            val uri = android.net.Uri.fromFile(file)
            val mediaItem = MediaItem.fromUri(uri)
            exoPlayer.setMediaItem(mediaItem)
            exoPlayer.prepare()
        }
    }
    
    // Play / Pause control
    LaunchedEffect(isPlaying) {
        if (isPlaying) {
            exoPlayer.play()
        } else {
            exoPlayer.pause()
        }
    }
    
    // Seek tracking & feedback loop
    var isSeekingInternal = false
    LaunchedEffect(currentPositionSec) {
        val playerPosSec = exoPlayer.currentPosition / 1000
        if (kotlin.math.abs(playerPosSec - currentPositionSec) > 1 && !isSeekingInternal) {
            exoPlayer.seekTo(currentPositionSec * 1000)
        }
    }
    
    // Mute / Unmute control
    LaunchedEffect(isMuted) {
        exoPlayer.volume = if (isMuted) 0f else 1f
    }
    
    // Periodic progress updates from player to screen
    LaunchedEffect(exoPlayer) {
        while (true) {
            val durationSec = exoPlayer.duration / 1000
            val positionSec = exoPlayer.currentPosition / 1000
            if (durationSec > 0) {
                onDurationKnown(durationSec)
            }
            if (positionSec >= 0) {
                isSeekingInternal = true
                onPositionChanged(positionSec)
                isSeekingInternal = false
            }
            
            // Check if playing finished or state changed
            val isCurrentlyPlaying = exoPlayer.isPlaying
            if (isCurrentlyPlaying != isPlaying) {
                onPlayingChanged(isCurrentlyPlaying)
            }
            delay(1000L)
        }
    }
    
    // Clean up player on dispose
    DisposableEffect(Unit) {
        onDispose {
            exoPlayer.release()
        }
    }
    
    // Android ExoPlayer View container
    AndroidView(
        factory = { ctx ->
            PlayerView(ctx).apply {
                player = exoPlayer
                useController = false
                layoutParams = android.view.ViewGroup.LayoutParams(
                    android.view.ViewGroup.LayoutParams.MATCH_PARENT,
                    android.view.ViewGroup.LayoutParams.MATCH_PARENT
                )
            }
        },
        modifier = modifier
    )
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun VideoWebView(
    url: String,
    modifier: Modifier = Modifier
) {
    val embedUrl = remember(url) { convertToEmbedUrl(url) }
    val lifecycleOwner = LocalLifecycleOwner.current

    // Keep reference to webview to control pause/resume in response to lifecycle
    var webViewRef by remember { mutableStateOf<WebView?>(null) }

    // Observe lifecycle events to pause/resume WebView playback
    DisposableEffect(lifecycleOwner, webViewRef) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_PAUSE -> {
                    webViewRef?.onPause()
                    webViewRef?.pauseTimers()
                }
                Lifecycle.Event.ON_RESUME -> {
                    webViewRef?.onResume()
                    webViewRef?.resumeTimers()
                }
                else -> {}
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    // Clean up webview when composable is destroyed
    DisposableEffect(Unit) {
        onDispose {
            webViewRef?.let { wv ->
                wv.onPause()
                wv.pauseTimers()
                wv.loadUrl("about:blank")
                wv.clearHistory()
                wv.removeAllViews()
                wv.destroy()
            }
        }
    }

    AndroidView(
        factory = { ctx ->
            WebView(ctx).apply {
                settings.apply {
                    javaScriptEnabled = true
                    domStorageEnabled = true
                    mediaPlaybackRequiresUserGesture = false
                    useWideViewPort = true
                    loadWithOverviewMode = true
                    allowContentAccess = true
                    allowFileAccess = true
                    databaseEnabled = true
                    mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
                    userAgentString = "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
                }
                webViewClient = WebViewClient()
                webChromeClient = WebChromeClient()
                layoutParams = android.view.ViewGroup.LayoutParams(
                    android.view.ViewGroup.LayoutParams.MATCH_PARENT,
                    android.view.ViewGroup.LayoutParams.MATCH_PARENT
                )
                webViewRef = this
            }
        },
        update = { webView ->
            if (webView.url != embedUrl) {
                webView.loadUrl(embedUrl)
            }
        },
        modifier = modifier
    )
}

fun convertToEmbedUrl(url: String): String {
    return when {
        url.contains("dailymotion.com") || url.contains("dai.ly") -> {
            val regex = Regex("(?:video|embed/video|dai\\.ly)/([a-zA-Z0-9]+)")
            val matchResult = regex.find(url)
            val videoId = matchResult?.groupValues?.get(1) ?: "x7tg3f0"
            "https://www.dailymotion.com/embed/video/$videoId?autoplay=1&mute=0&muted=false&volume=1.0"
        }
        url.contains("drive.google.com") -> {
            val regex = Regex("/file/d/([a-zA-Z0-9_-]+)")
            val matchResult = regex.find(url)
            val driveId = matchResult?.groupValues?.get(1)
            if (driveId != null) {
                "https://drive.google.com/file/d/$driveId/preview"
            } else {
                url
            }
        }
        else -> url
    }
}
