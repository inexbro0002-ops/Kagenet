package com.example.ui.screens

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import android.util.Log
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.rememberTransformableState
import androidx.compose.foundation.gestures.transformable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.KageViewModel
import com.example.ui.theme.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.FileOutputStream
import android.view.ViewGroup
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebChromeClient
import androidx.compose.ui.viewinterop.AndroidView

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReaderScreen(
    mangaId: String,
    chapterIndex: Int,
    viewModel: KageViewModel,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val dbState by viewModel.databaseState.collectAsStateWithLifecycle()
    val downloads by viewModel.downloadsState.collectAsStateWithLifecycle()

    val manga = dbState.manga.find { it.id == mangaId }
    if (manga == null || manga.chapters.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("No manga chapter found", color = KageWhite)
        }
        return
    }

    var currentChapIdx by remember { mutableStateOf(chapterIndex) }
    val chapter = manga.chapters.getOrNull(currentChapIdx) ?: manga.chapters.first()

    // Download path verify
    val downloadId = "${manga.id}_chap_${chapter.number}"
    val completedDownload = downloads.find { it.downloadId == downloadId && it.status == "completed" }

    var localFileState by remember { mutableStateOf<File?>(null) }
    var isLoadingOnlineFile by remember { mutableStateOf(false) }
    var loadingError by remember { mutableStateOf<String?>(null) }

    // Stream Mode vs Native Cache Mode toggle
    var isStreamMode by remember { mutableStateOf(completedDownload == null) }

    // Navigation and Direction
    var isVerticalMode by remember { mutableStateOf(true) }
    var isFullscreen by remember { mutableStateOf(false) }
    var isBookmarked by remember { mutableStateOf(false) }

    // Advanced reader customize states
    var readerTheme by remember { mutableStateOf("Default") } // "Default", "Dark" (Inverted), "Sepia", "Warm"
    var dimLevel by remember { mutableFloatStateOf(0f) }
    var showSettingsDialog by remember { mutableStateOf(false) }

    // Session stats tracking
    val startTime = remember { System.currentTimeMillis() }
    var totalPagesRead by remember { mutableIntStateOf(1) }

    // Automatically set/reset streaming mode when chapter changes
    LaunchedEffect(chapter) {
        isStreamMode = completedDownload == null
    }

    // Load PDF file: Check if downloaded, or cache remote PDF
    LaunchedEffect(completedDownload, chapter, isStreamMode) {
        if (completedDownload != null) {
            val file = File(completedDownload.filePath)
            if (file.exists()) {
                localFileState = file
                isLoadingOnlineFile = false
                loadingError = null
                isStreamMode = false
                return@LaunchedEffect
            }
        }

        if (isStreamMode) {
            localFileState = null
            isLoadingOnlineFile = false
            loadingError = null
            return@LaunchedEffect
        }

        // Fetch online PDF to a temp file in cache Dir
        isLoadingOnlineFile = true
        loadingError = null
        withContext(Dispatchers.IO) {
            try {
                val tempFile = File(context.cacheDir, "temp_reader_ch_${chapter.number}.pdf")
                if (tempFile.exists()) {
                    tempFile.delete()
                }
                
                Log.d("ReaderScreen", "Downloading online PDF to cache: ${chapter.pdf}")
                val client = OkHttpClient()
                val request = Request.Builder().url(chapter.pdf).build()
                client.newCall(request).execute().use { response ->
                    if (!response.isSuccessful) {
                        throw Exception("Server returned code ${response.code}")
                    }
                    val body = response.body ?: throw Exception("Empty response body")
                    FileOutputStream(tempFile).use { fos ->
                        body.byteStream().copyTo(fos)
                    }
                    withContext(Dispatchers.Main) {
                        localFileState = tempFile
                        isLoadingOnlineFile = false
                    }
                }
            } catch (e: Exception) {
                Log.e("ReaderScreen", "Error downloading PDF for chapter", e)
                withContext(Dispatchers.Main) {
                    loadingError = "Failed to load online chapter natively: ${e.localizedMessage}\n\nWe recommend using 'Stream Mode' (Cloud icon) for this document."
                    isLoadingOnlineFile = false
                }
            }
        }
    }

    // Zoom transformable gesture state
    var scale by remember { mutableFloatStateOf(1f) }
    var offset by remember { mutableStateOf(Offset.Zero) }
    val state = rememberTransformableState { zoomChange, offsetChange, _ ->
        scale = (scale * zoomChange).coerceIn(1f, 4f)
        offset += offsetChange
    }

    Scaffold(
        topBar = {
            if (!isFullscreen) {
                CenterAlignedTopAppBar(
                    title = {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(manga.title, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = KageWhite)
                            Text("Chapter ${chapter.number} - ${chapter.title}", fontSize = 11.sp, color = KageNeonBlue)
                        }
                    },
                    navigationIcon = {
                        IconButton(onClick = onNavigateBack, modifier = Modifier.minimumInteractiveComponentSize()) {
                            Icon(Icons.Filled.ArrowBack, "Back", tint = KageWhite)
                        }
                    },
                    actions = {
                        // Horizontal vs Vertical direction switch
                        IconButton(
                            onClick = { isVerticalMode = !isVerticalMode },
                            modifier = Modifier.minimumInteractiveComponentSize()
                        ) {
                            Icon(
                                imageVector = if (isVerticalMode) Icons.Filled.MenuBook else Icons.Filled.Book,
                                contentDescription = "Scroll Mode",
                                tint = KageNeonBlue
                            )
                        }

                        // Bookmark page
                        IconButton(
                            onClick = { isBookmarked = !isBookmarked },
                            modifier = Modifier.minimumInteractiveComponentSize()
                        ) {
                            Icon(
                                imageVector = if (isBookmarked) Icons.Filled.Bookmark else Icons.Filled.BookmarkBorder,
                                contentDescription = "Bookmark",
                                tint = if (isBookmarked) KageNeonBlue else KageWhite
                            )
                        }

                        // Reader Mode Toggle (WebView vs Native)
                        IconButton(
                            onClick = { isStreamMode = !isStreamMode },
                            modifier = Modifier.minimumInteractiveComponentSize()
                        ) {
                            Icon(
                                imageVector = if (isStreamMode) Icons.Filled.Cloud else Icons.Filled.FileDownload,
                                contentDescription = if (isStreamMode) "Switch to Native Mode" else "Switch to Stream Mode",
                                tint = if (isStreamMode) KageNeonBlue else KageWhite
                            )
                        }

                        // Custom Reader settings button
                        IconButton(
                            onClick = { showSettingsDialog = true },
                            modifier = Modifier.minimumInteractiveComponentSize()
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Tune,
                                contentDescription = "Reader Settings",
                                tint = KageNeonBlue
                            )
                        }
                    },
                    colors = TopAppBarDefaults.centerAlignedTopAppBarColors(containerColor = KageDeepAbyss)
                )
            }
        },
        bottomBar = {
            if (!isFullscreen) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(KageDeepAbyss)
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Back Chapter
                    TextButton(
                        onClick = { if (currentChapIdx > 0) currentChapIdx-- },
                        enabled = currentChapIdx > 0
                    ) {
                        Text("Prev Chapter", color = if (currentChapIdx > 0) KageNeonBlue else KageGray)
                    }

                    // Fullscreen trigger
                    IconButton(
                        onClick = { isFullscreen = true },
                        modifier = Modifier.minimumInteractiveComponentSize()
                    ) {
                        Icon(Icons.Filled.Fullscreen, "Fullscreen", tint = KageWhite)
                    }

                    // Next Chapter
                    TextButton(
                        onClick = { if (currentChapIdx < manga.chapters.size - 1) currentChapIdx++ },
                        enabled = currentChapIdx < manga.chapters.size - 1
                    ) {
                        Text("Next Chapter", color = if (currentChapIdx < manga.chapters.size - 1) KageNeonBlue else KageGray)
                    }
                }
            }
        },
        containerColor = KageBlack
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(Color.Black)
        ) {
            when {
                isStreamMode -> {
                    PdfWebView(
                        url = chapter.pdf,
                        modifier = Modifier.fillMaxSize()
                    )
                }
                isLoadingOnlineFile -> {
                    Column(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        CircularProgressIndicator(color = KageNeonBlue)
                        Spacer(modifier = Modifier.height(16.dp))
                        Text("Loading chapter dynamically from server...", color = KageWhite, fontSize = 14.sp)
                    }
                }
                loadingError != null -> {
                    Column(
                        modifier = Modifier.fillMaxSize().padding(24.dp),
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(Icons.Filled.ErrorOutline, "Error", tint = Color.Red, modifier = Modifier.size(48.dp))
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(loadingError!!, color = KageWhite, textAlign = TextAlign.Center)
                    }
                }
                localFileState != null -> {
                    // Renderer native view
                    PdfPageViewports(
                        file = localFileState!!,
                        isVertical = isVerticalMode,
                        scale = scale,
                        offset = offset,
                        transformableState = state,
                        readerTheme = readerTheme,
                        onPageChanged = { page, total ->
                            totalPagesRead = page
                            viewModel.saveContinueReading(
                                mangaId = manga.id,
                                chapterIndex = currentChapIdx,
                                title = "Chapter ${chapter.number} - ${chapter.title}",
                                page = page,
                                totalPages = total
                            )
                        },
                        onFallbackToStream = {
                            isStreamMode = true
                        }
                    )
                }
            }

            // Ambient Dimmer Overlay
            if (dimLevel > 0f) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = dimLevel))
                )
            }

            // Floating Floating Action button for Fullscreen restore
            if (isFullscreen) {
                IconButton(
                    onClick = { isFullscreen = false },
                    modifier = Modifier
                        .padding(16.dp)
                        .background(KageBlack.copy(alpha = 0.8f), RoundedCornerShape(8.dp))
                        .border(0.5.dp, KageNeonBlue, RoundedCornerShape(8.dp))
                        .align(Alignment.BottomEnd)
                ) {
                    Icon(Icons.Filled.FullscreenExit, "Restore", tint = KageWhite)
                }
            }
        }

        // Customize Settings Dialog
        if (showSettingsDialog) {
            AlertDialog(
                onDismissRequest = { showSettingsDialog = false },
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.Tune, "Settings", tint = KageNeonBlue)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Reader Customizer", color = KageWhite, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    }
                },
                text = {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        // 1. Theme filters selector
                        Column {
                            Text("Page Tone Filter", color = KageGray, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                listOf("Default", "Dark", "Sepia", "Warm").forEach { theme ->
                                    val isSel = readerTheme == theme
                                    Box(
                                        modifier = Modifier
                                            .weight(1f)
                                            .background(if (isSel) KageNeonBlue else KageDarkCard, RoundedCornerShape(8.dp))
                                            .clickable { readerTheme = theme }
                                            .padding(vertical = 8.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = theme,
                                            color = if (isSel) KageBlack else KageWhite,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 11.sp
                                        )
                                    }
                                }
                            }
                        }

                        // 2. Brightness / Dimmer slider
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("Ambient Dimmer", color = KageGray, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                Text("${(dimLevel * 100).toInt()}%", color = KageNeonBlue, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Slider(
                                value = dimLevel,
                                onValueChange = { dimLevel = it },
                                valueRange = 0.0f..0.8f,
                                colors = SliderDefaults.colors(
                                    thumbColor = KageNeonBlue,
                                    activeTrackColor = KageNeonBlue,
                                    inactiveTrackColor = KageDarkCard
                                )
                            )
                        }

                        // 3. Stats section
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(KageDarkCard, RoundedCornerShape(12.dp))
                                .padding(12.dp)
                        ) {
                            Text("Reading Session Analytics", color = KageNeonBlue, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(6.dp))
                            
                            val elapsedMinutes = ((System.currentTimeMillis() - startTime) / 1000) / 60
                            val speed = if (elapsedMinutes > 0) (totalPagesRead.toFloat() / elapsedMinutes).toInt() else totalPagesRead
                            
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Time Elapsed:", color = KageGray, fontSize = 11.sp)
                                Text("$elapsedMinutes min", color = KageWhite, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Pages Read:", color = KageGray, fontSize = 11.sp)
                                Text("$totalPagesRead pages", color = KageWhite, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Reading Velocity:", color = KageGray, fontSize = 11.sp)
                                Text("$speed pages/min", color = KageWhite, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                            }
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = { showSettingsDialog = false }) {
                        Text("Save & Close", color = KageNeonBlue, fontWeight = FontWeight.Bold)
                    }
                },
                containerColor = KageDarkSpace,
                shape = RoundedCornerShape(16.dp)
            )
        }
    }
}

// Custom annotation to bypass modifier warning in composite layers
@SuppressLint("ModifierParameter")
@Composable
fun PdfPageViewports(
    file: File,
    isVertical: Boolean,
    scale: Float,
    offset: Offset,
    transformableState: androidx.compose.foundation.gestures.TransformableState,
    readerTheme: String,
    onPageChanged: (Int, Int) -> Unit,
    onFallbackToStream: () -> Unit
) {
    val context = LocalContext.current
    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()

    // Safely open the PdfRenderer using runCatching to prevent crashes if file is corrupt
    val rendererResult = remember(file) {
        runCatching {
            val pfd = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
            PdfRenderer(pfd)
        }
    }

    val renderer = rendererResult.getOrNull()

    if (renderer == null) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(32.dp)
                .background(Color.Black),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = Icons.Filled.CloudOff,
                contentDescription = "Native render error",
                tint = KageNeonBlue,
                modifier = Modifier.size(64.dp)
            )
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = "Native Rendering Unavailable",
                color = KageWhite,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "This document cannot be loaded natively. This often happens due to web server security firewalls blocking direct binary downloads.",
                color = KageGray,
                fontSize = 13.sp,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(24.dp))
            Button(
                onClick = onFallbackToStream,
                colors = ButtonDefaults.buttonColors(containerColor = KageNeonBlue),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.testTag("stream_mode_fallback_button")
            ) {
                Icon(Icons.Filled.Cloud, contentDescription = null, tint = KageBlack)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Switch to Stream Mode", color = KageBlack, fontWeight = FontWeight.Bold)
            }
        }
        return
    }

    val pageCount = renderer.pageCount

    // Emit page progress callbacks on list scroll changes
    LaunchedEffect(listState.firstVisibleItemIndex) {
        onPageChanged(listState.firstVisibleItemIndex + 1, pageCount)
    }

    DisposableEffect(renderer) {
        onDispose {
            try {
                renderer.close()
            } catch (e: Exception) {
                Log.e("PdfPageViewports", "Error closing renderer", e)
            }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .transformable(state = transformableState)
            .graphicsLayer(
                scaleX = scale,
                scaleY = scale,
                translationX = offset.x,
                translationY = offset.y
            )
    ) {
        if (isVertical) {
            LazyColumn(
                state = listState,
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(bottom = 120.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(pageCount) { pageIndex ->
                    PdfPageItem(renderer = renderer, pageIndex = pageIndex, readerTheme = readerTheme)
                }
            }
        } else {
            LazyRow(
                state = listState,
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(end = 120.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(pageCount) { pageIndex ->
                    PdfPageItem(renderer = renderer, pageIndex = pageIndex, readerTheme = readerTheme)
                }
            }
        }
    }
}

@Composable
fun PdfPageItem(renderer: PdfRenderer, pageIndex: Int, readerTheme: String) {
    var bitmap by remember { mutableStateOf<Bitmap?>(null) }
    
    LaunchedEffect(pageIndex) {
        withContext(Dispatchers.IO) {
            try {
                val page = renderer.openPage(pageIndex)
                // 2x scaling rendering for ultra crisp details when zoomed
                val bmp = Bitmap.createBitmap(page.width * 2, page.height * 2, Bitmap.Config.ARGB_8888)
                page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                page.close()
                bitmap = bmp
            } catch (e: Exception) {
                Log.e("PdfPageItem", "Failed to render page: $pageIndex", e)
            }
        }
    }

    val colorFilter = remember(readerTheme) {
        when (readerTheme) {
            "Dark" -> ColorFilter.colorMatrix(ColorMatrix(floatArrayOf(
                -1f, 0f, 0f, 0f, 255f,
                0f, -1f, 0f, 0f, 255f,
                0f, 0f, -1f, 0f, 255f,
                0f, 0f, 0f, 1f, 0f
            )))
            "Sepia" -> ColorFilter.colorMatrix(ColorMatrix(floatArrayOf(
                0.393f, 0.769f, 0.189f, 0f, 0f,
                0.349f, 0.686f, 0.168f, 0f, 0f,
                0.272f, 0.534f, 0.131f, 0f, 0f,
                0f, 0f, 0f, 1f, 0f
            )))
            "Warm" -> ColorFilter.colorMatrix(ColorMatrix(floatArrayOf(
                1.0f, 0f, 0f, 0f, 10f,
                0f, 0.95f, 0f, 0f, 5f,
                0f, 0f, 0.85f, 0f, 0f,
                0f, 0f, 0f, 1f, 0f
            )))
            else -> null
        }
    }

    if (bitmap != null) {
        Image(
            bitmap = bitmap!!.asImageBitmap(),
            contentDescription = "Page ${pageIndex + 1}",
            modifier = Modifier
                .fillMaxWidth()
                .wrapContentHeight()
                .testTag("pdf_page_${pageIndex}"),
            contentScale = ContentScale.Fit,
            colorFilter = colorFilter
        )
    } else {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(450.dp),
            contentAlignment = Alignment.Center
        ) {
            CircularProgressIndicator(color = KageNeonBlue)
        }
    }
}

@Composable
fun PdfWebView(
    url: String,
    modifier: Modifier = Modifier
) {
    var webViewLoadingProgress by remember { mutableIntStateOf(0) }
    var isWebViewLoading by remember { mutableStateOf(true) }

    // Safety timeout: dismiss loading state after 5 seconds to ensure reader content is always visible
    LaunchedEffect(isWebViewLoading) {
        if (isWebViewLoading) {
            kotlinx.coroutines.delay(5000L)
            isWebViewLoading = false
        }
    }

    Box(modifier = modifier.fillMaxSize()) {
        AndroidView(
            factory = { context ->
                WebView(context).apply {
                    layoutParams = ViewGroup.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                    webViewClient = object : WebViewClient() {
                        override fun onPageStarted(view: WebView?, url: String?, favicon: android.graphics.Bitmap?) {
                            super.onPageStarted(view, url, favicon)
                            // Only trigger full loading state for Google Gview frames to avoid trackers locking the screen
                            if (url != null && url.contains("docs.google.com/gview")) {
                                isWebViewLoading = true
                            }
                        }

                        override fun onPageFinished(view: WebView?, url: String?) {
                            super.onPageFinished(view, url)
                            isWebViewLoading = false
                        }

                        override fun shouldOverrideUrlLoading(view: WebView?, request: android.webkit.WebResourceRequest?): Boolean {
                            return false // Handle within webview
                        }
                    }
                    webChromeClient = object : WebChromeClient() {
                        override fun onProgressChanged(view: WebView?, newProgress: Int) {
                            super.onProgressChanged(view, newProgress)
                            webViewLoadingProgress = newProgress
                            // Substantial layout loads by 75%, dismiss loading overlay early
                            if (newProgress >= 75) {
                                isWebViewLoading = false
                            }
                        }
                    }
                    settings.apply {
                        javaScriptEnabled = true
                        domStorageEnabled = true
                        useWideViewPort = true
                        loadWithOverviewMode = true
                        builtInZoomControls = true
                        displayZoomControls = false
                        setSupportZoom(true)
                    }
                }
            },
            update = { webView ->
                val googleDocsUrl = "https://docs.google.com/gview?embedded=true&url=${java.net.URLEncoder.encode(url, "UTF-8")}"
                if (webView.url != googleDocsUrl) {
                    webView.loadUrl(googleDocsUrl)
                }
            },
            modifier = Modifier.fillMaxSize()
        )

        if (isWebViewLoading) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .background(KageBlack.copy(alpha = 0.8f)),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                if (webViewLoadingProgress in 1..99) {
                    CircularProgressIndicator(
                        progress = webViewLoadingProgress / 100f,
                        color = KageNeonBlue,
                        modifier = Modifier.size(64.dp)
                    )
                } else {
                    CircularProgressIndicator(
                        color = KageNeonBlue,
                        modifier = Modifier.size(64.dp)
                    )
                }
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = "Streaming PDF via Cloud... ${webViewLoadingProgress}%",
                    color = KageWhite,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Powered by secure document stream engine",
                    color = KageGray,
                    fontSize = 11.sp
                )
            }
        }
    }
}
