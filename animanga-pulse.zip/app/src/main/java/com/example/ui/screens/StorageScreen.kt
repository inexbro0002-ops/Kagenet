package com.example.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.KageViewModel
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StorageScreen(
    viewModel: KageViewModel,
    onNavigateBack: () -> Unit
) {
    val dbSize by viewModel.storageDbSize.collectAsStateWithLifecycle()
    val cacheSize by viewModel.storageCacheSize.collectAsStateWithLifecycle()
    val downloadSize by viewModel.storageDownloadSize.collectAsStateWithLifecycle()
    val totalSize by viewModel.storageTotalSize.collectAsStateWithLifecycle()
    val freeSize by viewModel.storageFreeSize.collectAsStateWithLifecycle()

    val currentDbVersion by viewModel.currentDbVersion.collectAsStateWithLifecycle()
    val lastSync by viewModel.lastSyncTime.collectAsStateWithLifecycle()
    val downloads by viewModel.downloadsState.collectAsStateWithLifecycle()

    val downloadedAnimeCount = downloads.filter { it.fileType == "mp4" && it.status == "completed" }.size
    val downloadedMangaCount = downloads.filter { it.fileType == "pdf" && it.status == "completed" }.size

    val lastSyncDateStr = if (lastSync > 0) {
        val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
        sdf.format(Date(lastSync))
    } else {
        "Never"
    }

    // Trigger update on open
    LaunchedEffect(Unit) {
        viewModel.calculateStorageMetrics()
    }

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text("Storage Manager", fontWeight = FontWeight.Bold, color = KageWhite) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack, modifier = Modifier.minimumInteractiveComponentSize()) {
                        Icon(Icons.Filled.ArrowBack, "Back", tint = KageWhite)
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = KageDeepAbyss,
                    titleContentColor = KageWhite
                )
            )
        },
        containerColor = KageDeepAbyss
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 1. Dashboard Overview Card
            Card(
                colors = CardDefaults.cardColors(containerColor = KageDarkCard),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(0.5.dp, Color(0x3300D2FF), RoundedCornerShape(20.dp))
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        text = "TOTAL KAGENET USE",
                        color = KageNeonBlue,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.5.sp
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = totalSize,
                        color = KageWhite,
                        fontSize = 32.sp,
                        fontWeight = FontWeight.ExtraBold
                    )
                    Text(
                        text = "Available device space: $freeSize",
                        color = KageGray,
                        fontSize = 13.sp
                    )

                    Spacer(modifier = Modifier.height(20.dp))

                    // Custom Visual Storage Breakdown Gauge using Canvas
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(16.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0x22FFFFFF))
                    ) {
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            // Let's draw proportions
                            // Let's assume downloads are primary, cache secondary, database third.
                            // We will allocate simple fallback divisions or relative width bars
                            val totalWidth = size.width
                            val downloadBarWidth = totalWidth * 0.55f // Simulated representation for style
                            val cacheBarWidth = totalWidth * 0.25f
                            val dbBarWidth = totalWidth * 0.1f

                            // Draw DB bar
                            drawRect(
                                color = KageNeonBlue,
                                size = size.copy(width = dbBarWidth)
                            )
                            // Draw Cache bar
                            drawRect(
                                color = KageOrange,
                                topLeft = Offset(dbBarWidth, 0f),
                                size = size.copy(width = cacheBarWidth)
                            )
                            // Draw Downloads bar
                            drawRect(
                                color = KageGreen,
                                topLeft = Offset(dbBarWidth + cacheBarWidth, 0f),
                                size = size.copy(width = downloadBarWidth)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Legend details
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        LegendItem(color = KageNeonBlue, name = "Database", size = dbSize)
                        LegendItem(color = KageOrange, name = "Caches", size = cacheSize)
                        LegendItem(color = KageGreen, name = "Downloads", size = downloadSize)
                    }
                }
            }

            // 2. Statistics breakdown
            Text(
                text = "File Statistics",
                color = KageWhite,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(top = 8.dp)
            )

            Card(
                colors = CardDefaults.cardColors(containerColor = KageDarkCard),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(0.5.dp, Color(0x1100D2FF), RoundedCornerShape(16.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    StatisticRow(icon = Icons.Filled.VideoLibrary, label = "Downloaded Anime Episodes", value = "$downloadedAnimeCount files")
                    Divider(color = Color(0x1100D2FF))
                    StatisticRow(icon = Icons.Filled.MenuBook, label = "Downloaded Manga Chapters", value = "$downloadedMangaCount files")
                    Divider(color = Color(0x1100D2FF))
                    StatisticRow(icon = Icons.Filled.Layers, label = "Current Cache Sync Version", value = "v$currentDbVersion")
                    Divider(color = Color(0x1100D2FF))
                    StatisticRow(icon = Icons.Filled.CalendarToday, label = "Last Synchronized Date", value = lastSyncDateStr)
                }
            }

            // 3. Command operations
            Text(
                text = "Storage Operations",
                color = KageWhite,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(top = 8.dp)
            )

            // Dynamic action buttons
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                // Sync Database
                Button(
                    onClick = { viewModel.syncDatabaseNow() },
                    colors = ButtonDefaults.buttonColors(containerColor = KageNeonBlue, contentColor = KageBlack),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("action_sync_db")
                ) {
                    Icon(Icons.Filled.Sync, "Sync")
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Sync Remote Database", fontWeight = FontWeight.Bold)
                }

                // Clear Cache
                OutlinedButton(
                    onClick = { viewModel.clearCache() },
                    border = BorderStroke(1.dp, KageOrange),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = KageOrange),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("action_clear_cache")
                ) {
                    Icon(Icons.Filled.CleaningServices, "Cleaning")
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Clear JSON Local Cache", fontWeight = FontWeight.Bold)
                }

                // Delete Anime Downloads
                OutlinedButton(
                    onClick = { viewModel.deleteAnimeDownloads() },
                    border = BorderStroke(1.dp, Color(0xFFE57373)),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFE57373)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("action_delete_anime")
                ) {
                    Icon(Icons.Filled.DeleteOutline, "Delete Videos")
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Delete Anime Downloads (.MP4)", fontWeight = FontWeight.Bold)
                }

                // Delete Manga Downloads
                OutlinedButton(
                    onClick = { viewModel.deleteMangaDownloads() },
                    border = BorderStroke(1.dp, Color(0xFFE57373)),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFE57373)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("action_delete_manga")
                ) {
                    Icon(Icons.Filled.DeleteOutline, "Delete Chapters")
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Delete Manga Downloads (.PDF)", fontWeight = FontWeight.Bold)
                }

                // Delete All Downloads
                Button(
                    onClick = { viewModel.deleteAllDownloads() },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE53935), contentColor = KageWhite),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("action_delete_all")
                ) {
                    Icon(Icons.Filled.DeleteForever, "Delete All")
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Delete All Downloaded Files", fontWeight = FontWeight.Bold)
                }
            }
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
fun LegendItem(color: Color, name: String, size: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(10.dp)
                .clip(RoundedCornerShape(2.dp))
                .background(color)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Column {
            Text(name, color = KageGray, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            Text(size, color = KageWhite, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun StatisticRow(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, "Stat Icon", tint = KageNeonBlue, modifier = Modifier.size(20.dp))
        Spacer(modifier = Modifier.width(12.dp))
        Text(label, color = KageWhite, fontSize = 13.sp, modifier = Modifier.weight(1f))
        Text(value, color = KageGray, fontSize = 13.sp, fontWeight = FontWeight.Bold)
    }
}
