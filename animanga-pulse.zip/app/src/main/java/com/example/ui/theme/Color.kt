package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Sophisticated Dark design theme colors matching the Kage Net screenshot
val KageBlack = Color(0xFF020813)      // Immersive midnight blue `#020813`
val KageDarkSpace = Color(0xFF051126)  // Sleek dark navy surface for tabs/menus
val KageDarkCard = Color(0xFF0A192F)   // Dark navy semi-transparent card background
val KageNeonBlue = Color(0xFF0084FF)   // Vivid royal/neon blue accent `#0084ff`
val KageBlueGlow = Color(0xFF005BC2)   // Vibrant deep ocean blue `#005bc2`
val KageDeepAbyss = Color(0xFF010610)  // Deepest midnight blue background `#010610`
val KageGray = Color(0xFF707D93)       // Muted slate gray/blue `#707d93`
val KageWhite = Color(0xFFFFFFFF)      // Pure white text and icons
val KageGreen = Color(0xFF4ADE80)      // Sleek mint green for sync ready/success `#4ade80`
val KageOrange = Color(0xFF0084FF)     // Modern blue accents for ratings
