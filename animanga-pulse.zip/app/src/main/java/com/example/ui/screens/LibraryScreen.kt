package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.example.data.Anime
import com.example.data.Manga
import com.example.ui.KageViewModel
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LibraryScreen(
    viewModel: KageViewModel,
    onNavigateToAnime: (String) -> Unit,
    onNavigateToManga: (String) -> Unit,
    onNavigateToPlayer: (String, Int, Boolean) -> Unit,
    onNavigateToReader: (String, Int) -> Unit
) {
    var selectedTab by remember { mutableStateOf(0) }
    val tabs = listOf("Anime", "Manga", "Offline Manga", "Downloads")

    val database by viewModel.databaseState.collectAsStateWithLifecycle()
    val favorites by viewModel.favoritesState.collectAsStateWithLifecycle()
    val watchLater by viewModel.watchLaterState.collectAsStateWithLifecycle()
    val readingList by viewModel.readingListState.collectAsStateWithLifecycle()
    val continueWatching by viewModel.continueWatchingState.collectAsStateWithLifecycle()
    val continueReading by viewModel.continueReadingState.collectAsStateWithLifecycle()
    val downloads by viewModel.downloadsState.collectAsStateWithLifecycle()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("My Library", fontWeight = FontWeight.Bold, color = KageWhite, modifier = Modifier.padding(start = 4.dp)) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = KageDeepAbyss,
                    titleContentColor = KageWhite
                )
            )
        },
        containerColor = KageDeepAbyss
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Segmented Tab Row
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = KageDeepAbyss,
                contentColor = MaterialTheme.colorScheme.primary,
                indicator = { tabPositions ->
                    TabRowDefaults.Indicator(
                        modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                        color = MaterialTheme.colorScheme.primary
                    )
                },
                divider = { Divider(color = Color(0x1AFFFFFF)) }
            ) {
                tabs.forEachIndexed { index, title ->
                    Tab(
                        selected = selectedTab == index,
                        onClick = { selectedTab = index },
                        text = {
                            Text(
                                text = title,
                                fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Medium,
                                fontSize = 14.sp
                            )
                        },
                        selectedContentColor = MaterialTheme.colorScheme.primary,
                        unselectedContentColor = KageGray
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            when (selectedTab) {
                0 -> {
                    // Anime Tab
                    val libraryAnimeList = remember(database, favorites, watchLater, continueWatching) {
                        val animeIds = (favorites.filter { it.itemType == "anime" }.map { it.itemId } +
                                watchLater.map { it.animeId } +
                                continueWatching.map { it.animeId }).distinct()

                        database.anime.filter { it.id in animeIds }
                    }

                    if (libraryAnimeList.isEmpty()) {
                        EmptyLibraryState(
                            icon = Icons.Filled.PlayCircle,
                            message = "Your Anime Library is empty.\nAdd shows to Favorites or Watch Later to see them here!"
                        )
                    } else {
                        LazyColumn(
                            contentPadding = PaddingValues(16.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp),
                            modifier = Modifier.testTag("library_anime_list")
                        ) {
                            items(libraryAnimeList) { anime ->
                                val cw = continueWatching.find { it.animeId == anime.id }
                                val progress = if (cw != null && anime.episodes.isNotEmpty()) {
                                    (cw.episodeIndex + 1).toFloat() / anime.episodes.size
                                } else if (favorites.any { it.itemId == anime.id }) {
                                    1.0f
                                } else {
                                    0.0f
                                }

                                val subtitle = if (cw != null && anime.episodes.isNotEmpty()) {
                                    "${cw.episodeIndex + 1}/${anime.episodes.size} • Watching"
                                } else if (favorites.any { it.itemId == anime.id }) {
                                    "${anime.episodes.size}/${anime.episodes.size} • Completed"
                                } else {
                                    "Plan to Watch"
                                }

                                LibraryItemRow(
                                    title = anime.title,
                                    subtitle = subtitle,
                                    imageUrl = anime.cover,
                                    progress = progress,
                                    onClick = { onNavigateToAnime(anime.id) },
                                    onMoreClick = { viewModel.toggleWatchLater(anime.id) }
                                )
                            }
                        }
                    }
                }
                1 -> {
                    // Manga Tab
                    val libraryMangaList = remember(database, favorites, readingList, continueReading) {
                        val mangaIds = (favorites.filter { it.itemType == "manga" }.map { it.itemId } +
                                readingList.map { it.mangaId } +
                                continueReading.map { it.mangaId }).distinct()

                        database.manga.filter { it.id in mangaIds }
                    }

                    if (libraryMangaList.isEmpty()) {
                        EmptyLibraryState(
                            icon = Icons.Filled.Book,
                            message = "Your Manga Library is empty.\nAdd manga to Favorites or Reading List to see them here!"
                        )
                    } else {
                        LazyColumn(
                            contentPadding = PaddingValues(16.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp),
                            modifier = Modifier.testTag("library_manga_list")
                        ) {
                            items(libraryMangaList) { manga ->
                                val cr = continueReading.find { it.mangaId == manga.id }
                                val progress = if (cr != null && manga.chapters.isNotEmpty()) {
                                    (cr.chapterIndex + 1).toFloat() / manga.chapters.size
                                } else if (favorites.any { it.itemId == manga.id }) {
                                    1.0f
                                } else {
                                    0.0f
                                }

                                val subtitle = if (cr != null && manga.chapters.isNotEmpty()) {
                                    "Ch. ${cr.chapterIndex + 1}/${manga.chapters.size} • Reading"
                                } else if (favorites.any { it.itemId == manga.id }) {
                                    "Ch. ${manga.chapters.size}/${manga.chapters.size} • Completed"
                                } else {
                                    "Plan to Read"
                                }

                                LibraryItemRow(
                                    title = manga.title,
                                    subtitle = subtitle,
                                    imageUrl = manga.cover,
                                    progress = progress,
                                    onClick = { onNavigateToManga(manga.id) },
                                    onMoreClick = { viewModel.toggleReadingList(manga.id) }
                                )
                            }
                        }
                    }
                }
                2 -> {
                    // Offline Manga / PDFs Tab
                    val offlinePdfs = remember(downloads) {
                        downloads.filter { it.fileType == "pdf" && it.status == "completed" }
                    }

                    if (offlinePdfs.isEmpty()) {
                        EmptyLibraryState(
                            icon = Icons.Filled.Book,
                            message = "No downloaded manga found.\nDownload chapters to read offline in PDF format!"
                        )
                    } else {
                        LazyColumn(
                            contentPadding = PaddingValues(16.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp),
                            modifier = Modifier.testTag("library_offline_manga_list")
                        ) {
                            items(offlinePdfs) { download ->
                                val manga = database.manga.find { it.id == download.mangaId }
                                val coverUrl = manga?.cover ?: ""
                                
                                Card(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .border(0.5.dp, Color(0x1AFFFFFF), RoundedCornerShape(12.dp))
                                        .clickable {
                                            if (download.mangaId != null && download.chapterIndex != null) {
                                                onNavigateToReader(download.mangaId, download.chapterIndex)
                                            }
                                        },
                                    colors = CardDefaults.cardColors(containerColor = KageDarkCard)
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(10.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Card(
                                            shape = RoundedCornerShape(8.dp),
                                            modifier = Modifier.size(50.dp, 70.dp)
                                        ) {
                                            if (coverUrl.isNotEmpty()) {
                                                AsyncImage(
                                                    model = coverUrl,
                                                    contentDescription = download.title,
                                                    modifier = Modifier.fillMaxSize(),
                                                    contentScale = ContentScale.Crop
                                                )
                                            } else {
                                                Box(
                                                    modifier = Modifier
                                                        .fillMaxSize()
                                                        .background(KageBlack),
                                                    contentAlignment = Alignment.Center
                                                ) {
                                                    Icon(Icons.Filled.Book, "Cover placeholder", tint = KageGray)
                                                }
                                            }
                                        }

                                        Spacer(modifier = Modifier.width(16.dp))

                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = download.title,
                                                color = KageWhite,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 14.sp,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                            Spacer(modifier = Modifier.height(4.dp))
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Box(
                                                    modifier = Modifier
                                                        .background(KageNeonBlue.copy(alpha = 0.15f), RoundedCornerShape(4.dp))
                                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                                ) {
                                                    Text(
                                                        text = "OFFLINE",
                                                        color = KageNeonBlue,
                                                        fontSize = 9.sp,
                                                        fontWeight = FontWeight.Bold
                                                    )
                                                }
                                                if (download.sizeBytes > 0) {
                                                    Spacer(modifier = Modifier.width(8.dp))
                                                    Text(
                                                        text = formatBytes(download.sizeBytes),
                                                        color = KageGray,
                                                        fontSize = 11.sp
                                                    )
                                                }
                                            }
                                        }

                                        IconButton(onClick = { viewModel.deleteDownload(download.downloadId) }) {
                                            Icon(Icons.Filled.Delete, "Delete Offline Chapter", tint = Color.Red.copy(alpha = 0.7f))
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                3 -> {
                    // Downloads Tab
                    if (downloads.isEmpty()) {
                        EmptyLibraryState(
                            icon = Icons.Filled.Download,
                            message = "No active or completed downloads found.\nDownload episodes or chapters for offline use!"
                        )
                    } else {
                        LazyColumn(
                            contentPadding = PaddingValues(16.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp),
                            modifier = Modifier.testTag("library_downloads_list")
                        ) {
                            items(downloads) { download ->
                                val progress = if (download.sizeBytes > 0) {
                                    download.downloadedBytes.toFloat() / download.sizeBytes
                                } else {
                                    0.0f
                                }

                                val statusText = when (download.status) {
                                    "completed" -> "Offline Available"
                                    "downloading" -> "Downloading (${download.progress}%)"
                                    "paused" -> "Paused"
                                    "failed" -> "Failed"
                                    else -> "Queued"
                                }

                                Card(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .border(0.5.dp, Color(0x1AFFFFFF), RoundedCornerShape(12.dp))
                                        .clickable {
                                            if (download.status == "completed") {
                                                if (download.fileType == "pdf" && download.mangaId != null && download.chapterIndex != null) {
                                                    onNavigateToReader(download.mangaId, download.chapterIndex)
                                                } else if (download.fileType == "mp4" && download.animeId != null && download.episodeIndex != null) {
                                                    onNavigateToPlayer(download.animeId, download.episodeIndex, true)
                                                }
                                            }
                                        },
                                    colors = CardDefaults.cardColors(containerColor = KageDarkCard)
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(12.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(
                                            imageVector = if (download.fileType == "mp4") Icons.Filled.VideoLibrary else Icons.Filled.MenuBook,
                                            contentDescription = "File type",
                                            tint = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.size(24.dp)
                                        )
                                        Spacer(modifier = Modifier.width(16.dp))
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = download.title,
                                                color = KageWhite,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 14.sp,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                            Spacer(modifier = Modifier.height(2.dp))
                                            Text(
                                                text = statusText,
                                                color = if (download.status == "completed") KageGreen else KageGray,
                                                fontSize = 11.sp
                                            )
                                            if (download.status == "downloading" || download.status == "paused") {
                                                Spacer(modifier = Modifier.height(6.dp))
                                                LinearProgressIndicator(
                                                    progress = progress,
                                                    color = MaterialTheme.colorScheme.primary,
                                                    trackColor = Color(0x1AFFFFFF),
                                                    modifier = Modifier
                                                        .fillMaxWidth()
                                                        .height(3.dp)
                                                        .clip(RoundedCornerShape(2.dp))
                                                )
                                            }
                                        }
                                        IconButton(onClick = { viewModel.deleteDownload(download.downloadId) }) {
                                            Icon(Icons.Filled.Delete, "Delete Download", tint = Color.Red.copy(alpha = 0.7f))
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun LibraryItemRow(
    title: String,
    subtitle: String,
    imageUrl: String,
    progress: Float,
    onClick: () -> Unit,
    onMoreClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(0.5.dp, Color(0x1AFFFFFF), RoundedCornerShape(12.dp))
            .clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = KageDarkCard)
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Card(
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.size(50.dp, 70.dp)
                ) {
                    AsyncImage(
                        model = imageUrl,
                        contentDescription = title,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                }

                Spacer(modifier = Modifier.width(16.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = title,
                        color = KageWhite,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = subtitle,
                        color = KageGray,
                        fontSize = 12.sp
                    )
                }

                IconButton(onClick = onMoreClick) {
                    Icon(Icons.Filled.MoreVert, "More Options", tint = KageGray)
                }
            }

            if (progress > 0.0f) {
                Spacer(modifier = Modifier.height(8.dp))
                LinearProgressIndicator(
                    progress = progress,
                    color = MaterialTheme.colorScheme.primary,
                    trackColor = Color(0x1AFFFFFF),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(3.dp)
                        .clip(RoundedCornerShape(2.dp))
                )
            }
        }
    }
}

@Composable
fun EmptyLibraryState(icon: androidx.compose.ui.graphics.vector.ImageVector, message: String) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = KageGray.copy(alpha = 0.4f),
                modifier = Modifier.size(64.dp)
            )
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = message,
                color = KageGray,
                fontSize = 14.sp,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                lineHeight = 20.sp
            )
        }
    }
}

fun formatBytes(bytes: Long): String {
    if (bytes <= 0) return "0 B"
    val units = arrayOf("B", "KB", "MB", "GB")
    val digitGroups = (Math.log10(bytes.toDouble()) / Math.log10(1024.0)).toInt()
    return java.text.DecimalFormat("#,##0.#").format(bytes / Math.pow(1024.0, digitGroups.toDouble())) + " " + units[digitGroups]
}
