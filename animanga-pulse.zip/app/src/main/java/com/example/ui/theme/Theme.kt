package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true, // Force premium black theme by default
    content: @Composable () -> Unit
) {
    val colorScheme = darkColorScheme(
        primary = KageNeonBlue,
        onPrimary = KageBlack,
        primaryContainer = KageBlueGlow,
        onPrimaryContainer = KageWhite,
        secondary = KageBlueGlow,
        onSecondary = KageWhite,
        tertiary = KageGreen,
        onTertiary = KageBlack,
        background = KageDeepAbyss,
        onBackground = KageWhite,
        surface = KageDarkSpace,
        onSurface = KageWhite,
        surfaceVariant = KageDarkCard,
        onSurfaceVariant = KageWhite,
        outline = KageNeonBlue
    )

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
