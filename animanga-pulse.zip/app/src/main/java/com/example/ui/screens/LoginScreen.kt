package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import com.example.ui.KageViewModel
import com.example.ui.theme.KageDeepAbyss

@Composable
fun LoginScreen(
    viewModel: KageViewModel,
    onLoginSuccess: () -> Unit
) {
    Scaffold(
        containerColor = KageDeepAbyss
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(KageDeepAbyss),
            contentAlignment = Alignment.Center
        ) {
            LoginRegisterForm(onRegister = { username, email, avatar ->
                viewModel.registerOrLogin(username, email, avatar)
                onLoginSuccess()
            })
        }
    }
}
