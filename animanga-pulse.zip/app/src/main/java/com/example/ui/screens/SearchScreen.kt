package com.example.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.layout.ContentScale
import coil.compose.AsyncImage
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.KageViewModel
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SearchScreen(
    viewModel: KageViewModel,
    onNavigateToAnime: (String) -> Unit,
    onNavigateToManga: (String) -> Unit
) {
    val query by viewModel.searchQuery.collectAsStateWithLifecycle()
    val category by viewModel.searchCategory.collectAsStateWithLifecycle()
    val selectedGenreState by viewModel.selectedGenre.collectAsStateWithLifecycle()
    val selectedYearState by viewModel.selectedYear.collectAsStateWithLifecycle()
    val selectedStatusState by viewModel.selectedStatus.collectAsStateWithLifecycle()

    val animeResults by viewModel.filteredAnime.collectAsStateWithLifecycle()
    val mangaResults by viewModel.filteredManga.collectAsStateWithLifecycle()

    val allGenres by viewModel.allGenres.collectAsStateWithLifecycle()
    val allYears by viewModel.allYears.collectAsStateWithLifecycle()

    val statuses = listOf("Ongoing", "Completed")

    Scaffold(
        topBar = {
            Column(
                modifier = Modifier
                    .background(KageDeepAbyss)
                    .padding(top = 12.dp)
            ) {
                // Search Input Field
                OutlinedTextField(
                    value = query,
                    onValueChange = { viewModel.searchQuery.value = it },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp)
                        .testTag("search_input_field"),
                    placeholder = { Text("Search title, studios, descriptions...", color = KageGray) },
                    leadingIcon = { Icon(Icons.Filled.Search, "Search Icon", tint = KageNeonBlue) },
                    trailingIcon = {
                        if (query.isNotEmpty()) {
                            IconButton(onClick = { viewModel.searchQuery.value = "" }) {
                                Icon(Icons.Filled.Close, "Clear query", tint = KageGray)
                            }
                        }
                    },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = KageWhite,
                        unfocusedTextColor = KageWhite,
                        focusedBorderColor = KageNeonBlue,
                        unfocusedBorderColor = Color(0x1AFFFFFF),
                        focusedContainerColor = KageDarkSpace,
                        unfocusedContainerColor = KageDarkSpace,
                        cursorColor = KageNeonBlue
                    ),
                    shape = RoundedCornerShape(16.dp),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Category Switcher Rows (All, Anime, Manga)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf("All", "Anime", "Manga").forEach { cat ->
                        val isSelected = category == cat
                        Button(
                            onClick = { viewModel.searchCategory.value = cat },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isSelected) KageNeonBlue else KageDarkCard,
                                contentColor = if (isSelected) KageBlack else KageWhite
                            ),
                            border = if (!isSelected) BorderStroke(0.5.dp, Color(0x1AFFFFFF)) else null,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(38.dp)
                                .testTag("search_cat_${cat}")
                        ) {
                            Text(cat, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Scrollable filters (Genre, Year, Status)
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    // Genre reset button
                    if (selectedGenreState != null || selectedYearState != null || selectedStatusState != null) {
                        item {
                            FilterChip(
                                selected = false,
                                onClick = {
                                    viewModel.selectedGenre.value = null
                                    viewModel.selectedYear.value = null
                                    viewModel.selectedStatus.value = null
                                },
                                label = { Text("Clear Filters", color = KageNeonBlue) },
                                leadingIcon = { Icon(Icons.Filled.Close, "Reset Filters", modifier = Modifier.size(16.dp)) },
                                colors = FilterChipDefaults.filterChipColors(containerColor = KageDarkCard)
                            )
                        }
                    }

                    // Genre Filters list
                    items(allGenres) { genre ->
                        val isSelected = selectedGenreState == genre
                        FilterChip(
                            selected = isSelected,
                            onClick = {
                                viewModel.selectedGenre.value = if (isSelected) null else genre
                            },
                            label = { Text(genre, color = if (isSelected) KageBlack else KageWhite) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = KageNeonBlue,
                                containerColor = KageDarkCard
                            ),
                            border = FilterChipDefaults.filterChipBorder(
                                enabled = true,
                                selected = isSelected,
                                borderColor = Color(0x1AFFFFFF),
                                selectedBorderColor = KageNeonBlue
                            )
                        )
                    }

                    // Year Filters list
                    items(allYears) { year ->
                        val isSelected = selectedYearState == year
                        FilterChip(
                            selected = isSelected,
                            onClick = {
                                viewModel.selectedYear.value = if (isSelected) null else year
                            },
                            label = { Text(year.toString(), color = if (isSelected) KageBlack else KageWhite) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = KageNeonBlue,
                                containerColor = KageDarkCard
                            ),
                            border = FilterChipDefaults.filterChipBorder(
                                enabled = true,
                                selected = isSelected,
                                borderColor = Color(0x1AFFFFFF),
                                selectedBorderColor = KageNeonBlue
                            )
                        )
                    }

                    // Status filter chips
                    items(statuses) { status ->
                        val isSelected = selectedStatusState == status
                        FilterChip(
                            selected = isSelected,
                            onClick = {
                                viewModel.selectedStatus.value = if (isSelected) null else status
                            },
                            label = { Text(status, color = if (isSelected) KageBlack else KageWhite) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = KageNeonBlue,
                                containerColor = KageDarkCard
                            ),
                            border = FilterChipDefaults.filterChipBorder(
                                enabled = true,
                                selected = isSelected,
                                borderColor = Color(0x1AFFFFFF),
                                selectedBorderColor = KageNeonBlue
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))
                Divider(color = Color(0x1AFFFFFF), thickness = 1.dp)
            }
        },
        containerColor = KageDeepAbyss
    ) { innerPadding ->
        val resultsCombined = mutableListOf<Any>()
        if (category == "All" || category == "Anime") {
            resultsCombined.addAll(animeResults)
        }
        if (category == "All" || category == "Manga") {
            resultsCombined.addAll(mangaResults)
        }

        if (resultsCombined.isEmpty()) {
            // Empty State
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(24.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.FilterList,
                        contentDescription = "Empty Search",
                        tint = KageNeonBlue,
                        modifier = Modifier.size(64.dp)
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "No results found",
                        color = KageWhite,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Try adjusting your search keywords, genres, or switching categories.",
                        color = KageGray,
                        fontSize = 13.sp,
                        textAlign = TextAlign.Center
                    )
                }
            }
        } else {
            // Grid results
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .testTag("search_results_grid"),
                contentPadding = PaddingValues(16.dp),
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                items(resultsCombined) { item ->
                    when (item) {
                        is com.example.data.Anime -> {
                            SearchGridItem(
                                title = item.title,
                                coverUrl = item.cover,
                                rating = item.rating,
                                label = "ANIME",
                                onClick = { onNavigateToAnime(item.id) }
                            )
                        }
                        is com.example.data.Manga -> {
                            SearchGridItem(
                                title = item.title,
                                coverUrl = item.cover,
                                rating = item.rating,
                                label = "MANGA",
                                onClick = { onNavigateToManga(item.id) }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SearchGridItem(
    title: String,
    coverUrl: String,
    rating: Double,
    label: String,
    onClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .clip(RoundedCornerShape(16.dp))
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(200.dp)
                .background(KageDarkCard)
                .border(1.dp, Color(0x1AFFFFFF), RoundedCornerShape(16.dp))
        ) {
            AsyncImage(
                model = coverUrl,
                contentDescription = title,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )

            // Rating Overlay
            Box(
                modifier = Modifier
                    .padding(8.dp)
                    .background(Color.Black.copy(alpha = 0.6f), RoundedCornerShape(6.dp))
                    .border(0.5.dp, Color(0x4D38BDF8), RoundedCornerShape(6.dp))
                    .padding(horizontal = 6.dp, vertical = 2.dp)
                    .align(Alignment.TopEnd)
            ) {
                Text(
                    text = "$rating ★",
                    color = KageNeonBlue,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            // Category Label Overlay (Anime or Manga)
            Box(
                modifier = Modifier
                    .padding(8.dp)
                    .background(
                        if (label == "ANIME") Color(0xE638BDF8) else Color(0xE610B981),
                        RoundedCornerShape(6.dp)
                    )
                    .padding(horizontal = 8.dp, vertical = 4.dp)
                    .align(Alignment.BottomStart)
            ) {
                Text(
                    text = label,
                    color = KageBlack,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = title,
            color = KageWhite,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(horizontal = 4.dp)
        )
    }
}
