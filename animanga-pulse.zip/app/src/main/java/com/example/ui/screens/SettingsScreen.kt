package com.example.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import android.content.Intent
import android.net.Uri
import androidx.compose.ui.platform.LocalContext
import com.example.ui.KageViewModel
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    viewModel: KageViewModel,
    onNavigateToStorageManager: () -> Unit
) {
    val context = LocalContext.current
    val isSyncing by viewModel.isSyncing.collectAsStateWithLifecycle()
    val lastSync by viewModel.lastSyncTime.collectAsStateWithLifecycle()
    val dbVersion by viewModel.currentDbVersion.collectAsStateWithLifecycle()
    val darkTheme by viewModel.darkThemeState.collectAsStateWithLifecycle()

    var showAboutDialog by remember { mutableStateOf(false) }
    var showPrivacyDialog by remember { mutableStateOf(false) }
    var showTermsDialog by remember { mutableStateOf(false) }

    val lastSyncDateStr = if (lastSync > 0) {
        val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
        sdf.format(Date(lastSync))
    } else {
        "Never"
    }

    // Rotation animation for sync icon when syncing
    val infiniteTransition = rememberInfiniteTransition(label = "SyncRotate")
    val rotationAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "Rotation"
    )

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text("Kage Settings", fontWeight = FontWeight.Bold, color = KageWhite) },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = KageDeepAbyss,
                    titleContentColor = KageWhite
                )
            )
        },
        containerColor = KageDeepAbyss
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Section 1: Connection & Syncing
            SettingsHeader("Syncing & Server")

            Card(
                colors = CardDefaults.cardColors(containerColor = KageDarkCard),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(0.5.dp, Color(0x1100D2FF), RoundedCornerShape(16.dp))
            ) {
                Column {
                    // Sync Now Button Row
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { viewModel.syncDatabaseNow() }
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Sync,
                            contentDescription = "Sync Now",
                            tint = KageNeonBlue,
                            modifier = Modifier
                                .size(24.dp)
                                .rotate(if (isSyncing) rotationAngle else 0f)
                        )
                        Spacer(modifier = Modifier.width(16.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Sync Database Now", fontWeight = FontWeight.Bold, color = KageWhite)
                            Text("Pulls the latest remote database.json and version.json.", color = KageGray, fontSize = 11.sp)
                        }
                        if (isSyncing) {
                            CircularProgressIndicator(modifier = Modifier.size(20.dp), color = KageNeonBlue, strokeWidth = 2.dp)
                        } else {
                            Icon(Icons.Filled.ChevronRight, "Arrow", tint = KageGray)
                        }
                    }

                    Divider(color = Color(0x1100D2FF))

                    // Sync details row
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Filled.Info, "Info", tint = KageGray, modifier = Modifier.size(24.dp))
                        Spacer(modifier = Modifier.width(16.dp))
                        Column {
                            Text("Database Version: v$dbVersion", color = KageWhite, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                            Text("Last Synced: $lastSyncDateStr", color = KageGray, fontSize = 11.sp)
                        }
                    }
                }
            }

            // Section 2: Storage & Files
            SettingsHeader("Storage & Management")

            Card(
                colors = CardDefaults.cardColors(containerColor = KageDarkCard),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(0.5.dp, Color(0x1100D2FF), RoundedCornerShape(16.dp))
            ) {
                Column {
                    // Storage manager Row
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable(onClick = onNavigateToStorageManager)
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Filled.PieChart, "Storage Analytics", tint = KageNeonBlue, modifier = Modifier.size(24.dp))
                        Spacer(modifier = Modifier.width(16.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Storage Manager Dashboard", fontWeight = FontWeight.Bold, color = KageWhite)
                            Text("Review local sizes, clear cache, delete downloaded videos.", color = KageGray, fontSize = 11.sp)
                        }
                        Icon(Icons.Filled.ChevronRight, "Arrow", tint = KageGray)
                    }

                    Divider(color = Color(0x1100D2FF))

                    // Clear Cache (safe deletion) Row
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { viewModel.clearCache() }
                            .padding(16.dp)
                            .testTag("clear_cache_settings"),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Filled.CleaningServices, "Clear Cache", tint = KageOrange, modifier = Modifier.size(24.dp))
                        Spacer(modifier = Modifier.width(16.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Clear JSON Cache Database", fontWeight = FontWeight.Bold, color = KageWhite)
                            Text("Safe: Erases downloaded JSON but NEVER deletes MP4/PDF files.", color = KageGray, fontSize = 11.sp)
                        }
                    }
                }
            }

            // Section 2.5: Database Curation
            SettingsHeader("Database Content Curation")

            val dbState by viewModel.databaseState.collectAsStateWithLifecycle()

            Card(
                colors = CardDefaults.cardColors(containerColor = KageDarkCard),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(0.5.dp, Color(0x1100D2FF), RoundedCornerShape(16.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Hero Section Banner",
                        color = KageWhite,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Select an anime to feature in the main home screen header:",
                        color = KageGray,
                        fontSize = 11.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    
                    val currentHero = dbState.anime.find { it.id == dbState.featured.firstOrNull() }
                    
                    var expandedHeroDropdown by remember { mutableStateOf(false) }
                    
                    Box(modifier = Modifier.fillMaxWidth()) {
                        OutlinedButton(
                            onClick = { expandedHeroDropdown = true },
                            modifier = Modifier.fillMaxWidth(),
                            border = BorderStroke(1.dp, KageNeonBlue),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = KageWhite)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = currentHero?.title ?: "Select Anime...",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Icon(Icons.Filled.ArrowDropDown, "Dropdown")
                            }
                        }
                        
                        DropdownMenu(
                            expanded = expandedHeroDropdown,
                            onDismissRequest = { expandedHeroDropdown = false },
                            modifier = Modifier
                                .background(KageDarkSpace)
                                .fillMaxWidth(0.9f)
                        ) {
                            dbState.anime.forEach { item ->
                                val isHero = item.id == dbState.featured.firstOrNull()
                                DropdownMenuItem(
                                    text = { 
                                        Text(
                                            item.title, 
                                            color = if (isHero) KageNeonBlue else KageWhite,
                                            fontWeight = if (isHero) FontWeight.Bold else FontWeight.Normal
                                        ) 
                                    },
                                    onClick = {
                                        viewModel.setHeroSection(item.id)
                                        expandedHeroDropdown = false
                                    }
                                )
                            }
                        }
                    }
                    
                    Spacer(modifier = Modifier.height(16.dp))
                    Divider(color = Color(0x1100D2FF))
                    Spacer(modifier = Modifier.height(16.dp))
                    
                    Text(
                        text = "Trending Animes",
                        color = KageWhite,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Toggle which animes appear in the Trending Section:",
                        color = KageGray,
                        fontSize = 11.sp
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    
                    Column(
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 220.dp)
                            .verticalScroll(rememberScrollState())
                    ) {
                        dbState.anime.forEach { item ->
                            val isTrending = dbState.trending.contains(item.id)
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(Color(0xFF0F172A).copy(alpha = 0.5f))
                                    .padding(horizontal = 12.dp, vertical = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = item.title,
                                    color = if (isTrending) KageNeonBlue else KageWhite,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.weight(1f)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Switch(
                                    checked = isTrending,
                                    onCheckedChange = { viewModel.toggleTrending(item.id) },
                                    colors = SwitchDefaults.colors(
                                        checkedThumbColor = KageNeonBlue,
                                        checkedTrackColor = KageNeonBlue.copy(alpha = 0.3f)
                                    )
                                )
                            }
                        }
                    }
                }
            }

            // Section 3: Visual styling
            SettingsHeader("Preferences")

            Card(
                colors = CardDefaults.cardColors(containerColor = KageDarkCard),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(0.5.dp, Color(0x1100D2FF), RoundedCornerShape(16.dp))
            ) {
                Column {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Filled.Contrast, "Theme", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(24.dp))
                        Spacer(modifier = Modifier.width(16.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Immersive Theater Mode", fontWeight = FontWeight.Bold, color = KageWhite)
                            Text("Forces active Pure Black backdrops for OLED devices.", color = KageGray, fontSize = 11.sp)
                        }
                        Switch(
                            checked = darkTheme,
                            onCheckedChange = { viewModel.darkThemeState.value = it },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = MaterialTheme.colorScheme.primary,
                                checkedTrackColor = MaterialTheme.colorScheme.primaryContainer
                            )
                        )
                    }
                }
            }

            // Section 3.5: Customer Services Support
            SettingsHeader("Customer Support")

            Card(
                colors = CardDefaults.cardColors(containerColor = KageDarkCard),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(0.5.dp, Color(0x1100D2FF), RoundedCornerShape(16.dp))
            ) {
                Column {
                    // Email Option
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                try {
                                    val intent = Intent(Intent.ACTION_SENDTO).apply {
                                        data = Uri.parse("mailto:kagelanka@gmail.com")
                                        putExtra(Intent.EXTRA_SUBJECT, "KageNet Customer Support")
                                    }
                                    context.startActivity(intent)
                                } catch (e: Exception) {
                                    val intent = Intent(Intent.ACTION_SEND).apply {
                                        type = "message/rfc822"
                                        putExtra(Intent.EXTRA_EMAIL, arrayOf("kagelanka@gmail.com"))
                                        putExtra(Intent.EXTRA_SUBJECT, "KageNet Customer Support")
                                    }
                                    context.startActivity(Intent.createChooser(intent, "Send Email"))
                                }
                            }
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Email,
                            contentDescription = "Email Support",
                            tint = KageNeonBlue,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(16.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Email Customer Support", fontWeight = FontWeight.Bold, color = KageWhite)
                            Text("kagelanka@gmail.com", color = KageGray, fontSize = 11.sp)
                        }
                        Icon(Icons.Filled.ChevronRight, "Arrow", tint = KageGray)
                    }

                    Divider(color = Color(0x1100D2FF))

                    // Telegram Option
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                try {
                                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://t.me/kagenetlanka"))
                                    context.startActivity(intent)
                                } catch (e: Exception) {
                                    // Fallback
                                }
                            }
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Send,
                            contentDescription = "Telegram Support",
                            tint = KageNeonBlue,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(16.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Telegram Community Support", fontWeight = FontWeight.Bold, color = KageWhite)
                            Text("@kagenetlanka (t.me/kagenetlanka)", color = KageGray, fontSize = 11.sp)
                        }
                        Icon(Icons.Filled.ChevronRight, "Arrow", tint = KageGray)
                    }
                }
            }

            // Section 4: Legals & About
            SettingsHeader("Legal & Information")

            Card(
                colors = CardDefaults.cardColors(containerColor = KageDarkCard),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(0.5.dp, Color(0x1100D2FF), RoundedCornerShape(16.dp))
            ) {
                Column {
                    // About App
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { showAboutDialog = true }
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Filled.Help, "About", tint = KageWhite, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(16.dp))
                        Text("About KageNet", color = KageWhite, modifier = Modifier.weight(1f))
                        Icon(Icons.Filled.ChevronRight, "Arrow", tint = KageGray)
                    }

                    Divider(color = Color(0x1100D2FF))

                    // Privacy Policy
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { showPrivacyDialog = true }
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Filled.PrivacyTip, "Privacy", tint = KageWhite, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(16.dp))
                        Text("Privacy Policy", color = KageWhite, modifier = Modifier.weight(1f))
                        Icon(Icons.Filled.ChevronRight, "Arrow", tint = KageGray)
                    }

                    Divider(color = Color(0x1100D2FF))

                    // Terms of Service
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { showTermsDialog = true }
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Filled.Description, "Terms", tint = KageWhite, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(16.dp))
                        Text("Terms & Conditions", color = KageWhite, modifier = Modifier.weight(1f))
                        Icon(Icons.Filled.ChevronRight, "Arrow", tint = KageGray)
                    }
                }
            }

            // Version info footer
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 16.dp),
                contentAlignment = Alignment.Center
            ) {
                Text("KageNet v1.0 • Built for Android with Kotlin & Compose", color = KageGray, fontSize = 11.sp)
            }
        }

        // Dialogs
        if (showAboutDialog) {
            AlertDialog(
                onDismissRequest = { showAboutDialog = false },
                title = { Text("About KageNet", color = KageNeonBlue, fontWeight = FontWeight.Bold) },
                text = {
                    Text(
                        "KageNet is a native offline-first Anime Streaming and Manga Reading application.\n\n" +
                                "It automatically synchronizes with remote servers to load catalogs without requiring APK modifications. All content can be downloaded and viewed securely offline.",
                        color = KageWhite
                    )
                },
                confirmButton = {
                    TextButton(onClick = { showAboutDialog = false }) { Text("Dismiss", color = KageNeonBlue) }
                },
                containerColor = KageDarkSpace
            )
        }

        if (showPrivacyDialog) {
            AlertDialog(
                onDismissRequest = { showPrivacyDialog = false },
                title = { Text("Privacy Policy", color = KageNeonBlue, fontWeight = FontWeight.Bold) },
                text = {
                    Text(
                        "We highly respect your privacy.\n\n" +
                                "All history records, credentials, and settings are stored locally on your device within sandboxed app space. We never transmit telemetry, tracking logs, or profile details to external servers.",
                        color = KageWhite
                    )
                },
                confirmButton = {
                    TextButton(onClick = { showPrivacyDialog = false }) { Text("Close", color = KageNeonBlue) }
                },
                containerColor = KageDarkSpace
            )
        }

        if (showTermsDialog) {
            AlertDialog(
                onDismissRequest = { showTermsDialog = false },
                title = { Text("Terms & Conditions", color = KageNeonBlue, fontWeight = FontWeight.Bold) },
                text = {
                    Text(
                        "All content provided dynamically within KageNet is parsed from your designated server endpoints. " +
                                "By downloading or viewing content through KageNet, you acknowledge that KageNet operates as a personal media organizer and catalog client.",
                        color = KageWhite
                    )
                },
                confirmButton = {
                    TextButton(onClick = { showTermsDialog = false }) { Text("Agree", color = KageNeonBlue) }
                },
                containerColor = KageDarkSpace
            )
        }
    }
}

@Composable
fun SettingsHeader(title: String) {
    Text(
        text = title,
        color = KageNeonBlue,
        fontSize = 13.sp,
        fontWeight = FontWeight.Bold,
        letterSpacing = 1.2.sp,
        modifier = Modifier.padding(top = 8.dp)
    )
}
