package com.example.ui.screens

import android.content.Intent
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.example.data.Chapter
import com.example.data.Manga
import com.example.ui.KageViewModel
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MangaDetailsScreen(
    mangaId: String,
    viewModel: KageViewModel,
    onNavigateBack: () -> Unit,
    onNavigateToReader: (String, Int) -> Unit,
    onNavigateToRelatedManga: (String) -> Unit
) {
    val dbState by viewModel.databaseState.collectAsStateWithLifecycle()
    val favorites by viewModel.favoritesState.collectAsStateWithLifecycle()
    val readingList by viewModel.readingListState.collectAsStateWithLifecycle()
    val downloads by viewModel.downloadsState.collectAsStateWithLifecycle()

    val context = LocalContext.current

    val manga = dbState.manga.find { it.id == mangaId }
    if (manga == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("Manga not found", color = KageWhite)
        }
        return
    }

    val isFav = favorites.any { it.itemId == manga.id && it.itemType == "manga" }
    val isRL = readingList.any { it.mangaId == manga.id }

    val relatedManga = dbState.manga.filter { other ->
        other.id != manga.id && other.genres.any { manga.genres.contains(it) }
    }

    var selectedTab by remember { mutableStateOf("Chapters") }
    var isSynopsisExpanded by remember { mutableStateOf(false) }

    Scaffold(
        containerColor = KageDeepAbyss
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .testTag("manga_details_scroll"),
            contentPadding = PaddingValues(bottom = 32.dp)
        ) {
            // 1. Large Immersive Banner Backsplash (Mockup Style)
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(350.dp)
                ) {
                    // Banner Image
                    AsyncImage(
                        model = manga.banner.ifEmpty { manga.cover },
                        contentDescription = "Banner",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )

                    // Overlay Gradients
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.verticalGradient(
                                    colors = listOf(
                                        Color.Transparent,
                                        KageBlack.copy(alpha = 0.5f),
                                        KageDeepAbyss
                                    )
                                )
                            )
                    )

                    // Navigation Back Button (Top Left)
                    IconButton(
                        onClick = onNavigateBack,
                        modifier = Modifier
                            .padding(16.dp)
                            .size(40.dp)
                            .background(KageBlack.copy(alpha = 0.6f), CircleShape)
                            .border(0.5.dp, Color(0x33FFFFFF), CircleShape)
                            .align(Alignment.TopStart)
                    ) {
                        Icon(Icons.Filled.ArrowBack, "Back", tint = KageWhite, modifier = Modifier.size(20.dp))
                    }

                    // Share Button (Top Right)
                    IconButton(
                        onClick = {
                            val intent = Intent(Intent.ACTION_SEND).apply {
                                type = "text/plain"
                                putExtra(Intent.EXTRA_SUBJECT, manga.title)
                                putExtra(Intent.EXTRA_TEXT, "Read ${manga.title} on KageNet! https://kagenet.com/manga/${manga.id}")
                            }
                            context.startActivity(Intent.createChooser(intent, "Share Manga"))
                        },
                        modifier = Modifier
                            .padding(16.dp)
                            .size(40.dp)
                            .background(KageBlack.copy(alpha = 0.6f), CircleShape)
                            .border(0.5.dp, Color(0x33FFFFFF), CircleShape)
                            .align(Alignment.TopEnd)
                    ) {
                        Icon(Icons.Filled.Share, "Share", tint = KageWhite, modifier = Modifier.size(20.dp))
                    }

                    // Floating Glass Blue Read Button (Mockup Style)
                    IconButton(
                        onClick = { onNavigateToReader(manga.id, 0) },
                        modifier = Modifier
                            .padding(end = 20.dp, bottom = 40.dp)
                            .size(56.dp)
                            .background(KageNeonBlue, CircleShape)
                            .border(4.dp, KageDeepAbyss, CircleShape)
                            .align(Alignment.BottomEnd)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Book,
                            contentDescription = "Read First Chapter",
                            tint = KageBlack,
                            modifier = Modifier.size(26.dp)
                        )
                    }

                    // Bottom info text overlay
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .align(Alignment.BottomStart)
                            .padding(horizontal = 20.dp, vertical = 20.dp)
                            .padding(end = 70.dp) // Leave space for read button
                    ) {
                        Text(
                            text = manga.title,
                            color = KageWhite,
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Black,
                            lineHeight = 30.sp
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "By ${manga.author}  •  ${manga.year}  •  ${manga.status}",
                            color = KageGray,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.Star, "Rating", tint = Color(0xFFFFB200), modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "${manga.rating} (8.5K)",
                                color = KageWhite,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            // 2. Genre Tags Row
            item {
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp)
                ) {
                    items(manga.genres) { genre ->
                        Box(
                            modifier = Modifier
                                .background(Color(0x1D00D2FF), RoundedCornerShape(20.dp))
                                .border(0.5.dp, Color(0x3300D2FF), RoundedCornerShape(20.dp))
                                .padding(horizontal = 14.dp, vertical = 6.dp)
                        ) {
                            Text(genre, color = KageNeonBlue, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            // 3. Synopsis with Expandable "Read more"
            item {
                Column(modifier = Modifier.padding(horizontal = 20.dp, vertical = 12.dp)) {
                    Text(
                        text = "Synopsis",
                        color = KageWhite,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = manga.description,
                        color = KageGray,
                        fontSize = 13.sp,
                        lineHeight = 19.sp,
                        maxLines = if (isSynopsisExpanded) Int.MAX_VALUE else 3,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = if (isSynopsisExpanded) "Read less" else "Read more",
                        color = KageNeonBlue,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.clickable { isSynopsisExpanded = !isSynopsisExpanded }
                    )
                }
            }

            // 4. Quick Actions Circle Row
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceAround,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Add/Remove from Reading List
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.clickable { viewModel.toggleReadingList(manga.id) }
                    ) {
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .background(Color(0x0AFFFFFF), CircleShape)
                                .border(1.dp, Color(0x1AFFFFFF), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = if (isRL) Icons.Filled.CheckCircle else Icons.Filled.Add,
                                contentDescription = "Add",
                                tint = if (isRL) KageNeonBlue else KageWhite,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = if (isRL) "In Library" else "Add to List",
                            color = if (isRL) KageNeonBlue else KageGray,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }

                    // Favorite / Love List
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.clickable { viewModel.toggleFavorite(manga.id, "manga") }
                    ) {
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .background(Color(0x0AFFFFFF), CircleShape)
                                .border(1.dp, Color(0x1AFFFFFF), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = if (isFav) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                                contentDescription = "Favorite",
                                tint = if (isFav) Color.Red else KageWhite,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = if (isFav) "Liked" else "Love",
                            color = if (isFav) Color.Red else KageGray,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }

                    // Share
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.clickable {
                            val intent = Intent(Intent.ACTION_SEND).apply {
                                type = "text/plain"
                                putExtra(Intent.EXTRA_SUBJECT, manga.title)
                                putExtra(Intent.EXTRA_TEXT, "Read ${manga.title} on KageNet! https://kagenet.com/manga/${manga.id}")
                            }
                            context.startActivity(Intent.createChooser(intent, "Share Manga"))
                        }
                    ) {
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .background(Color(0x0AFFFFFF), CircleShape)
                                .border(1.dp, Color(0x1AFFFFFF), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Share,
                                contentDescription = "Share",
                                tint = KageWhite,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Share",
                            color = KageGray,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }

            // 5. Custom Tab Row (Mockup Style Pill Tabs)
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    listOf("Chapters", "Details", "Related").forEach { tab ->
                        val isSelected = selectedTab == tab
                        Box(
                            modifier = Modifier
                                .background(
                                    if (isSelected) KageNeonBlue else Color.Transparent,
                                    RoundedCornerShape(24.dp)
                                )
                                .border(
                                    1.dp,
                                    if (isSelected) KageNeonBlue else Color(0x1AFFFFFF),
                                    RoundedCornerShape(24.dp)
                                )
                                .clickable { selectedTab = tab }
                                .padding(horizontal = 20.dp, vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = tab,
                                color = if (isSelected) KageBlack else KageGray,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            // Tab Content Rendering
            when (selectedTab) {
                "Chapters" -> {
                    if (manga.chapters.isEmpty()) {
                        item {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(24.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text("No chapters available.", color = KageGray)
                            }
                        }
                    } else {
                        items(manga.chapters.size) { index ->
                            val chapter = manga.chapters[index]
                            val downloadId = "${manga.id}_chap_${chapter.number}"
                            val downloadState = downloads.find { it.downloadId == downloadId }

                            ChapterRowItem(
                                chapter = chapter,
                                index = index,
                                downloadItem = downloadState,
                                onReadClick = { onNavigateToReader(manga.id, index) },
                                onDownloadClick = {
                                    viewModel.startDownload(
                                        id = downloadId,
                                        url = chapter.pdf,
                                        title = "${manga.title} - Ch ${chapter.number}",
                                        fileType = "pdf",
                                        mangaId = manga.id,
                                        chapterIndex = index
                                    )
                                },
                                onPauseClick = { viewModel.pauseDownload(downloadId) },
                                onResumeClick = { viewModel.resumeDownload(downloadId) },
                                onCancelClick = { viewModel.cancelDownload(downloadId) }
                            )
                        }
                    }
                }

                "Details" -> {
                    item {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 20.dp, vertical = 10.dp)
                                .background(KageDarkCard, RoundedCornerShape(16.dp))
                                .border(0.5.dp, Color(0x1AFFFFFF), RoundedCornerShape(16.dp))
                                .padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Text("Metadata", color = KageWhite, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                            HorizontalDivider(color = Color(0x11FFFFFF))
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Author", color = KageGray, fontSize = 13.sp)
                                Text(manga.author, color = KageWhite, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            }
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Year", color = KageGray, fontSize = 13.sp)
                                Text(manga.year.toString(), color = KageWhite, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            }
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Status", color = KageGray, fontSize = 13.sp)
                                Text(manga.status, color = KageNeonBlue, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            }
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Rating", color = KageGray, fontSize = 13.sp)
                                Text("${manga.rating} / 10", color = KageWhite, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                "Related" -> {
                    if (relatedManga.isEmpty()) {
                        item {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(24.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text("No related content found.", color = KageGray)
                            }
                        }
                    } else {
                        item {
                            LazyRow(
                                contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp),
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                items(relatedManga) { other ->
                                    MangaCard(manga = other, onClick = { onNavigateToRelatedManga(other.id) })
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ChapterRowItem(
    chapter: Chapter,
    index: Int,
    downloadItem: com.example.data.DownloadItem?,
    onReadClick: () -> Unit,
    onDownloadClick: () -> Unit,
    onPauseClick: () -> Unit,
    onResumeClick: () -> Unit,
    onCancelClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp)
            .border(0.5.dp, Color(0x1AFFFFFF), RoundedCornerShape(16.dp)),
        colors = CardDefaults.cardColors(containerColor = KageDarkCard)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Thumbnail block
                Box(
                    modifier = Modifier
                        .size(width = 60.dp, height = 70.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(KageBlack)
                        .clickable(onClick = onReadClick)
                ) {
                    AsyncImage(
                        model = chapter.cover.ifEmpty { "https://images.unsplash.com/photo-1543002588-bfa74002ed7e?w=100&q=80" },
                        contentDescription = "Chapter ${chapter.number}",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                }

                Spacer(modifier = Modifier.width(16.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Chapter ${chapter.number}",
                        color = KageNeonBlue,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = chapter.title,
                        color = KageWhite,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                // Download control widget
                DownloadButtonWidget(
                    downloadItem = downloadItem,
                    onDownloadClick = onDownloadClick,
                    onPauseClick = onPauseClick,
                    onResumeClick = onResumeClick,
                    onCancelClick = onCancelClick
                )
            }

            // Download progress bar indicator (if active/downloading/paused)
            if (downloadItem != null && (downloadItem.status == "downloading" || downloadItem.status == "paused" || downloadItem.status == "pending")) {
                Spacer(modifier = Modifier.height(10.dp))
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        val speedStr = if (downloadItem.status == "downloading") "${downloadItem.speedBytesPerSec / 1024} KB/s" else "Paused"
                        val remainingStr = if (downloadItem.status == "downloading") "${downloadItem.remainingTimeSeconds}s left" else ""
                        Text(
                            text = "${downloadItem.progress}% ($speedStr)",
                            color = KageNeonBlue,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = remainingStr,
                            color = KageGray,
                            fontSize = 10.sp
                        )
                    }
                    LinearProgressIndicator(
                        progress = { downloadItem.progress.toFloat() / 100f },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(4.dp)
                            .clip(RoundedCornerShape(2.dp)),
                        color = KageNeonBlue,
                        trackColor = Color(0x22FFFFFF)
                    )
                }
            }
        }
    }
}
