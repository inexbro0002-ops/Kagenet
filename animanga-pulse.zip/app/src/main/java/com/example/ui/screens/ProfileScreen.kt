package com.example.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.example.R
import com.example.ui.KageViewModel
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileScreen(
    viewModel: KageViewModel,
    onNavigateToStorageManager: () -> Unit,
    onNavigateToSettings: () -> Unit
) {
    val profile by viewModel.profileState.collectAsStateWithLifecycle()
    val favorites by viewModel.favoritesState.collectAsStateWithLifecycle()
    val watchHistory by viewModel.watchHistoryState.collectAsStateWithLifecycle()
    val readingHistory by viewModel.readingHistoryState.collectAsStateWithLifecycle()

    var isEditing by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text("Kage Profile", fontWeight = FontWeight.Bold, color = KageWhite) },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = KageDeepAbyss,
                    titleContentColor = KageWhite
                ),
                actions = {
                    IconButton(
                        onClick = onNavigateToSettings,
                        modifier = Modifier.testTag("action_settings_top")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Settings,
                            contentDescription = "Settings",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            )
        },
        containerColor = KageDeepAbyss
    ) { innerPadding ->
        if (profile == null || !profile!!.isLoggedIn) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator(color = KageNeonBlue)
            }
        } else {
            val user = profile!!
            if (isEditing) {
                // Edit Profile Form Screen
                EditProfileForm(
                    initialName = user.username,
                    initialEmail = user.email,
                    initialAvatar = user.profilePicturePath,
                    onSave = { name, email, avatar ->
                        viewModel.registerOrLogin(name, email, avatar)
                        isEditing = false
                    },
                    onCancel = { isEditing = false }
                )
            } else {
                // Main Profile Info Screen
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                        .testTag("profile_content_list"),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    item {
                        ProfileHeaderSection(
                            username = user.username,
                            email = user.email,
                            avatarUrl = user.profilePicturePath,
                            onEditClick = { isEditing = true }
                        )
                    }

                    // Stats Dashboard Grid
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            StatBox(
                                value = favorites.size.toString(),
                                label = "Favorites",
                                modifier = Modifier.weight(1f)
                            )
                            StatBox(
                                value = watchHistory.size.toString(),
                                label = "Episodes",
                                modifier = Modifier.weight(1f)
                            )
                            StatBox(
                                value = readingHistory.size.toString(),
                                label = "Chapters",
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }

                    // Storage manager shortcut card
                    item {
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, Color(0x3300D2FF), RoundedCornerShape(16.dp))
                                .clickable(onClick = onNavigateToStorageManager),
                            colors = CardDefaults.cardColors(containerColor = KageDarkCard)
                        ) {
                            Row(
                                modifier = Modifier.padding(16.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Storage,
                                    contentDescription = "Storage",
                                    tint = KageNeonBlue,
                                    modifier = Modifier.size(28.dp)
                                )
                                Spacer(modifier = Modifier.width(16.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("Storage Manager", fontWeight = FontWeight.Bold, color = KageWhite, fontSize = 16.sp)
                                    Text("Analyze local cache, size of downloads, database version.", color = KageGray, fontSize = 11.sp)
                                }
                                Icon(Icons.Filled.ChevronRight, "Arrow", tint = KageGray)
                            }
                        }
                    }

                    // Activity History Rows
                    item {
                        Text(
                            text = "Recent Activity",
                            fontWeight = FontWeight.Bold,
                            color = KageWhite,
                            fontSize = 18.sp,
                            modifier = Modifier.padding(top = 10.dp)
                        )
                    }

                    val totalHistory = (watchHistory.map { "Watched: " to it.episodeTitle } +
                            readingHistory.map { "Read: " to it.chapterTitle }).shuffled().take(5)

                    if (totalHistory.isEmpty()) {
                        item {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(KageDarkCard, RoundedCornerShape(16.dp))
                                    .padding(24.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text("No recent streaming or reading history.", color = KageGray, fontSize = 13.sp)
                            }
                        }
                    } else {
                        items(totalHistory.size) { index ->
                            val activity = totalHistory[index]
                            ActivityRow(type = activity.first, title = activity.second)
                        }
                    }

                    // Logout Button
                    item {
                        Spacer(modifier = Modifier.height(12.dp))
                        Button(
                            onClick = { viewModel.logout() },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("logout_button"),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF601111), contentColor = KageWhite),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(imageVector = Icons.Filled.Logout, contentDescription = "Logout")
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Logout", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ProfileHeaderSection(
    username: String,
    email: String,
    avatarUrl: String?,
    onEditClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .background(KageDarkCard)
            .border(1.dp, Color(0x2200D2FF), RoundedCornerShape(24.dp))
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        val finalAvatar = avatarUrl ?: "https://api.dicebear.com/7.x/bottts/png?seed=KageNet"
        Box(
            modifier = Modifier
                .size(72.dp)
                .clip(CircleShape)
                .background(KageBlack)
                .border(2.dp, KageNeonBlue, CircleShape)
        ) {
            AsyncImage(
                model = finalAvatar,
                contentDescription = "Avatar",
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
        }

        Spacer(modifier = Modifier.width(16.dp))

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = username,
                color = KageWhite,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = email,
                color = KageGray,
                fontSize = 13.sp
            )
        }

        IconButton(
            onClick = onEditClick,
            modifier = Modifier
                .minimumInteractiveComponentSize()
                .background(KageBlack.copy(alpha = 0.5f), CircleShape)
                .border(0.5.dp, Color(0x3300D2FF), CircleShape)
                .testTag("edit_profile_button")
        ) {
            Icon(Icons.Filled.Edit, "Edit profile", tint = KageNeonBlue, modifier = Modifier.size(18.dp))
        }
    }
}

@Composable
fun StatBox(value: String, label: String, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .background(KageDarkCard)
            .border(0.5.dp, Color(0x1100D2FF), RoundedCornerShape(16.dp))
            .padding(16.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = value,
                color = KageNeonBlue,
                fontSize = 22.sp,
                fontWeight = FontWeight.ExtraBold
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = label,
                color = KageGray,
                fontSize = 11.sp,
                fontWeight = FontWeight.Medium
            )
        }
    }
}

@Composable
fun ActivityRow(type: String, title: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(KageDarkCard)
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = if (type.startsWith("Watched")) Icons.Filled.PlayCircleFilled else Icons.Filled.Book,
            contentDescription = "Activity Type",
            tint = if (type.startsWith("Watched")) KageNeonBlue else KageGreen,
            modifier = Modifier.size(20.dp)
        )
        Spacer(modifier = Modifier.width(12.dp))
        Column {
            Text(type, color = KageGray, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            Text(title, color = KageWhite, fontSize = 13.sp, fontWeight = FontWeight.Medium, maxLines = 1)
        }
    }
}

@Composable
fun LoginRegisterForm(onRegister: (String, String, String) -> Unit) {
    var username by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var selectedAvatar by remember { mutableStateOf("https://api.dicebear.com/7.x/bottts/png?seed=KageNet") }

    val avatarSeeds = listOf("Alpha", "Beta", "Gamma", "Shadow", "Delta")

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp)
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            "Welcome to Shadow Network",
            color = KageWhite,
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center
        )
        Text(
            "Create a local profile to track your streaming, download records, history and favorites offline.",
            color = KageGray,
            fontSize = 13.sp,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
        )

        Spacer(modifier = Modifier.height(24.dp))

        // Avatar presets selector
        Text("Choose Cyber Avatar", color = KageWhite, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.align(Alignment.Start))
        Spacer(modifier = Modifier.height(8.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            avatarSeeds.forEach { seed ->
                val picUrl = "https://api.dicebear.com/7.x/bottts/png?seed=$seed"
                val isSelected = selectedAvatar == picUrl
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(KageDarkCard)
                        .border(
                            2.dp,
                            if (isSelected) KageNeonBlue else Color.Transparent,
                            CircleShape
                        )
                        .clickable { selectedAvatar = picUrl }
                ) {
                    AsyncImage(
                        model = picUrl,
                        contentDescription = "Avatar preset",
                        modifier = Modifier.fillMaxSize()
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        OutlinedTextField(
            value = username,
            onValueChange = { username = it },
            label = { Text("Username") },
            modifier = Modifier
                .fillMaxWidth()
                .testTag("username_field"),
            singleLine = true,
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = KageWhite,
                unfocusedTextColor = KageWhite,
                focusedBorderColor = KageNeonBlue,
                unfocusedBorderColor = Color(0x3300D2FF),
                cursorColor = KageNeonBlue
            )
        )

        Spacer(modifier = Modifier.height(12.dp))

        OutlinedTextField(
            value = email,
            onValueChange = { email = it },
            label = { Text("Email Address") },
            modifier = Modifier
                .fillMaxWidth()
                .testTag("email_field"),
            singleLine = true,
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = KageWhite,
                unfocusedTextColor = KageWhite,
                focusedBorderColor = KageNeonBlue,
                unfocusedBorderColor = Color(0x3300D2FF),
                cursorColor = KageNeonBlue
            )
        )

        Spacer(modifier = Modifier.height(28.dp))

        Button(
            onClick = {
                if (username.isNotEmpty() && email.isNotEmpty()) {
                    onRegister(username, email, selectedAvatar)
                }
            },
            enabled = username.isNotEmpty() && email.isNotEmpty(),
            modifier = Modifier
                .fillMaxWidth()
                .height(50.dp)
                .testTag("register_submit_button"),
            colors = ButtonDefaults.buttonColors(
                containerColor = KageNeonBlue,
                contentColor = KageBlack,
                disabledContainerColor = KageDarkCard,
                disabledContentColor = KageGray
            ),
            shape = RoundedCornerShape(14.dp)
        ) {
            Text("Initialize Profile", fontWeight = FontWeight.Bold, fontSize = 15.sp)
        }
    }
}

@Composable
fun EditProfileForm(
    initialName: String,
    initialEmail: String,
    initialAvatar: String?,
    onSave: (String, String, String?) -> Unit,
    onCancel: () -> Unit
) {
    var username by remember { mutableStateOf(initialName) }
    var email by remember { mutableStateOf(initialEmail) }
    var selectedAvatar by remember { mutableStateOf(initialAvatar ?: "https://api.dicebear.com/7.x/bottts/png?seed=KageNet") }

    val avatarSeeds = listOf("Alpha", "Beta", "Gamma", "Shadow", "Delta")

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp)
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            "Modify Cyber Profile",
            color = KageWhite,
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(24.dp))

        // Avatar select
        Text("Choose Cyber Avatar", color = KageWhite, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.align(Alignment.Start))
        Spacer(modifier = Modifier.height(8.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            avatarSeeds.forEach { seed ->
                val picUrl = "https://api.dicebear.com/7.x/bottts/png?seed=$seed"
                val isSelected = selectedAvatar == picUrl
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(KageDarkCard)
                        .border(
                            2.dp,
                            if (isSelected) KageNeonBlue else Color.Transparent,
                            CircleShape
                        )
                        .clickable { selectedAvatar = picUrl }
                ) {
                    AsyncImage(
                        model = picUrl,
                        contentDescription = "Avatar preset",
                        modifier = Modifier.fillMaxSize()
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        OutlinedTextField(
            value = username,
            onValueChange = { username = it },
            label = { Text("Username") },
            modifier = Modifier
                .fillMaxWidth()
                .testTag("edit_username_field"),
            singleLine = true,
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = KageWhite,
                unfocusedTextColor = KageWhite,
                focusedBorderColor = KageNeonBlue,
                unfocusedBorderColor = Color(0x3300D2FF),
                cursorColor = KageNeonBlue
            )
        )

        Spacer(modifier = Modifier.height(12.dp))

        OutlinedTextField(
            value = email,
            onValueChange = { email = it },
            label = { Text("Email Address") },
            modifier = Modifier
                .fillMaxWidth()
                .testTag("edit_email_field"),
            singleLine = true,
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = KageWhite,
                unfocusedTextColor = KageWhite,
                focusedBorderColor = KageNeonBlue,
                unfocusedBorderColor = Color(0x3300D2FF),
                cursorColor = KageNeonBlue
            )
        )

        Spacer(modifier = Modifier.height(28.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedButton(
                onClick = onCancel,
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp),
                border = BorderStroke(1.dp, Color(0x44FFFFFF)),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = KageWhite),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text("Cancel")
            }

            Button(
                onClick = {
                    if (username.isNotEmpty() && email.isNotEmpty()) {
                        onSave(username, email, selectedAvatar)
                    }
                },
                enabled = username.isNotEmpty() && email.isNotEmpty(),
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp)
                    .testTag("edit_save_button"),
                colors = ButtonDefaults.buttonColors(containerColor = KageNeonBlue, contentColor = KageBlack),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text("Save Changes", fontWeight = FontWeight.Bold)
            }
        }
    }
}
