package com.example.ui

import android.app.Application
import android.os.Environment
import android.os.StatFs
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.*
import com.example.download.KageDownloadManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.DecimalFormat

class KageViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = KageRepository(application)
    private val downloadManager = KageDownloadManager(application)
    private val context = application.applicationContext

    // DB & Version Status
    val databaseState: StateFlow<DatabaseResponse> = repository.databaseState
    val isSyncing: StateFlow<Boolean> = repository.isSyncing
    val syncError: SharedFlow<String?> = repository.syncError
    val lastSyncTime: StateFlow<Long> = repository.lastSyncTime
    val currentDbVersion: StateFlow<Int> = repository.currentDbVersion

    // User Profile
    private val _profileState = MutableStateFlow<UserProfile?>(null)
    val profileState: StateFlow<UserProfile?> = _profileState.asStateFlow()
    val isProfileLoaded = MutableStateFlow(false)

    // Lists & States
    val favoritesState: StateFlow<List<Favorite>> = repository.favoritesFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
        
    val watchLaterState: StateFlow<List<WatchLater>> = repository.watchLaterFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
        
    val readingListState: StateFlow<List<ReadingList>> = repository.readingListFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
        
    val continueWatchingState: StateFlow<List<ContinueWatching>> = repository.continueWatchingFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
        
    val continueReadingState: StateFlow<List<ContinueReading>> = repository.continueReadingFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
        
    val watchHistoryState: StateFlow<List<WatchHistory>> = repository.watchHistoryFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
        
    val readingHistoryState: StateFlow<List<ReadingHistory>> = repository.readingHistoryFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
        
    val notificationsState: StateFlow<List<NotificationEntity>> = repository.notificationsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
        
    val unreadNotificationsCount: StateFlow<Int> = repository.unreadNotificationsCount
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)
        
    val downloadsState: StateFlow<List<DownloadItem>> = repository.downloadsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Search & Filter States
    val searchQuery = MutableStateFlow("")
    val searchCategory = MutableStateFlow("All") // "All", "Anime", "Manga"
    val selectedGenre = MutableStateFlow<String?>(null)
    val selectedStatus = MutableStateFlow<String?>(null)
    val selectedYear = MutableStateFlow<Int?>(null)

    // Settings & Theme
    val darkThemeState = MutableStateFlow(true) // Premium black default

    // Storage Manager Flow Metrics
    val storageDbSize = MutableStateFlow("0 B")
    val storageCacheSize = MutableStateFlow("0 B")
    val storageDownloadSize = MutableStateFlow("0 B")
    val storageTotalSize = MutableStateFlow("0 B")
    val storageFreeSize = MutableStateFlow("0 B")

    init {
        // Load and track profile state from database
        viewModelScope.launch {
            repository.profileFlow.collect { profile ->
                _profileState.value = profile
                isProfileLoaded.value = true
            }
        }

        // Trigger initial sync on startup
        viewModelScope.launch {
            repository.syncDatabase(force = false)
            calculateStorageMetrics()
        }

        // Automatic background sync check every 30 minutes (1800000 ms)
        viewModelScope.launch {
            while (true) {
                delay(1800000)
                Log.d("KageViewModel", "Periodic 30-minute sync triggered")
                repository.syncDatabase(force = false)
                calculateStorageMetrics()
            }
        }
    }

    // Dynamic Search & Live Suggestions Filtering logic
    val filteredAnime: StateFlow<List<Anime>> = combine<Any?, List<Anime>>(
        databaseState, searchQuery, searchCategory, selectedGenre, selectedStatus, selectedYear
    ) { array ->
        val db = array[0] as com.example.data.DatabaseResponse
        val query = array[1] as String
        val category = array[2] as String
        val genre = array[3] as String?
        val status = array[4] as String?
        val year = array[5] as Int?

        if (category == "Manga") return@combine emptyList()
        db.anime.filter { item ->
            val matchesQuery = query.isEmpty() || item.title.contains(query, ignoreCase = true) || item.description.contains(query, ignoreCase = true)
            val matchesGenre = genre == null || item.genres.contains(genre)
            val matchesStatus = status == null || item.status.equals(status, ignoreCase = true)
            val matchesYear = year == null || item.year == year
            matchesQuery && matchesGenre && matchesStatus && matchesYear
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val filteredManga: StateFlow<List<Manga>> = combine<Any?, List<Manga>>(
        databaseState, searchQuery, searchCategory, selectedGenre, selectedStatus, selectedYear
    ) { array ->
        val db = array[0] as com.example.data.DatabaseResponse
        val query = array[1] as String
        val category = array[2] as String
        val genre = array[3] as String?
        val status = array[4] as String?
        val year = array[5] as Int?

        if (category == "Anime") return@combine emptyList()
        db.manga.filter { item ->
            val matchesQuery = query.isEmpty() || item.title.contains(query, ignoreCase = true) || item.description.contains(query, ignoreCase = true)
            val matchesGenre = genre == null || item.genres.contains(genre)
            val matchesStatus = status == null || item.status.equals(status, ignoreCase = true)
            val matchesYear = year == null || item.year == year
            matchesQuery && matchesGenre && matchesStatus && matchesYear
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // All unique genres, years, and statuses from database for filter suggestions
    val allGenres: StateFlow<List<String>> = databaseState.map { db ->
        val animeGenres = db.anime.flatMap { it.genres }
        val mangaGenres = db.manga.flatMap { it.genres }
        (animeGenres + mangaGenres).distinct().sorted()
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allYears: StateFlow<List<Int>> = databaseState.map { db ->
        val animeYears = db.anime.map { it.year }
        val mangaYears = db.manga.map { it.year }
        (animeYears + mangaYears).distinct().sortedDescending()
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // User Profile Actions
    fun registerOrLogin(username: String, email: String, profilePicPath: String?) {
        viewModelScope.launch {
            repository.saveProfile(username, email, profilePicPath)
        }
    }

    fun logout() {
        viewModelScope.launch {
            repository.logout()
        }
    }

    // Toggle Favorites
    fun toggleFavorite(itemId: String, itemType: String) {
        viewModelScope.launch {
            repository.toggleFavorite(itemId, itemType)
        }
    }

    // Toggle Watch Later / Reading Lists
    fun toggleWatchLater(animeId: String) {
        viewModelScope.launch {
            repository.toggleWatchLater(animeId)
        }
    }

    fun toggleReadingList(mangaId: String) {
        viewModelScope.launch {
            repository.toggleReadingList(mangaId)
        }
    }

    // Watch Progress
    fun saveContinueWatching(animeId: String, episodeIndex: Int, title: String, position: Long, duration: Long) {
        viewModelScope.launch {
            repository.saveContinueWatching(animeId, episodeIndex, title, position, duration)
        }
    }

    fun saveContinueReading(mangaId: String, chapterIndex: Int, title: String, page: Int, totalPages: Int) {
        viewModelScope.launch {
            repository.saveContinueReading(mangaId, chapterIndex, title, page, totalPages)
        }
    }

    // Rating
    fun rateItem(itemId: String, itemType: String, rating: Double) {
        viewModelScope.launch {
            repository.setRating(itemId, itemType, rating)
        }
    }

    fun getLocalRatingFlow(itemId: String, itemType: String): Flow<Rating?> {
        return repository.getRatingFlow(itemId, itemType)
    }

    // Manual Sync Database Action
    fun syncDatabaseNow() {
        viewModelScope.launch {
            repository.syncDatabase(force = true)
            calculateStorageMetrics()
        }
    }

    // Notifications
    fun markNotificationAsRead(id: String) {
        viewModelScope.launch {
            repository.markNotificationAsRead(id)
        }
    }

    fun markAllNotificationsAsRead() {
        viewModelScope.launch {
            repository.markAllNotificationsAsRead()
        }
    }

    // Downloads Actions
    fun startDownload(
        id: String,
        url: String,
        title: String,
        fileType: String,
        animeId: String? = null,
        mangaId: String? = null,
        episodeIndex: Int? = null,
        chapterIndex: Int? = null
    ) {
        viewModelScope.launch {
            downloadManager.enqueueDownload(
                id = id,
                url = url,
                title = title,
                fileType = fileType,
                animeId = animeId,
                mangaId = mangaId,
                episodeIndex = episodeIndex,
                chapterIndex = chapterIndex
            )
            calculateStorageMetrics()
        }
    }

    fun pauseDownload(downloadId: String) {
        viewModelScope.launch {
            downloadManager.pauseDownload(downloadId)
        }
    }

    fun resumeDownload(downloadId: String) {
        viewModelScope.launch {
            downloadManager.resumeDownload(downloadId)
        }
    }

    fun cancelDownload(downloadId: String) {
        viewModelScope.launch {
            downloadManager.cancelDownload(downloadId)
            calculateStorageMetrics()
        }
    }

    fun deleteDownload(downloadId: String) {
        viewModelScope.launch {
            downloadManager.deleteDownload(downloadId)
            calculateStorageMetrics()
        }
    }

    // Storage Actions
    fun clearCache() {
        viewModelScope.launch {
            repository.clearCache()
            calculateStorageMetrics()
        }
    }

    fun deleteAnimeDownloads() {
        viewModelScope.launch {
            repository.deleteVideoDownloads()
            // Delete actual files in filesDir/downloads ending with .mp4
            val downloadsDir = File(context.filesDir, "downloads")
            if (downloadsDir.exists()) {
                downloadsDir.listFiles()?.forEach { file ->
                    if (file.name.endsWith(".mp4")) {
                        file.delete()
                    }
                }
            }
            val videoDir = KageDownloadManager.getDownloadFolder(context, "mp4")
            if (videoDir.exists()) {
                videoDir.listFiles()?.forEach { file ->
                    if (file.name.endsWith(".mp4")) {
                        file.delete()
                    }
                }
            }
            calculateStorageMetrics()
        }
    }

    fun deleteMangaDownloads() {
        viewModelScope.launch {
            repository.deletePdfDownloads()
            // Delete actual files in filesDir/downloads ending with .pdf
            val downloadsDir = File(context.filesDir, "downloads")
            if (downloadsDir.exists()) {
                downloadsDir.listFiles()?.forEach { file ->
                    if (file.name.endsWith(".pdf")) {
                        file.delete()
                    }
                }
            }
            val pdfDir = KageDownloadManager.getDownloadFolder(context, "pdf")
            if (pdfDir.exists()) {
                pdfDir.listFiles()?.forEach { file ->
                    if (file.name.endsWith(".pdf")) {
                        file.delete()
                    }
                }
            }
            calculateStorageMetrics()
        }
    }

    fun deleteAllDownloads() {
        viewModelScope.launch {
            repository.deleteAllDownloads()
            // Delete all files in filesDir/downloads
            val downloadsDir = File(context.filesDir, "downloads")
            if (downloadsDir.exists()) {
                downloadsDir.listFiles()?.forEach { it.delete() }
            }
            val videoDir = KageDownloadManager.getDownloadFolder(context, "mp4")
            if (videoDir.exists()) {
                videoDir.listFiles()?.forEach { it.delete() }
            }
            val pdfDir = KageDownloadManager.getDownloadFolder(context, "pdf")
            if (pdfDir.exists()) {
                videoDir.listFiles()?.forEach { it.delete() }
            }
            calculateStorageMetrics()
        }
    }

    // Hero and Trending section management
    fun setHeroSection(animeId: String) {
        viewModelScope.launch {
            repository.updateHeroSection(animeId)
        }
    }

    fun toggleTrending(itemId: String) {
        viewModelScope.launch {
            repository.toggleTrendingStatus(itemId)
        }
    }

    // Storage Metric Calculation Utilities
    fun calculateStorageMetrics() {
        viewModelScope.launch(Dispatchers.IO) {
            val dbFile = context.getDatabasePath("kagenet_database")
            val dbSizeVal = if (dbFile.exists()) dbFile.length() else 0L

            val cacheDir = context.cacheDir
            val cacheSizeVal = getFolderSize(cacheDir)

            val downloadsDir = File(context.filesDir, "downloads")
            val legacySizeVal = getFolderSize(downloadsDir)
            val videoDir = KageDownloadManager.getDownloadFolder(context, "mp4")
            val videoSizeVal = getFolderSize(videoDir)
            val pdfDir = KageDownloadManager.getDownloadFolder(context, "pdf")
            val pdfSizeVal = getFolderSize(pdfDir)
            val downloadSizeVal = legacySizeVal + videoSizeVal + pdfSizeVal

            val totalAppSizeVal = dbSizeVal + cacheSizeVal + downloadSizeVal + getFolderSize(context.filesDir)

            val stat = StatFs(context.filesDir.absolutePath)
            val availableBytes = stat.availableBlocksLong * stat.blockSizeLong

            withContext(Dispatchers.Main) {
                storageDbSize.value = formatSize(dbSizeVal)
                storageCacheSize.value = formatSize(cacheSizeVal)
                storageDownloadSize.value = formatSize(downloadSizeVal)
                storageTotalSize.value = formatSize(totalAppSizeVal)
                storageFreeSize.value = formatSize(availableBytes)
            }
        }
    }

    private fun getFolderSize(file: File): Long {
        if (!file.exists()) return 0L
        if (file.isFile) return file.length()
        var size = 0L
        val files = file.listFiles()
        if (files != null) {
            for (f in files) {
                size += getFolderSize(f)
            }
        }
        return size
    }

    private fun formatSize(sizeBytes: Long): String {
        if (sizeBytes <= 0) return "0 B"
        val units = arrayOf("B", "KB", "MB", "GB", "TB")
        val digitGroups = (Math.log10(sizeBytes.toDouble()) / Math.log10(1024.0)).toInt()
        return DecimalFormat("#,##0.#").format(sizeBytes / Math.pow(1024.0, digitGroups.toDouble())) + " " + units[digitGroups]
    }
}
