package com.example.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.outlined.Notifications
import androidx.compose.material.icons.outlined.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.example.data.Anime
import com.example.data.Manga
import com.example.ui.KageViewModel
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

data class RecentEpisodeItem(
    val anime: Anime,
    val episode: com.example.data.Episode,
    val episodeIndex: Int
)

data class RecentChapterItem(
    val manga: Manga,
    val chapter: com.example.data.Chapter,
    val chapterIndex: Int
)

private fun isWithinLast7Days(dateString: String): Boolean {
    return try {
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val releaseDate = sdf.parse(dateString) ?: return false
        val currentDate = Date()
        val diffInMs = currentDate.time - releaseDate.time
        val diffInDays = TimeUnit.MILLISECONDS.toDays(diffInMs)
        diffInDays in -1..7
    } catch (e: Exception) {
        false
    }
}

@Composable
fun HomeScreen(
    viewModel: KageViewModel,
    onNavigateToAnime: (String) -> Unit,
    onNavigateToManga: (String) -> Unit,
    onNavigateToPlayer: (String, Int, Boolean) -> Unit,
    onNavigateToReader: (String, Int) -> Unit,
    onNavigateToNotifications: () -> Unit,
    onSearchTabClick: () -> Unit,
    onProfileTabClick: () -> Unit
) {
    val dbState by viewModel.databaseState.collectAsStateWithLifecycle()
    val favorites by viewModel.favoritesState.collectAsStateWithLifecycle()
    val watchLater by viewModel.watchLaterState.collectAsStateWithLifecycle()
    val readingList by viewModel.readingListState.collectAsStateWithLifecycle()
    val continueWatching by viewModel.continueWatchingState.collectAsStateWithLifecycle()
    val continueReading by viewModel.continueReadingState.collectAsStateWithLifecycle()
    val unreadNotifsCount by viewModel.unreadNotificationsCount.collectAsStateWithLifecycle()
    val profile by viewModel.profileState.collectAsStateWithLifecycle()

    // Grab items
    val animeList = dbState.anime
    val mangaList = dbState.manga

    val featuredItem = animeList.firstOrNull { it.id == dbState.featured.firstOrNull() }
        ?: animeList.firstOrNull()

    val trendingAnime = animeList.filter { dbState.trending.contains(it.id) }
    val trendingManga = mangaList.filter { dbState.trending.contains(it.id) }

    val recentEpisodes = remember(animeList) {
        animeList.flatMap { anime ->
            anime.episodes.mapIndexed { index, episode ->
                RecentEpisodeItem(anime, episode, index)
            }
        }.filter { isWithinLast7Days(it.episode.releaseDate) }
         .sortedByDescending { it.episode.releaseDate }
    }

    val recentChapters = remember(mangaList) {
        mangaList.flatMap { manga ->
            manga.chapters.mapIndexed { index, chapter ->
                RecentChapterItem(manga, chapter, index)
            }
        }.filter { isWithinLast7Days(it.chapter.releaseDate) }
         .sortedByDescending { it.chapter.releaseDate }
    }

    val favAnime = animeList.filter { anime -> favorites.any { it.itemId == anime.id && it.itemType == "anime" } }
    val favManga = mangaList.filter { manga -> favorites.any { it.itemId == manga.id && it.itemType == "manga" } }

    val watchLaterAnime = animeList.filter { anime -> watchLater.any { it.animeId == anime.id } }
    val readingListManga = mangaList.filter { manga -> readingList.any { it.mangaId == manga.id } }

    Scaffold(
        topBar = {
            KageHomeTopBar(
                unreadCount = unreadNotifsCount,
                profileAvatar = profile?.profilePicturePath,
                onNotificationsClick = onNavigateToNotifications,
                onRefreshClick = { viewModel.syncDatabaseNow() },
                onSearchClick = onSearchTabClick,
                onProfileClick = onProfileTabClick
            )
        },
        containerColor = KageDeepAbyss
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .testTag("home_screen_scroll"),
            contentPadding = PaddingValues(bottom = 24.dp)
        ) {
            // 1. Featured Banner
            if (featuredItem != null) {
                item {
                    val isAdded = watchLater.any { it.animeId == featuredItem.id }
                    FeaturedHeroBanner(
                        anime = featuredItem,
                        isAddedToList = isAdded,
                        onAddToListClick = { viewModel.toggleWatchLater(featuredItem.id) },
                        onWatchNowClick = { onNavigateToPlayer(featuredItem.id, 0, false) }
                    )
                }
            }

            // 2. Continue Watching (if exists)
            if (continueWatching.isNotEmpty()) {
                item {
                    RowHeader(title = "Continue Watching")
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(continueWatching) { item ->
                            val fullAnime = animeList.find { it.id == item.animeId }
                            ContinueWatchingCard(
                                title = item.episodeTitle,
                                animeTitle = fullAnime?.title ?: "Anime",
                                coverUrl = fullAnime?.cover ?: "",
                                position = item.playbackPosition,
                                duration = item.duration,
                                onClick = { onNavigateToPlayer(item.animeId, item.episodeIndex, false) }
                            )
                        }
                    }
                }
            }

            // 3. Continue Reading (if exists)
            if (continueReading.isNotEmpty()) {
                item {
                    RowHeader(title = "Continue Reading")
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(continueReading) { item ->
                            val fullManga = mangaList.find { it.id == item.mangaId }
                            ContinueReadingCard(
                                title = item.chapterTitle,
                                mangaTitle = fullManga?.title ?: "Manga",
                                coverUrl = fullManga?.cover ?: "",
                                lastPage = item.lastPage,
                                totalPages = item.totalPages,
                                onClick = { onNavigateToReader(item.mangaId, item.chapterIndex) }
                            )
                        }
                    }
                }
            }

            // 4. Trending Anime
            if (trendingAnime.isNotEmpty()) {
                item {
                    RowHeader(title = "Trending Anime")
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(trendingAnime) { anime ->
                            AnimeCard(anime = anime, onClick = { onNavigateToAnime(anime.id) })
                        }
                    }
                }
            }

            // 5. Trending Manga
            if (trendingManga.isNotEmpty()) {
                item {
                    RowHeader(title = "Trending Manga")
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(trendingManga) { manga ->
                            MangaCard(manga = manga, onClick = { onNavigateToManga(manga.id) })
                        }
                    }
                }
            }

            // 6. Recently Added Episodes (within last 7 days)
            if (recentEpisodes.isNotEmpty()) {
                item {
                    RowHeader(title = "Recently Added Episodes")
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(recentEpisodes) { item ->
                            RecentEpisodeCard(item = item, onClick = { onNavigateToPlayer(item.anime.id, item.episodeIndex, false) })
                        }
                    }
                }
            }

            // 7. Recently Added Chapters (within last 7 days)
            if (recentChapters.isNotEmpty()) {
                item {
                    RowHeader(title = "Recently Added Chapters")
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(recentChapters) { item ->
                            RecentChapterCard(item = item, onClick = { onNavigateToReader(item.manga.id, item.chapterIndex) })
                        }
                    }
                }
            }

            // 8. Favorites (if exists)
            if (favAnime.isNotEmpty() || favManga.isNotEmpty()) {
                item {
                    RowHeader(title = "Your Favorites")
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(favAnime) { anime ->
                            AnimeCard(anime = anime, onClick = { onNavigateToAnime(anime.id) })
                        }
                        items(favManga) { manga ->
                            MangaCard(manga = manga, onClick = { onNavigateToManga(manga.id) })
                        }
                    }
                }
            }

            // 9. Watch Later & Reading List
            if (watchLaterAnime.isNotEmpty() || readingListManga.isNotEmpty()) {
                item {
                    RowHeader(title = "Saved Lists")
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(watchLaterAnime) { anime ->
                            AnimeCard(anime = anime, onClick = { onNavigateToAnime(anime.id) })
                        }
                        items(readingListManga) { manga ->
                            MangaCard(manga = manga, onClick = { onNavigateToManga(manga.id) })
                        }
                    }
                }
            }

            // 10. Popular & Recommended (M3 styled list of all available items)
            item {
                RowHeader(title = "Recommended For You")
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    val recommendedList = (animeList + mangaList).shuffled().take(6)
                    recommendedList.forEach { item ->
                        when (item) {
                            is Anime -> RecommendedItemRow(
                                title = item.title,
                                subtitle = "${item.year} • ${item.studio} • ⭐ ${item.rating}",
                                type = "Anime",
                                coverUrl = item.cover,
                                onClick = { onNavigateToAnime(item.id) }
                            )
                            is Manga -> RecommendedItemRow(
                                title = item.title,
                                subtitle = "${item.year} • ${item.author} • ⭐ ${item.rating}",
                                type = "Manga",
                                coverUrl = item.cover,
                                onClick = { onNavigateToManga(item.id) }
                            )
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun KageHomeTopBar(
    unreadCount: Int,
    profileAvatar: String?,
    onNotificationsClick: () -> Unit,
    onRefreshClick: () -> Unit,
    onSearchClick: () -> Unit,
    onProfileClick: () -> Unit
) {
    TopAppBar(
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(start = 4.dp)
            ) {
                Text(
                    text = "KAGE NET",
                    fontWeight = FontWeight.Bold,
                    color = KageWhite,
                    fontSize = 20.sp,
                    letterSpacing = 1.5.sp
                )
            }
        },
        actions = {
            IconButton(
                onClick = onSearchClick,
                modifier = Modifier.minimumInteractiveComponentSize()
            ) {
                Icon(
                    imageVector = Icons.Filled.Search,
                    contentDescription = "Search",
                    tint = KageWhite,
                    modifier = Modifier.size(24.dp)
                )
            }
            IconButton(
                onClick = onRefreshClick,
                modifier = Modifier.minimumInteractiveComponentSize()
            ) {
                Icon(
                    imageVector = Icons.Filled.Refresh,
                    contentDescription = "Refresh",
                    tint = KageWhite.copy(alpha = 0.6f),
                    modifier = Modifier.size(20.dp)
                )
            }
            IconButton(
                onClick = onNotificationsClick,
                modifier = Modifier.minimumInteractiveComponentSize()
            ) {
                BadgedBox(
                    badge = {
                        if (unreadCount > 0) {
                            Badge(
                                containerColor = KageNeonBlue,
                                contentColor = Color.White
                            ) {
                                Text(text = unreadCount.toString(), fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                ) {
                    Icon(
                        imageVector = Icons.Outlined.Notifications,
                        contentDescription = "Notifications",
                        tint = KageWhite
                    )
                }
            }
            Spacer(modifier = Modifier.width(4.dp))
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .border(1.5.dp, KageNeonBlue, CircleShape)
                    .clickable { onProfileClick() }
            ) {
                AsyncImage(
                    model = profileAvatar?.ifEmpty { null } ?: "https://api.dicebear.com/7.x/adventurer/png?seed=KageNet",
                    contentDescription = "Profile",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
        },
        colors = TopAppBarDefaults.topAppBarColors(
            containerColor = KageDeepAbyss,
            titleContentColor = KageWhite
        )
    )
}

@Composable
fun FeaturedHeroBanner(
    anime: Anime,
    isAddedToList: Boolean,
    onAddToListClick: () -> Unit,
    onWatchNowClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(380.dp)
            .padding(16.dp)
            .clip(RoundedCornerShape(24.dp))
            .border(1.dp, Color(0xFF0C1D36), RoundedCornerShape(24.dp))
    ) {
        // Hero Background Banner Image
        AsyncImage(
            model = anime.banner.ifEmpty { anime.cover },
            contentDescription = "Featured Banner",
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
        )

        // Glass gradient overlay with blue vignette
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            Color.Transparent,
                            KageBlack.copy(alpha = 0.4f),
                            KageDeepAbyss
                        )
                    )
                )
        )

        // Content
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(18.dp),
            verticalArrangement = Arrangement.Bottom
        ) {
            // TOP PICK Tag
            Text(
                text = "TOP PICK",
                color = KageNeonBlue,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp,
                modifier = Modifier.padding(bottom = 8.dp)
            )

            // Title "JUJUTSU KAISEN" style
            Text(
                text = anime.title.uppercase(),
                color = KageWhite,
                fontSize = 28.sp,
                fontWeight = FontWeight.ExtraBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(modifier = Modifier.height(6.dp))

            // Subtitle
            Text(
                text = if (anime.title.contains("Jujutsu", ignoreCase = true)) {
                    "Season 2 Now Streaming"
                } else {
                    "${anime.status.lowercase().replaceFirstChar { it.uppercaseChar() }} Now Streaming"
                },
                color = KageNeonBlue,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(10.dp))

            // Description
            Text(
                text = anime.description,
                color = KageGray,
                fontSize = 11.sp,
                maxLines = 3,
                overflow = TextOverflow.Ellipsis,
                lineHeight = 15.sp
            )
            Spacer(modifier = Modifier.height(18.dp))
            
            // Watch now and Add list buttons
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // WATCH NOW Button
                Button(
                    onClick = onWatchNowClick,
                    colors = ButtonDefaults.buttonColors(containerColor = KageNeonBlue, contentColor = Color.Black),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 24.dp, vertical = 12.dp),
                    modifier = Modifier.testTag("featured_watch_now")
                ) {
                    Icon(
                        imageVector = Icons.Filled.PlayArrow,
                        contentDescription = "Play Icon",
                        modifier = Modifier.size(16.dp),
                        tint = Color.Black
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("WATCH NOW", fontWeight = FontWeight.Black, fontSize = 12.sp, letterSpacing = 0.5.sp)
                }

                // Plus / Added Circle Button
                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                        .border(1.dp, Color.White.copy(alpha = 0.6f), CircleShape)
                        .clickable { onAddToListClick() },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (isAddedToList) Icons.Filled.Check else Icons.Filled.Add,
                        contentDescription = "Add to list",
                        tint = KageWhite,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Centered Page Indicator Dots (4 dots)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                for (i in 0 until 4) {
                    val isActive = i == 0
                    Box(
                        modifier = Modifier
                            .padding(horizontal = 3.dp)
                            .size(
                                width = if (isActive) 16.dp else 6.dp,
                                height = 6.dp
                            )
                            .clip(CircleShape)
                            .background(
                                if (isActive) KageNeonBlue else Color.White.copy(alpha = 0.3f)
                            )
                    )
                }
            }
        }
    }
}

@Composable
fun RowHeader(title: String, onViewAllClick: (() -> Unit)? = {}) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(enabled = onViewAllClick != null) { onViewAllClick?.invoke() }
            .padding(start = 16.dp, top = 22.dp, end = 16.dp, bottom = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = title,
            color = KageWhite,
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.width(6.dp))
        Icon(
            imageVector = Icons.Filled.ChevronRight,
            contentDescription = "View all",
            tint = KageGray,
            modifier = Modifier.size(16.dp)
        )
    }
}

@Composable
fun AnimeCard(anime: Anime, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .width(130.dp)
            .clickable(onClick = onClick)
            .testTag("anime_card_${anime.id}"),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent)
    ) {
        Column {
            Box(
                modifier = Modifier
                    .width(130.dp)
                    .height(180.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(KageDarkCard)
                    .border(1.dp, Color(0xFF0C1D36), RoundedCornerShape(16.dp))
            ) {
                AsyncImage(
                    model = anime.cover,
                    contentDescription = anime.title,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
                // Rating Overlay
                Box(
                    modifier = Modifier
                        .padding(8.dp)
                        .background(Color.Black.copy(alpha = 0.65f), RoundedCornerShape(6.dp))
                        .border(0.5.dp, Color(0xFF0C1D36), RoundedCornerShape(6.dp))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                        .align(Alignment.TopEnd)
                ) {
                    Text(
                        text = "${anime.rating}★",
                        color = KageNeonBlue,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = anime.title,
                color = KageWhite,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(horizontal = 4.dp)
            )
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
            ) {
                Text(
                    text = "Series",
                    color = KageGray,
                    fontSize = 11.sp
                )
                Text(
                    text = " • ",
                    color = KageNeonBlue,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Sub | Dub",
                    color = KageGray,
                    fontSize = 11.sp
                )
            }
        }
    }
}

@Composable
fun MangaCard(manga: Manga, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .width(130.dp)
            .clickable(onClick = onClick)
            .testTag("manga_card_${manga.id}"),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent)
    ) {
        Column {
            Box(
                modifier = Modifier
                    .width(130.dp)
                    .height(180.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(KageDarkCard)
                    .border(1.dp, Color(0x1AFFFFFF), RoundedCornerShape(16.dp))
            ) {
                AsyncImage(
                    model = manga.cover,
                    contentDescription = manga.title,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
                // Rating Overlay
                Box(
                    modifier = Modifier
                        .padding(8.dp)
                        .background(Color.Black.copy(alpha = 0.65f), RoundedCornerShape(6.dp))
                        .border(0.5.dp, Color(0x4D38BDF8), RoundedCornerShape(6.dp))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                        .align(Alignment.TopEnd)
                ) {
                    Text(
                        text = "${manga.rating}★",
                        color = KageNeonBlue,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = manga.title,
                color = KageWhite,
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(horizontal = 4.dp)
            )
            val genreText = manga.genres.take(2).joinToString(", ")
            if (genreText.isNotEmpty()) {
                Text(
                    text = genreText,
                    color = KageGray,
                    fontSize = 11.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                )
            }
        }
    }
}

@Composable
fun ContinueWatchingCard(
    title: String,
    animeTitle: String,
    coverUrl: String,
    position: Long,
    duration: Long,
    onClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .width(160.dp)
            .clickable(onClick = onClick)
    ) {
        Card(
            modifier = Modifier
                .width(160.dp)
                .height(95.dp)
                .clip(RoundedCornerShape(12.dp))
                .border(1.dp, Color(0xFF0C1D36), RoundedCornerShape(12.dp)),
            colors = CardDefaults.cardColors(containerColor = KageDarkCard)
        ) {
            Box(modifier = Modifier.fillMaxSize()) {
                AsyncImage(
                    model = coverUrl,
                    contentDescription = animeTitle,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )

                // 3-dot menu button at top-right of the card
                IconButton(
                    onClick = { /* Optional menu trigger */ },
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(2.dp)
                        .size(24.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.MoreVert,
                        contentDescription = "Options",
                        tint = KageWhite,
                        modifier = Modifier.size(16.dp)
                    )
                }

                // Play Button Icon Overlay centered
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .clip(CircleShape)
                        .background(Color.Black.copy(alpha = 0.5f))
                        .align(Alignment.Center),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Filled.PlayArrow,
                        contentDescription = "Resume Icon",
                        tint = KageWhite,
                        modifier = Modifier.size(18.dp)
                    )
                }

                // Progress Indicator at the bottom of the card
                val progress = if (duration > 0) position.toFloat() / duration.toFloat() else 0f
                LinearProgressIndicator(
                    progress = { progress },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(3.dp)
                        .align(Alignment.BottomCenter),
                    color = KageNeonBlue,
                    trackColor = Color(0x33FFFFFF)
                )
            }
        }
        Spacer(modifier = Modifier.height(6.dp))
        // Text displayed outside card (underneath)
        Text(
            text = animeTitle,
            color = KageWhite,
            fontWeight = FontWeight.Bold,
            fontSize = 12.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(horizontal = 2.dp)
        )
        Text(
            text = title,
            color = KageGray,
            fontSize = 11.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(horizontal = 2.dp)
        )
    }
}

@Composable
fun ContinueReadingCard(
    title: String,
    mangaTitle: String,
    coverUrl: String,
    lastPage: Int,
    totalPages: Int,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .width(220.dp)
            .height(130.dp)
            .clip(RoundedCornerShape(16.dp))
            .border(1.dp, Color(0x1AFFFFFF), RoundedCornerShape(16.dp))
            .clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = KageDarkCard)
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            AsyncImage(
                model = coverUrl,
                contentDescription = mangaTitle,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop,
                alpha = 0.4f
            )

            // Content Overlay
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(12.dp),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Icon(
                    imageVector = Icons.Filled.MenuBook,
                    contentDescription = "Read Icon",
                    tint = KageNeonBlue,
                    modifier = Modifier
                        .size(28.dp)
                        .background(KageBlack.copy(alpha = 0.8f), RoundedCornerShape(20.dp))
                        .padding(5.dp)
                )

                Column {
                    Text(
                        text = mangaTitle,
                        color = KageWhite,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = title,
                        color = KageGray,
                        fontSize = 11.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(modifier = Modifier.height(6.dp))

                    val progress = if (totalPages > 0) lastPage.toFloat() / totalPages.toFloat() else 0f
                    LinearProgressIndicator(
                        progress = { progress },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(3.dp)
                            .clip(RoundedCornerShape(2.dp)),
                        color = KageNeonBlue,
                        trackColor = Color(0x44FFFFFF)
                    )
                }
            }
        }
    }
}

@Composable
fun RecommendedItemRow(
    title: String,
    subtitle: String,
    type: String,
    coverUrl: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(KageDarkCard)
            .border(0.5.dp, Color(0x1100D2FF), RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        AsyncImage(
            model = coverUrl,
            contentDescription = title,
            modifier = Modifier
                .size(50.dp)
                .clip(RoundedCornerShape(8.dp)),
            contentScale = ContentScale.Crop
        )
        Spacer(modifier = Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .background(
                            if (type == "Anime") Color(0x2200D2FF) else Color(0x2200FF88),
                            RoundedCornerShape(4.dp)
                        )
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = type.uppercase(),
                        color = if (type == "Anime") KageNeonBlue else KageGreen,
                        fontSize = 8.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = title,
                color = KageWhite,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = subtitle,
                color = KageGray,
                fontSize = 11.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        Icon(
            imageVector = Icons.Filled.ChevronRight,
            contentDescription = "Arrow Right",
            tint = KageGray,
            modifier = Modifier.size(20.dp)
        )
    }
}

@Composable
fun QuickStatsBar(totalEpisodes: Int, librarySize: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Stat 1: Episodes
        Box(
            modifier = Modifier
                .weight(1f)
                .background(Color(0x0DFFFFFF), RoundedCornerShape(20.dp))
                .border(1.dp, Color(0x1AFFFFFF), RoundedCornerShape(20.dp))
                .padding(vertical = 12.dp, horizontal = 8.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = "EPISODES",
                    color = KageWhite.copy(alpha = 0.4f),
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.5.sp
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "$totalEpisodes+",
                    color = KageNeonBlue,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Black
                )
            }
        }

        // Stat 2: Library
        Box(
            modifier = Modifier
                .weight(1f)
                .background(Color(0x0DFFFFFF), RoundedCornerShape(20.dp))
                .border(1.dp, Color(0x1AFFFFFF), RoundedCornerShape(20.dp))
                .padding(vertical = 12.dp, horizontal = 8.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = "LIBRARY",
                    color = KageWhite.copy(alpha = 0.4f),
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.5.sp
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = librarySize,
                    color = KageWhite,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Black
                )
            }
        }

        // Stat 3: Sync
        Box(
            modifier = Modifier
                .weight(1f)
                .background(Color(0x0DFFFFFF), RoundedCornerShape(20.dp))
                .border(1.dp, Color(0x1AFFFFFF), RoundedCornerShape(20.dp))
                .padding(vertical = 12.dp, horizontal = 8.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = "SYNC",
                    color = KageWhite.copy(alpha = 0.4f),
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.5.sp
                )
                Spacer(modifier = Modifier.height(2.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(6.dp)
                            .clip(CircleShape)
                            .background(KageGreen)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "Ready",
                        color = KageGreen,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Black
                    )
                }
            }
        }
    }
}

@Composable
fun RecentEpisodeCard(item: RecentEpisodeItem, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .width(160.dp)
            .clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent)
    ) {
        Column {
            Box(
                modifier = Modifier
                    .width(160.dp)
                    .height(100.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(KageDarkCard)
                    .border(1.dp, Color(0xFF0C1D36), RoundedCornerShape(12.dp))
            ) {
                AsyncImage(
                    model = if (item.episode.thumbnail.isNotEmpty()) item.episode.thumbnail else item.anime.cover,
                    contentDescription = item.episode.title,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
                
                // Episode Badge "NEW EPISODE" in white text
                Box(
                    modifier = Modifier
                        .padding(8.dp)
                        .background(KageNeonBlue, RoundedCornerShape(4.dp))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                        .align(Alignment.TopStart)
                ) {
                    Text(
                        text = "NEW EPISODE",
                        color = Color.White,
                        fontSize = 8.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                // Play Button Icon Overlay
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .clip(CircleShape)
                        .background(Color.Black.copy(alpha = 0.5f))
                        .align(Alignment.Center),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Filled.PlayArrow,
                        contentDescription = "Play",
                        tint = KageWhite,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = item.episode.title,
                color = KageWhite,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(horizontal = 2.dp)
            )
            Text(
                text = item.anime.title,
                color = KageGray,
                fontSize = 11.sp,
                fontWeight = FontWeight.Medium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(horizontal = 2.dp)
            )
            // Show release date
            Text(
                text = "Released: " + item.episode.releaseDate,
                color = KageNeonBlue.copy(alpha = 0.8f),
                fontSize = 10.sp,
                fontWeight = FontWeight.Medium,
                modifier = Modifier.padding(horizontal = 2.dp, vertical = 1.dp)
            )
        }
    }
}

@Composable
fun RecentChapterCard(item: RecentChapterItem, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .width(160.dp)
            .clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent)
    ) {
        Column {
            Box(
                modifier = Modifier
                    .width(160.dp)
                    .height(100.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(KageDarkCard)
                    .border(1.dp, Color(0x1AFFFFFF), RoundedCornerShape(12.dp))
            ) {
                AsyncImage(
                    model = if (item.chapter.cover.isNotEmpty()) item.chapter.cover else item.manga.cover,
                    contentDescription = item.chapter.title,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
                
                // Chapter Badge
                Box(
                    modifier = Modifier
                        .padding(8.dp)
                        .background(KageGreen, RoundedCornerShape(4.dp))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                        .align(Alignment.TopStart)
                ) {
                    Text(
                        text = "CHAPTER ${item.chapter.number}",
                        color = KageBlack,
                        fontSize = 8.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                // Book / Read Icon Overlay
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .clip(CircleShape)
                        .background(Color.Black.copy(alpha = 0.6f))
                        .align(Alignment.Center),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Filled.MenuBook,
                        contentDescription = "Read",
                        tint = KageGreen,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = item.chapter.title,
                color = KageWhite,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(horizontal = 2.dp)
            )
            Text(
                text = item.manga.title,
                color = KageGray,
                fontSize = 11.sp,
                fontWeight = FontWeight.Medium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(horizontal = 2.dp)
            )
            // Show release date
            Text(
                text = "Released: " + item.chapter.releaseDate,
                color = KageGreen,
                fontSize = 10.sp,
                fontWeight = FontWeight.Medium,
                modifier = Modifier.padding(horizontal = 2.dp, vertical = 1.dp)
            )
        }
    }
}

