package com.example.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

@Dao
interface UserProfileDao {
    @Query("SELECT * FROM user_profiles WHERE id = 'local_user' LIMIT 1")
    fun getProfileFlow(): Flow<UserProfile?>

    @Query("SELECT * FROM user_profiles WHERE id = 'local_user' LIMIT 1")
    suspend fun getProfile(): UserProfile?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProfile(profile: UserProfile)
}

@Dao
interface FavoriteDao {
    @Query("SELECT * FROM favorites")
    fun getAllFlow(): Flow<List<Favorite>>

    @Query("SELECT EXISTS(SELECT 1 FROM favorites WHERE itemId = :itemId AND itemType = :itemType)")
    fun isFavoriteFlow(itemId: String, itemType: String): Flow<Boolean>

    @Query("SELECT EXISTS(SELECT 1 FROM favorites WHERE itemId = :itemId AND itemType = :itemType)")
    suspend fun isFavorite(itemId: String, itemType: String): Boolean

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(favorite: Favorite)

    @Query("DELETE FROM favorites WHERE itemId = :itemId AND itemType = :itemType")
    suspend fun delete(itemId: String, itemType: String)
}

@Dao
interface WatchLaterDao {
    @Query("SELECT * FROM watch_later")
    fun getAllFlow(): Flow<List<WatchLater>>

    @Query("SELECT EXISTS(SELECT 1 FROM watch_later WHERE animeId = :animeId)")
    fun isWatchLaterFlow(animeId: String): Flow<Boolean>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(watchLater: WatchLater)

    @Query("DELETE FROM watch_later WHERE animeId = :animeId")
    suspend fun delete(animeId: String)
}

@Dao
interface ReadingListDao {
    @Query("SELECT * FROM reading_lists")
    fun getAllFlow(): Flow<List<ReadingList>>

    @Query("SELECT EXISTS(SELECT 1 FROM reading_lists WHERE mangaId = :mangaId)")
    fun isReadingListFlow(mangaId: String): Flow<Boolean>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(readingList: ReadingList)

    @Query("DELETE FROM reading_lists WHERE mangaId = :mangaId")
    suspend fun delete(mangaId: String)
}

@Dao
interface ContinueWatchingDao {
    @Query("SELECT * FROM continue_watching ORDER BY timestamp DESC")
    fun getAllFlow(): Flow<List<ContinueWatching>>

    @Query("SELECT * FROM continue_watching WHERE animeId = :animeId LIMIT 1")
    suspend fun getForAnime(animeId: String): ContinueWatching?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(continueWatching: ContinueWatching)

    @Query("DELETE FROM continue_watching WHERE animeId = :animeId")
    suspend fun delete(animeId: String)
}

@Dao
interface ContinueReadingDao {
    @Query("SELECT * FROM continue_reading ORDER BY timestamp DESC")
    fun getAllFlow(): Flow<List<ContinueReading>>

    @Query("SELECT * FROM continue_reading WHERE mangaId = :mangaId LIMIT 1")
    suspend fun getForManga(mangaId: String): ContinueReading?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(continueReading: ContinueReading)

    @Query("DELETE FROM continue_reading WHERE mangaId = :mangaId")
    suspend fun delete(mangaId: String)
}

@Dao
interface HistoryDao {
    @Query("SELECT * FROM watch_histories ORDER BY timestamp DESC")
    fun getWatchHistoriesFlow(): Flow<List<WatchHistory>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWatchHistory(watchHistory: WatchHistory)

    @Query("SELECT * FROM reading_histories ORDER BY timestamp DESC")
    fun getReadingHistoriesFlow(): Flow<List<ReadingHistory>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReadingHistory(readingHistory: ReadingHistory)

    @Query("DELETE FROM watch_histories")
    suspend fun clearWatchHistory()

    @Query("DELETE FROM reading_histories")
    suspend fun clearReadingHistory()
}

@Dao
interface RatingDao {
    @Query("SELECT * FROM ratings WHERE itemId = :itemId AND itemType = :itemType LIMIT 1")
    fun getRatingFlow(itemId: String, itemType: String): Flow<Rating?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRating(rating: Rating)
}

@Dao
interface NotificationDao {
    @Query("SELECT * FROM notifications ORDER BY timestamp DESC")
    fun getAllNotificationsFlow(): Flow<List<NotificationEntity>>

    @Query("SELECT COUNT(*) FROM notifications WHERE isRead = 0")
    fun getUnreadCountFlow(): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNotifications(notifications: List<NotificationEntity>)

    @Query("UPDATE notifications SET isRead = 1 WHERE id = :id")
    suspend fun markAsRead(id: String)

    @Query("UPDATE notifications SET isRead = 1")
    suspend fun markAllAsRead()
}

@Dao
interface DownloadDao {
    @Query("SELECT * FROM downloads")
    fun getAllFlow(): Flow<List<DownloadItem>>

    @Query("SELECT * FROM downloads WHERE downloadId = :downloadId LIMIT 1")
    suspend fun getById(downloadId: String): DownloadItem?

    @Query("SELECT * FROM downloads WHERE status = 'downloading' OR status = 'pending' ORDER BY downloadId ASC")
    suspend fun getActiveQueue(): List<DownloadItem>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(downloadItem: DownloadItem)

    @Query("UPDATE downloads SET downloadedBytes = :downloadedBytes, speedBytesPerSec = :speed, remainingTimeSeconds = :remaining, progress = :progress, status = :status WHERE downloadId = :downloadId")
    suspend fun updateProgress(downloadId: String, downloadedBytes: Long, speed: Long, remaining: Long, progress: Int, status: String)

    @Query("UPDATE downloads SET status = :status WHERE downloadId = :downloadId")
    suspend fun updateStatus(downloadId: String, status: String)

    @Query("DELETE FROM downloads WHERE downloadId = :downloadId")
    suspend fun delete(downloadId: String)

    @Query("DELETE FROM downloads WHERE fileType = 'mp4'")
    suspend fun deleteAllVideoDownloads()

    @Query("DELETE FROM downloads WHERE fileType = 'pdf'")
    suspend fun deleteAllPdfDownloads()

    @Query("DELETE FROM downloads")
    suspend fun deleteAllDownloads()
}

@Dao
interface CacheDao {
    @Query("SELECT * FROM cache_entries WHERE `key` = :key LIMIT 1")
    suspend fun getEntry(key: String): CacheEntry?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEntry(entry: CacheEntry)

    @Query("DELETE FROM cache_entries WHERE `key` = :key")
    suspend fun deleteEntry(key: String)
}

@Database(
    entities = [
        UserProfile::class,
        Favorite::class,
        WatchLater::class,
        ReadingList::class,
        ContinueWatching::class,
        ContinueReading::class,
        WatchHistory::class,
        ReadingHistory::class,
        Rating::class,
        NotificationEntity::class,
        DownloadItem::class,
        CacheEntry::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun userProfileDao(): UserProfileDao
    abstract fun favoriteDao(): FavoriteDao
    abstract fun watchLaterDao(): WatchLaterDao
    abstract fun readingListDao(): ReadingListDao
    abstract fun continueWatchingDao(): ContinueWatchingDao
    abstract fun continueReadingDao(): ContinueReadingDao
    abstract fun historyDao(): HistoryDao
    abstract fun ratingDao(): RatingDao
    abstract fun notificationDao(): NotificationDao
    abstract fun downloadDao(): DownloadDao
    abstract fun cacheDao(): CacheDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "kagenet_database"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
