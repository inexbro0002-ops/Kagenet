package com.example.data

object ApiConfig {
    // Modify these URLs when moving to another server
    const val DATABASE_URL = "https://kagenet.ct.ws/database.json?i=1"
    const val VERSION_URL = "https://kagenet.ct.ws/version.json"
}
