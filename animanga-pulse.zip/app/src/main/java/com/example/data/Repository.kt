package com.example.data

import android.content.Context
import android.util.Log
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

class KageRepository(private val context: Context) {

    private val db = AppDatabase.getDatabase(context)
    private val client = OkHttpClient.Builder().build()
    
    private val moshi = Moshi.Builder()
        .add(KotlinJsonAdapterFactory())
        .build()
        
    private val databaseAdapter = moshi.adapter(DatabaseResponse::class.java)
    private val versionAdapter = moshi.adapter(VersionResponse::class.java)

    // Flow exposing the active database (loaded from local cache or fallback)
    private val _databaseState = MutableStateFlow<DatabaseResponse>(FallbackDatabase.mockDatabase)
    val databaseState: StateFlow<DatabaseResponse> = _databaseState.asStateFlow()

    private val _isSyncing = MutableStateFlow(false)
    val isSyncing: StateFlow<Boolean> = _isSyncing.asStateFlow()

    private val _syncError = MutableSharedFlow<String?>()
    val syncError: SharedFlow<String?> = _syncError.asSharedFlow()

    private val _lastSyncTime = MutableStateFlow<Long>(0L)
    val lastSyncTime: StateFlow<Long> = _lastSyncTime.asStateFlow()

    private val _currentDbVersion = MutableStateFlow(0)
    val currentDbVersion: StateFlow<Int> = _currentDbVersion.asStateFlow()

    // Exposed Flows from DAOs
    val profileFlow: Flow<UserProfile?> = db.userProfileDao().getProfileFlow()
    val favoritesFlow: Flow<List<Favorite>> = db.favoriteDao().getAllFlow()
    val watchLaterFlow: Flow<List<WatchLater>> = db.watchLaterDao().getAllFlow()
    val readingListFlow: Flow<List<ReadingList>> = db.readingListDao().getAllFlow()
    val continueWatchingFlow: Flow<List<ContinueWatching>> = db.continueWatchingDao().getAllFlow()
    val continueReadingFlow: Flow<List<ContinueReading>> = db.continueReadingDao().getAllFlow()
    val watchHistoryFlow: Flow<List<WatchHistory>> = db.historyDao().getWatchHistoriesFlow()
    val readingHistoryFlow: Flow<List<ReadingHistory>> = db.historyDao().getReadingHistoriesFlow()
    val notificationsFlow: Flow<List<NotificationEntity>> = db.notificationDao().getAllNotificationsFlow()
    val unreadNotificationsCount: Flow<Int> = db.notificationDao().getUnreadCountFlow()
    val downloadsFlow: Flow<List<DownloadItem>> = db.downloadDao().getAllFlow()

    init {
        // Load initial cache from local database immediately on startup
        CoroutineScope(Dispatchers.IO).launch {
            loadDatabaseFromCache()
        }
    }

    private suspend fun loadDatabaseFromCache() {
        try {
            val dbVersionEntry = db.cacheDao().getEntry("db_version")
            val dbJsonEntry = db.cacheDao().getEntry("db_json")
            val syncTimeEntry = db.cacheDao().getEntry("last_sync_time")

            if (syncTimeEntry != null) {
                _lastSyncTime.value = syncTimeEntry.value.toLongOrNull() ?: 0L
            }
            if (dbVersionEntry != null) {
                _currentDbVersion.value = dbVersionEntry.value.toIntOrNull() ?: 0
            }

            if (dbJsonEntry != null) {
                val parsed = withContext(Dispatchers.Default) {
                    databaseAdapter.fromJson(dbJsonEntry.value)
                }
                if (parsed != null) {
                    _databaseState.value = parsed
                    Log.d("KageRepository", "Successfully loaded database.json from Room cache")
                    return
                }
            }
            // Fallback to mock database if cache is empty
            _databaseState.value = FallbackDatabase.mockDatabase
        } catch (e: Exception) {
            Log.e("KageRepository", "Error loading database from cache", e)
            _databaseState.value = FallbackDatabase.mockDatabase
        }
    }

    // Version update sync method
    suspend fun syncDatabase(force: Boolean = false): Boolean = withContext(Dispatchers.IO) {
        if (_isSyncing.value) return@withContext false
        _isSyncing.value = true
        Log.d("KageRepository", "Starting sync database flow (force=$force)")

        try {
            // 1. Download version.json
            val versionReq = Request.Builder().url(ApiConfig.VERSION_URL).build()
            var remoteVersion = 1
            var isNewVersion = false

            try {
                client.newCall(versionReq).execute().use { response ->
                    if (response.isSuccessful) {
                        val body = response.body?.string()
                        if (body != null) {
                            val remoteVerObj = versionAdapter.fromJson(body)
                            if (remoteVerObj != null) {
                                remoteVersion = remoteVerObj.version
                                val localVersionEntry = db.cacheDao().getEntry("db_version")
                                val localVersion = localVersionEntry?.value?.toIntOrNull() ?: 0
                                isNewVersion = remoteVersion != localVersion
                                Log.d("KageRepository", "Version check: remote=$remoteVersion, local=$localVersion")
                            }
                        }
                    } else {
                        Log.w("KageRepository", "Failed to download version.json: ${response.code}")
                    }
                }
            } catch (e: Exception) {
                Log.w("KageRepository", "Network exception when getting version.json: ${e.message}")
                if (!force) {
                    // Non-forced update fails gracefully, keep using cached database
                    _isSyncing.value = false
                    return@withContext false
                }
                isNewVersion = true // Force sync will pull database.json directly
            }

            // 2. Determine if database.json should be downloaded
            if (isNewVersion || force || db.cacheDao().getEntry("db_json") == null) {
                Log.d("KageRepository", "Downloading database.json from ${ApiConfig.DATABASE_URL}")
                val dbReq = Request.Builder().url(ApiConfig.DATABASE_URL).build()
                
                client.newCall(dbReq).execute().use { response ->
                    if (response.isSuccessful) {
                        val body = response.body?.string()
                        if (body != null) {
                            val parsed = withContext(Dispatchers.Default) {
                                databaseAdapter.fromJson(body)
                            }
                            if (parsed != null) {
                                // Compare old and new database files to notify about new products
                                val oldState = _databaseState.value
                                val oldAnimeIds = oldState.anime.map { it.id }.toSet()
                                val oldMangaIds = oldState.manga.map { it.id }.toSet()

                                // Save to Room local cache
                                db.cacheDao().insertEntry(CacheEntry("db_json", body))
                                db.cacheDao().insertEntry(CacheEntry("db_version", remoteVersion.toString()))
                                
                                val now = System.currentTimeMillis()
                                db.cacheDao().insertEntry(CacheEntry("last_sync_time", now.toString()))
                                
                                _currentDbVersion.value = remoteVersion
                                _lastSyncTime.value = now
                                _databaseState.value = parsed

                                // Sync notification entries from downloaded JSON to notifications table
                                val entities = parsed.notifications.map { remote ->
                                    NotificationEntity(
                                        id = remote.id,
                                        title = remote.title,
                                        content = remote.content,
                                        timestamp = parseIsoDate(remote.timestamp)
                                    )
                                }
                                db.notificationDao().insertNotifications(entities)

                                // Compare lists
                                if (oldAnimeIds.isNotEmpty() && !oldAnimeIds.contains("anime_1")) {
                                    val newAnimes = parsed.anime.filter { it.id !in oldAnimeIds }
                                    val newMangas = parsed.manga.filter { it.id !in oldMangaIds }

                                    val newEntities = mutableListOf<NotificationEntity>()
                                    newAnimes.forEach { anime ->
                                        newEntities.add(NotificationEntity(
                                            id = "new_anime_${anime.id}_${System.currentTimeMillis()}",
                                            title = "🆕 New Anime: ${anime.title}",
                                            content = "We have added ${anime.title} to KageNet! Genres: ${anime.genres.joinToString(", ")}.",
                                            timestamp = System.currentTimeMillis()
                                        ))
                                    }
                                    newMangas.forEach { manga ->
                                        newEntities.add(NotificationEntity(
                                            id = "new_manga_${manga.id}_${System.currentTimeMillis()}",
                                            title = "📖 New Manga: ${manga.title}",
                                            content = "We have added ${manga.title} to KageNet! Genres: ${manga.genres.joinToString(", ")}.",
                                            timestamp = System.currentTimeMillis()
                                        ))
                                    }

                                    if (newEntities.isNotEmpty()) {
                                        db.notificationDao().insertNotifications(newEntities)
                                        val totalNew = newAnimes.size + newMangas.size
                                        if (totalNew > 3) {
                                            com.example.ui.NotificationHelper.showSystemNotification(
                                                context = context,
                                                id = 1001,
                                                title = "🔥 New Releases Available!",
                                                content = "KageNet added $totalNew new titles: ${newAnimes.take(2).joinToString { it.title }} and others."
                                            )
                                        } else {
                                            newAnimes.forEach { anime ->
                                                com.example.ui.NotificationHelper.showSystemNotification(
                                                    context = context,
                                                    id = anime.id.hashCode(),
                                                    title = "🆕 New Anime: ${anime.title}",
                                                    content = "Now streaming on KageNet: ${anime.title} (${anime.year})"
                                                )
                                            }
                                            newMangas.forEach { manga ->
                                                com.example.ui.NotificationHelper.showSystemNotification(
                                                    context = context,
                                                    id = manga.id.hashCode(),
                                                    title = "📖 New Manga: ${manga.title}",
                                                    content = "Now reading on KageNet: ${manga.title} (${manga.year})"
                                                )
                                            }
                                        }
                                    } else if (force) {
                                        val syncNotif = NotificationEntity(
                                            id = "sync_complete_${System.currentTimeMillis()}",
                                            title = "🔄 Database Refreshed",
                                            content = "KageNet database has been updated successfully! Checked ${parsed.anime.size} anime and ${parsed.manga.size} manga.",
                                            timestamp = System.currentTimeMillis()
                                        )
                                        db.notificationDao().insertNotifications(listOf(syncNotif))

                                        com.example.ui.NotificationHelper.showSystemNotification(
                                            context = context,
                                            id = 9999,
                                            title = "🔄 KageNet Database Refreshed",
                                            content = "All content is up-to-date. Verified ${parsed.anime.size} anime & ${parsed.manga.size} manga."
                                        )
                                    }
                                } else {
                                    if (force) {
                                        val syncNotif = NotificationEntity(
                                            id = "sync_complete_${System.currentTimeMillis()}",
                                            title = "🔄 Sync Completed",
                                            content = "Successfully loaded database! Ready to watch offline.",
                                            timestamp = System.currentTimeMillis()
                                        )
                                        db.notificationDao().insertNotifications(listOf(syncNotif))

                                        com.example.ui.NotificationHelper.showSystemNotification(
                                            context = context,
                                            id = 9999,
                                            title = "🔄 KageNet Sync Completed",
                                            content = "Successfully synchronized with the KageNet servers!"
                                        )
                                    }
                                }

                                Log.d("KageRepository", "Successfully synced and updated database!")
                            } else {
                                throw Exception("Parsing database.json failed")
                            }
                        } else {
                            throw Exception("Empty response body for database.json")
                        }
                    } else {
                        throw Exception("Failed to fetch database.json: Server returned ${response.code}")
                    }
                }
            } else {
                Log.d("KageRepository", "Local version is up to date. No need to download database.json.")
                // Update sync time
                val now = System.currentTimeMillis()
                db.cacheDao().insertEntry(CacheEntry("last_sync_time", now.toString()))
                _lastSyncTime.value = now
            }
            
            _isSyncing.value = false
            true
        } catch (e: Exception) {
            Log.e("KageRepository", "Error during syncDatabase", e)
            _syncError.emit(e.localizedMessage ?: "Sync connection failed")
            _isSyncing.value = false
            // On failure, reload from cache to ensure UI is updated
            loadDatabaseFromCache()
            false
        }
    }

    private fun parseIsoDate(isoString: String): Long {
        return try {
            val sdf = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US)
            sdf.timeZone = TimeZone.getTimeZone("UTC")
            sdf.parse(isoString)?.time ?: System.currentTimeMillis()
        } catch (e: Exception) {
            System.currentTimeMillis()
        }
    }

    // Cache clearing logic
    suspend fun clearCache() {
        withContext(Dispatchers.IO) {
            // Delete cache entries but do NOT delete user state or downloads files!
            db.cacheDao().deleteEntry("db_json")
            db.cacheDao().deleteEntry("db_version")
            db.cacheDao().deleteEntry("last_sync_time")
            _currentDbVersion.value = 0
            _lastSyncTime.value = 0
            // Reset state flow to mock database
            _databaseState.value = FallbackDatabase.mockDatabase
        }
    }

    // User Profile Actions
    suspend fun saveProfile(username: String, email: String, profilePicPath: String?) {
        val currentProfile = db.userProfileDao().getProfile() ?: UserProfile()
        val updated = currentProfile.copy(
            username = username,
            email = email,
            profilePicturePath = profilePicPath,
            isLoggedIn = true
        )
        db.userProfileDao().insertProfile(updated)
    }

    suspend fun logout() {
        val currentProfile = db.userProfileDao().getProfile() ?: UserProfile()
        db.userProfileDao().insertProfile(currentProfile.copy(isLoggedIn = false))
    }

    // Favorite Actions
    suspend fun toggleFavorite(itemId: String, itemType: String) {
        val isFav = db.favoriteDao().isFavorite(itemId, itemType)
        if (isFav) {
            db.favoriteDao().delete(itemId, itemType)
        } else {
            db.favoriteDao().insert(Favorite(id = "${itemId}_${itemType}", itemId = itemId, itemType = itemType))
        }
    }

    // Watch Later / Reading List
    suspend fun toggleWatchLater(animeId: String) {
        val currentList = db.watchLaterDao().getAllFlow().first()
        val exists = currentList.any { it.animeId == animeId }
        if (exists) {
            db.watchLaterDao().delete(animeId)
        } else {
            db.watchLaterDao().insert(WatchLater(animeId))
        }
    }

    suspend fun toggleReadingList(mangaId: String) {
        val currentList = db.readingListDao().getAllFlow().first()
        val exists = currentList.any { it.mangaId == mangaId }
        if (exists) {
            db.readingListDao().delete(mangaId)
        } else {
            db.readingListDao().insert(ReadingList(mangaId))
        }
    }

    // Continue Watching / Reading State
    suspend fun saveContinueWatching(animeId: String, episodeIndex: Int, title: String, position: Long, duration: Long) {
        db.continueWatchingDao().insert(
            ContinueWatching(
                animeId = animeId,
                episodeIndex = episodeIndex,
                episodeTitle = title,
                playbackPosition = position,
                duration = duration
            )
        )
        // Add to history list as well
        db.historyDao().insertWatchHistory(
            WatchHistory(
                id = "${animeId}_${episodeIndex}",
                animeId = animeId,
                episodeIndex = episodeIndex,
                episodeTitle = title
            )
        )
    }

    suspend fun saveContinueReading(mangaId: String, chapterIndex: Int, title: String, lastPage: Int, totalPages: Int) {
        db.continueReadingDao().insert(
            ContinueReading(
                mangaId = mangaId,
                chapterIndex = chapterIndex,
                chapterTitle = title,
                lastPage = lastPage,
                totalPages = totalPages
            )
        )
        // Add to reading history as well
        db.historyDao().insertReadingHistory(
            ReadingHistory(
                id = "${mangaId}_${chapterIndex}",
                mangaId = mangaId,
                chapterIndex = chapterIndex,
                chapterTitle = title
            )
        )
    }

    // Ratings
    suspend fun setRating(itemId: String, itemType: String, score: Double) {
        db.ratingDao().insertRating(Rating(id = "${itemId}_${itemType}", itemId = itemId, itemType = itemType, score = score))
    }

    fun getRatingFlow(itemId: String, itemType: String): Flow<Rating?> = db.ratingDao().getRatingFlow(itemId, itemType)

    // Notification mark as read
    suspend fun markNotificationAsRead(id: String) {
        db.notificationDao().markAsRead(id)
    }

    suspend fun markAllNotificationsAsRead() {
        db.notificationDao().markAllAsRead()
    }

    // Storage Manager Deletions
    suspend fun deleteVideoDownloads() {
        db.downloadDao().deleteAllVideoDownloads()
    }

    suspend fun deletePdfDownloads() {
        db.downloadDao().deleteAllPdfDownloads()
    }

    suspend fun deleteAllDownloads() {
        db.downloadDao().deleteAllDownloads()
    }

    // Hero and Trending section manual management
    suspend fun updateHeroSection(animeId: String) = withContext(Dispatchers.IO) {
        val currentDb = _databaseState.value
        // Put the chosen animeId as the first in featured list
        val updatedFeatured = listOf(animeId) + currentDb.featured.filter { it != animeId }
        val updatedDb = currentDb.copy(featured = updatedFeatured)
        
        _databaseState.value = updatedDb
        try {
            val jsonStr = databaseAdapter.toJson(updatedDb)
            db.cacheDao().insertEntry(CacheEntry("db_json", jsonStr))
            Log.d("KageRepository", "Hero section updated to: $animeId and persisted in Room")
        } catch (e: Exception) {
            Log.e("KageRepository", "Error persisting updated hero section", e)
        }
    }

    suspend fun toggleTrendingStatus(itemId: String) = withContext(Dispatchers.IO) {
        val currentDb = _databaseState.value
        val isCurrentlyTrending = currentDb.trending.contains(itemId)
        val updatedTrending = if (isCurrentlyTrending) {
            currentDb.trending.filter { it != itemId }
        } else {
            currentDb.trending + itemId
        }
        val updatedDb = currentDb.copy(trending = updatedTrending)
        
        _databaseState.value = updatedDb
        try {
            val jsonStr = databaseAdapter.toJson(updatedDb)
            db.cacheDao().insertEntry(CacheEntry("db_json", jsonStr))
            Log.d("KageRepository", "Trending status toggled for: $itemId and persisted in Room")
        } catch (e: Exception) {
            Log.e("KageRepository", "Error persisting updated trending status", e)
        }
    }
}
