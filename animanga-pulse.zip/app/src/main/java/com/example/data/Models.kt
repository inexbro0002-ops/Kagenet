package com.example.data

import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class VersionResponse(
    val version: Int,
    val lastUpdated: String
)

@JsonClass(generateAdapter = true)
data class DatabaseResponse(
    val anime: List<Anime> = emptyList(),
    val manga: List<Manga> = emptyList(),
    val featured: List<String> = emptyList(), // list of anime/manga IDs
    val trending: List<String> = emptyList(),
    val latest: List<String> = emptyList(),
    val notifications: List<RemoteNotification> = emptyList()
)

@JsonClass(generateAdapter = true)
data class Anime(
    val id: String,
    val title: String,
    val description: String,
    val genres: List<String> = emptyList(),
    val rating: Double = 0.0,
    val status: String = "",
    val year: Int = 2026,
    val cover: String = "",
    val banner: String = "",
    val episodes: List<Episode> = emptyList(),
    val studio: String = "KageStudio"
)

@JsonClass(generateAdapter = true)
data class Episode(
    val episode: Int,
    val title: String,
    val description: String = "",
    val thumbnail: String = "",
    val mp4: String,
    val subtitles: List<String> = emptyList(),
    val qualities: List<String> = emptyList(),
    val releaseDate: String = "2026-07-06",
    val driveLinks: Map<String, String>? = null,
    val serverLinks: Map<String, String>? = null
)

@JsonClass(generateAdapter = true)
data class Manga(
    val id: String,
    val title: String,
    val description: String,
    val cover: String = "",
    val banner: String = "",
    val chapters: List<Chapter> = emptyList(),
    val author: String = "KageAuthor",
    val status: String = "Ongoing",
    val rating: Double = 0.0,
    val genres: List<String> = emptyList(),
    val year: Int = 2026
)

@JsonClass(generateAdapter = true)
data class Chapter(
    val number: Int,
    val title: String,
    val cover: String = "",
    val pdf: String,
    val releaseDate: String = "2026-07-06"
)

@JsonClass(generateAdapter = true)
data class RemoteNotification(
    val id: String,
    val title: String,
    val content: String,
    val timestamp: String
)

object FallbackDatabase {
    val mockDatabase = DatabaseResponse(
        anime = listOf(
            Anime(
                id = "anime_1",
                title = "Kage no Jitsuryokusha ni Naritakute!",
                description = "Even in his past life, Cid\'s dream wasn\'t to become a protagonist or a final boss. He\'d rather lie low as a minor character until it\'s time to reveal he\'s a mastermind... or at least, do the next best thing-pretend to be one! And now that he\'s been reborn into another world, he\'s ready to set the perfect conditions to live out his dreams to the fullest.",
                genres = listOf("Action", "Fantasy", "Comedy", "Isekai"),
                rating = 9.2,
                status = "Completed",
                year = 2023,
                cover = "https://images.unsplash.com/photo-1578632767115-351597cf2477?w=500&q=80",
                banner = "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=1000&q=80",
                studio = "Nexus",
                episodes = listOf(
                    Episode(
                        episode = 1,
                        title = "The Chosen Mastermind",
                        description = "Cid trains in secret, preparing to become a shadow eminence. He encounters a mysterious girl and accidentally founds Shadow Garden.",
                        thumbnail = "https://images.unsplash.com/photo-1560942485-b2a11cc13456?w=400&q=80",
                        mp4 = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
                        releaseDate = "2026-06-25",
                        qualities = listOf("1080p", "720p", "480p"),
                        serverLinks = mapOf("Google Drive" to "https://drive.google.com/file/d/1_A2B3C4D5E6F7G8H9I0J/view", "Dailymotion" to "x8m6kvq"),
                        driveLinks = mapOf(
                            "1080p" to "https://drive.google.com/file/d/1_A2B3C4D5E6F7G8H9I0J/view",
                            "720p" to "https://drive.google.com/file/d/1_A2B3C4D5E6F7G8H9I0J/view",
                            "480p" to "https://drive.google.com/file/d/1_A2B3C4D5E6F7G8H9I0J/view"
                        )
                    ),
                    Episode(
                        episode = 2,
                        title = "The Shadow Garden is Born",
                        description = "Years later, Cid is living as an ordinary student, while his Shadow Garden subordinates operate in secret against the Diablos Cult.",
                        thumbnail = "https://images.unsplash.com/photo-1511512578047-dfb367046420?w=400&q=80",
                        mp4 = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4",
                        releaseDate = "2026-07-01",
                        qualities = listOf("1080p", "720p", "480p"),
                        serverLinks = mapOf("Google Drive" to "https://drive.google.com/file/d/1_A2B3C4D5E6F7G8H9I0J/view", "Dailymotion" to "x7tg3f0"),
                        driveLinks = mapOf(
                            "1080p" to "https://drive.google.com/file/d/1_A2B3C4D5E6F7G8H9I0J/view",
                            "720p" to "https://drive.google.com/file/d/1_A2B3C4D5E6F7G8H9I0J/view",
                            "480p" to "https://drive.google.com/file/d/1_A2B3C4D5E6F7G8H9I0J/view"
                        )
                    ),
                    Episode(
                        episode = 3,
                        title = "Faux Ordinary Life",
                        description = "Cid gets caught in a school crisis and must maintain his perfectly average background character status while defending the academy.",
                        thumbnail = "https://images.unsplash.com/photo-1534447677768-be436bb09401?w=400&q=80",
                        mp4 = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4",
                        releaseDate = "2026-07-06",
                        qualities = listOf("1080p", "720p"),
                        serverLinks = mapOf("Google Drive" to "https://drive.google.com/file/d/1_A2B3C4D5E6F7G8H9I0J/view", "Dailymotion" to "x8p7w9z"),
                        driveLinks = mapOf(
                            "1080p" to "https://drive.google.com/file/d/1_A2B3C4D5E6F7G8H9I0J/view",
                            "720p" to "https://drive.google.com/file/d/1_A2B3C4D5E6F7G8H9I0J/view"
                        )
                    )
                )
            ),
            Anime(
                id = "anime_2",
                title = "Chainsaw Man",
                description = "Denji is a teenage boy living with a Chainsaw Devil named Pochita. Due to the debt his father left behind, he has been living a rock-bottom life while repaying his debt by harvesting devil carcasses with Pochita. One day, Denji is betrayed and killed. As his consciousness fades, he makes a contract with Pochita and gets revived as Chainsaw Man.",
                genres = listOf("Action", "Dark Fantasy", "Gore"),
                rating = 8.8,
                status = "Ongoing",
                year = 2022,
                cover = "https://images.unsplash.com/photo-1607604276583-eef5d076aa5f?w=500&q=80",
                banner = "https://images.unsplash.com/photo-1541701494587-cb58502866ab?w=1000&q=80",
                studio = "MAPPA",
                episodes = listOf(
                    Episode(
                        episode = 1,
                        title = "Dog & Chainsaw",
                        description = "Denji lives a miserable life trying to pay off his late father\'s debt. After a deadly betrayal, Pochita merges with him to form Chainsaw Man.",
                        thumbnail = "https://images.unsplash.com/photo-1550745165-9bc0b252726f?w=400&q=80",
                        mp4 = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4",
                        releaseDate = "2026-06-20"
                    ),
                    Episode(
                        episode = 2,
                        title = "Arrival in Tokyo",
                        description = "Denji is taken in by Makima of the Public Safety Devil Hunters and meets his new partner Aki Hayakawa.",
                        thumbnail = "https://images.unsplash.com/photo-1509198397868-475647b2a1e5?w=400&q=80",
                        mp4 = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4",
                        releaseDate = "2026-07-04"
                    )
                )
            ),
            Anime(
                id = "anime_3",
                title = "Frieren: Beyond Journey\'s End",
                description = "Elf mage Frieren and her courageous fellow adventurers have defeated the Demon King and brought peace to the land. But Frieren will long outlive the rest of her former party. How will she come to understand what life means to the humans around her?",
                genres = listOf("Adventure", "Drama", "Fantasy"),
                rating = 9.5,
                status = "Completed",
                year = 2024,
                cover = "https://images.unsplash.com/photo-1534447677768-be436bb09401?w=500&q=80",
                banner = "https://images.unsplash.com/photo-1579783902614-a3fb3927b6a5?w=1000&q=80",
                studio = "Madhouse",
                episodes = listOf(
                    Episode(
                        episode = 1,
                        title = "The Journey\'s End",
                        description = "The party returns victorious from their ten-year quest. Frieren goes on a solitary journey, returning fifty years later to find her friends aged.",
                        thumbnail = "https://images.unsplash.com/photo-1448375240586-882707db888b?w=400&q=80",
                        mp4 = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/SubaruOutback.mp4",
                        releaseDate = "2026-07-02"
                    )
                )
            )
        ),
        manga = listOf(
            Manga(
                id = "manga_1",
                title = "The Eminence in Shadow (Manga)",
                description = "The official manga adaptation of the hit light novel series. Follow Cid Kagenou as he acts out his master shadow-organization fantasy in a brand-new world, completely oblivious to the fact that his fictional Diablos Cult is actually real!",
                cover = "https://images.unsplash.com/photo-1543002588-bfa74002ed7e?w=500&q=80",
                banner = "https://images.unsplash.com/photo-1516979187457-637abb4f9353?w=1000&q=80",
                author = "Daisuke Aizawa",
                status = "Ongoing",
                rating = 9.1,
                genres = listOf("Action", "Comedy", "Fantasy", "Isekai"),
                year = 2019,
                chapters = listOf(
                    Chapter(
                        number = 1,
                        title = "I Want to Be a Shadow Broker!",
                        cover = "https://images.unsplash.com/photo-1543002588-bfa74002ed7e?w=400&q=80",
                        pdf = "https://kagenet.ct.ws/twate1.pdf",
                        releaseDate = "2026-06-20"
                    ),
                    Chapter(
                        number = 2,
                        title = "Starting the Shadow Garden",
                        cover = "https://images.unsplash.com/photo-1516979187457-637abb4f9353?w=400&q=80",
                        pdf = "https://kagenet.ct.ws/twate1.pdf",
                        releaseDate = "2026-07-05"
                    )
                )
            ),
            Manga(
                id = "manga_2",
                title = "Solo Leveling",
                description = "In a world where hunters, humans who possess magical abilities, must battle deadly monsters to protect mankind from certain annihilation, a notoriously weak hunter named Sung Jinwoo finds himself in a struggle for survival. Surviving a double dungeon, Jinwoo awakens as a 'Player' with an active leveling system.",
                cover = "https://images.unsplash.com/photo-1614850523459-c2f4c699c52e?w=500&q=80",
                banner = "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=1000&q=80",
                author = "Chugong",
                status = "Completed",
                rating = 9.4,
                genres = listOf("Action", "Adventure", "Fantasy"),
                year = 2018,
                chapters = listOf(
                    Chapter(
                        number = 1,
                        title = "The Weakest Hunter of All Mankind",
                        cover = "https://images.unsplash.com/photo-1614850523459-c2f4c699c52e?w=400&q=80",
                        pdf = "https://kagenet.ct.ws/twate1.pdf",
                        releaseDate = "2026-06-28"
                    ),
                    Chapter(
                        number = 2,
                        title = "Double Dungeon Disaster",
                        cover = "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=400&q=80",
                        pdf = "https://kagenet.ct.ws/twate1.pdf",
                        releaseDate = "2026-07-06"
                    )
                )
            )
        ),
        featured = listOf("anime_1", "manga_1"),
        trending = listOf("anime_1", "anime_2", "manga_2"),
        latest = listOf("anime_3", "manga_1"),
        notifications = listOf(
            RemoteNotification(
                id = "notif_1",
                title = "Welcome to KageNet!",
                content = "Stream anime and read manga offline in ultra high quality.",
                timestamp = "2026-07-06T08:00:00Z"
            ),
            RemoteNotification(
                id = "notif_2",
                title = "Database Updated",
                content = "Frieren: Beyond Journey\'s End is now streaming on KageNet!",
                timestamp = "2026-07-06T08:15:00Z"
            )
        )
    )
}
