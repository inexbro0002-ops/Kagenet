package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "user_profiles")
data class UserProfile(
    @PrimaryKey val id: String = "local_user",
    val username: String = "KageUser",
    val email: String = "user@kagenet.io",
    val profilePicturePath: String? = null,
    val isLoggedIn: Boolean = false
)

@Entity(tableName = "favorites")
data class Favorite(
    @PrimaryKey val id: String, // composite item_id + "_" + item_type
    val itemId: String,
    val itemType: String // "anime" or "manga"
)

@Entity(tableName = "watch_later")
data class WatchLater(
    @PrimaryKey val animeId: String
)

@Entity(tableName = "reading_lists")
data class ReadingList(
    @PrimaryKey val mangaId: String
)

@Entity(tableName = "continue_watching")
data class ContinueWatching(
    @PrimaryKey val animeId: String,
    val episodeIndex: Int,
    val episodeTitle: String,
    val playbackPosition: Long,
    val duration: Long,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "continue_reading")
data class ContinueReading(
    @PrimaryKey val mangaId: String,
    val chapterIndex: Int,
    val chapterTitle: String,
    val lastPage: Int,
    val totalPages: Int,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "watch_histories")
data class WatchHistory(
    @PrimaryKey val id: String, // animeId + "_" + episodeIndex
    val animeId: String,
    val episodeIndex: Int,
    val episodeTitle: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "reading_histories")
data class ReadingHistory(
    @PrimaryKey val id: String, // mangaId + "_" + chapterIndex
    val mangaId: String,
    val chapterIndex: Int,
    val chapterTitle: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "ratings")
data class Rating(
    @PrimaryKey val id: String, // itemId + "_" + itemType
    val itemId: String,
    val itemType: String, // "anime" or "manga"
    val score: Double
)

@Entity(tableName = "notifications")
data class NotificationEntity(
    @PrimaryKey val id: String,
    val title: String,
    val content: String,
    val timestamp: Long,
    val isRead: Boolean = false
)

@Entity(tableName = "downloads")
data class DownloadItem(
    @PrimaryKey val downloadId: String, // Unique download key
    val fileUrl: String,
    val filePath: String,
    val fileType: String, // "mp4" or "pdf"
    val title: String,
    val sizeBytes: Long = 0L,
    val downloadedBytes: Long = 0L,
    val status: String = "pending", // "pending", "downloading", "paused", "completed", "failed"
    val progress: Int = 0,
    val speedBytesPerSec: Long = 0L,
    val remainingTimeSeconds: Long = 0L,
    val animeId: String? = null,
    val mangaId: String? = null,
    val episodeIndex: Int? = null,
    val chapterIndex: Int? = null
)

@Entity(tableName = "cache_entries")
data class CacheEntry(
    @PrimaryKey val key: String,
    val value: String,
    val lastUpdated: Long = System.currentTimeMillis()
)
