package com.example.download

import android.content.Context
import androidx.work.*
import com.example.data.AppDatabase
import com.example.data.DownloadItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID

class KageDownloadManager(private val context: Context) {

    companion object {
        fun getDownloadFolder(context: Context, fileType: String): File {
            val subDir = if (fileType == "mp4") "kage/kagenet/video" else "kage/kagenet/pdf"
            
            // Try public external storage first
            val extStorage = android.os.Environment.getExternalStorageDirectory()
            if (extStorage != null && android.os.Environment.getExternalStorageState() == android.os.Environment.MEDIA_MOUNTED) {
                val publicDir = File(extStorage, subDir)
                try {
                    if (!publicDir.exists()) {
                        val created = publicDir.mkdirs()
                        if (created || publicDir.exists()) {
                            val testFile = File(publicDir, ".test_write")
                            if (testFile.createNewFile()) {
                                testFile.delete()
                                return publicDir
                            }
                        }
                    } else if (publicDir.canWrite()) {
                        return publicDir
                    }
                } catch (e: Exception) {
                    // Ignore and fall back
                }
            }
            
            // Fallback 1: Public Downloads folder (fully accessible to users & writable on modern Android)
            val downloadsPublicDir = android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DOWNLOADS)
            if (downloadsPublicDir != null && android.os.Environment.getExternalStorageState() == android.os.Environment.MEDIA_MOUNTED) {
                val publicDir = File(downloadsPublicDir, subDir)
                try {
                    if (!publicDir.exists()) {
                        publicDir.mkdirs()
                    }
                    val testFile = File(publicDir, ".test_write")
                    if (testFile.createNewFile()) {
                        testFile.delete()
                        return publicDir
                    }
                } catch (e: Exception) {
                    // Ignore and fall back
                }
            }

            // Fallback 2: App's external files directory (which is in local storage and accessible by user via file managers)
            val extFilesDir = context.getExternalFilesDir(null)
            if (extFilesDir != null) {
                val appExtDir = File(extFilesDir, subDir)
                if (!appExtDir.exists()) {
                    appExtDir.mkdirs()
                }
                return appExtDir
            }
            
            // Fallback 3: Internal files directory
            val internalDir = File(context.filesDir, subDir)
            if (!internalDir.exists()) {
                internalDir.mkdirs()
            }
            return internalDir
        }
    }

    private val db = AppDatabase.getDatabase(context)
    private val workManager = WorkManager.getInstance(context)

    suspend fun enqueueDownload(
        id: String,
        url: String,
        title: String,
        fileType: String, // "mp4" or "pdf"
        animeId: String? = null,
        mangaId: String? = null,
        episodeIndex: Int? = null,
        chapterIndex: Int? = null
    ) = withContext(Dispatchers.IO) {
        val extension = if (fileType == "mp4") "mp4" else "pdf"
        val downloadsDir = getDownloadFolder(context, fileType)
        val targetFile = File(downloadsDir, "${id}.${extension}")
        
        // Check if already completed or downloading
        val existing = db.downloadDao().getById(id)
        if (existing != null && existing.status == "completed") {
            return@withContext
        }

        val newItem = DownloadItem(
            downloadId = id,
            fileUrl = url,
            filePath = targetFile.absolutePath,
            fileType = fileType,
            title = title,
            status = "pending",
            animeId = animeId,
            mangaId = mangaId,
            episodeIndex = episodeIndex,
            chapterIndex = chapterIndex
        )
        db.downloadDao().insert(newItem)

        triggerWorker(id)
    }

    suspend fun pauseDownload(downloadId: String) = withContext(Dispatchers.IO) {
        db.downloadDao().updateStatus(downloadId, "paused")
        workManager.cancelAllWorkByTag(downloadId)
    }

    suspend fun resumeDownload(downloadId: String) = withContext(Dispatchers.IO) {
        val item = db.downloadDao().getById(downloadId) ?: return@withContext
        db.downloadDao().insert(item.copy(status = "pending"))
        triggerWorker(downloadId)
    }

    suspend fun cancelDownload(downloadId: String) = withContext(Dispatchers.IO) {
        workManager.cancelAllWorkByTag(downloadId)
        val item = db.downloadDao().getById(downloadId)
        if (item != null) {
            val file = File(item.filePath)
            if (file.exists()) {
                file.delete()
            }
            db.downloadDao().delete(downloadId)
        }
    }

    suspend fun deleteDownload(downloadId: String) = withContext(Dispatchers.IO) {
        cancelDownload(downloadId)
    }

    private fun triggerWorker(downloadId: String) {
        val constraints = Constraints.Builder()
            .setRequiredNetworkType(NetworkType.CONNECTED)
            .build()

        val data = Data.Builder()
            .putString("DOWNLOAD_ID", downloadId)
            .build()

        val workRequest = OneTimeWorkRequestBuilder<DownloadWorker>()
            .setConstraints(constraints)
            .setInputData(data)
            .addTag(downloadId)
            .addTag("KageNetDownload")
            .setBackoffCriteria(
                BackoffPolicy.LINEAR,
                WorkRequest.MIN_BACKOFF_MILLIS,
                java.util.concurrent.TimeUnit.MILLISECONDS
            )
            .build()

        workManager.enqueueUniqueWork(
            downloadId,
            ExistingWorkPolicy.REPLACE,
            workRequest
        )
    }
}
