package com.example.download

import android.content.Context
import android.util.Log
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.example.data.AppDatabase
import com.example.data.DownloadItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.RandomAccessFile

class DownloadWorker(
    context: Context,
    workerParams: WorkerParameters
) : CoroutineWorker(context, workerParams) {

    private val db = AppDatabase.getDatabase(context)
    private val client = OkHttpClient.Builder().build()

    private fun extractGoogleDriveId(url: String): String? {
        val regexes = listOf(
            Regex("drive\\.google\\.com/file/d/([a-zA-Z0-9_-]+)"),
            Regex("drive\\.google\\.com/open\\?id=([a-zA-Z0-9_-]+)"),
            Regex("drive\\.google\\.com/uc\\?id=([a-zA-Z0-9_-]+)"),
            Regex("id=([a-zA-Z0-9_-]+)")
        )
        for (regex in regexes) {
            val match = regex.find(url)
            if (match != null) {
                return match.groupValues[1]
            }
        }
        if (url.length in 25..45 && url.matches(Regex("^[a-zA-Z0-9_-]+$"))) {
            return url
        }
        return null
    }

    private fun getGoogleDriveDirectLink(driveId: String, client: OkHttpClient): String {
        val initialUrl = "https://drive.google.com/uc?export=download&id=$driveId"
        try {
            val request = Request.Builder().url(initialUrl).build()
            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val bodyString = response.body?.string() ?: ""
                    val confirmRegex = Regex("confirm=([a-zA-Z0-9_]+)")
                    val match = confirmRegex.find(bodyString)
                    if (match != null) {
                        val token = match.groupValues[1]
                        return "https://drive.google.com/uc?export=download&confirm=$token&id=$driveId"
                    }
                }
            }
        } catch (e: Exception) {
            Log.e("DownloadWorker", "Error getting Drive confirm token: ${e.message}")
        }
        return initialUrl
    }

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        val downloadId = inputData.getString("DOWNLOAD_ID") ?: return@withContext Result.failure()
        
        Log.d("DownloadWorker", "Starting download work for id: $downloadId")
        
        var item = db.downloadDao().getById(downloadId)
        if (item == null) {
            Log.e("DownloadWorker", "No DownloadItem found in database for id: $downloadId")
            return@withContext Result.failure()
        }

        if (item.status == "completed") {
            return@withContext Result.success()
        }

        db.downloadDao().updateStatus(downloadId, "downloading")

        val targetFile = File(item.filePath)
        val fileDir = targetFile.parentFile
        if (fileDir != null && !fileDir.exists()) {
            fileDir.mkdirs()
        }

        var downloadedBytes = 0L
        if (targetFile.exists() && item.status == "paused") {
            downloadedBytes = targetFile.length()
        } else if (!targetFile.exists()) {
            targetFile.createNewFile()
        }

        Log.d("DownloadWorker", "File destination: ${targetFile.absolutePath}, resuming from: $downloadedBytes")

        // Resolve Google Drive URLs before executing down requests
        var resolvedUrl = item.fileUrl
        val driveId = extractGoogleDriveId(resolvedUrl)
        if (driveId != null) {
            resolvedUrl = getGoogleDriveDirectLink(driveId, client)
            Log.d("DownloadWorker", "Resolved Google Drive direct download link: $resolvedUrl")
        }

        try {
            val requestBuilder = Request.Builder()
                .url(resolvedUrl)
            
            if (downloadedBytes > 0) {
                requestBuilder.header("Range", "bytes=$downloadedBytes-")
            }
            
            val request = requestBuilder.build()
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful && response.code != 206) {
                    Log.e("DownloadWorker", "Server returned failure code: ${response.code}")
                    db.downloadDao().updateStatus(downloadId, "failed")
                    return@withContext Result.retry()
                }

                val body = response.body
                if (body == null) {
                    Log.e("DownloadWorker", "Response body is null")
                    db.downloadDao().updateStatus(downloadId, "failed")
                    return@withContext Result.failure()
                }

                val contentLength = body.contentLength()
                val totalBytes = if (response.code == 206) {
                    downloadedBytes + contentLength
                } else {
                    contentLength
                }

                db.downloadDao().insert(item.copy(sizeBytes = totalBytes, status = "downloading"))

                val inputStream = body.byteStream()
                val outputStream = RandomAccessFile(targetFile, "rw")
                if (response.code == 206) {
                    outputStream.seek(downloadedBytes)
                } else {
                    outputStream.setLength(0) // Overwrite if server didn't support partial range
                    downloadedBytes = 0
                }

                val buffer = ByteArray(8192)
                var bytesRead: Int
                var lastUpdateTime = System.currentTimeMillis()
                var bytesDownloadedInInterval = 0L
                var currentProgress = 0

                while (inputStream.read(buffer).also { bytesRead = it } != -1) {
                    // Check if paused or stopped
                    val liveItem = db.downloadDao().getById(downloadId)
                    if (isStopped || (liveItem != null && liveItem.status == "paused")) {
                        Log.d("DownloadWorker", "Download stopped or paused by user action")
                        outputStream.close()
                        inputStream.close()
                        if (liveItem?.status != "paused") {
                            db.downloadDao().updateStatus(downloadId, "paused")
                        }
                        return@withContext Result.success() // Saved state
                    }

                    outputStream.write(buffer, 0, bytesRead)
                    downloadedBytes += bytesRead
                    bytesDownloadedInInterval += bytesRead

                    val now = System.currentTimeMillis()
                    val timeDiff = now - lastUpdateTime
                    if (timeDiff >= 1000L || downloadedBytes == totalBytes) {
                        val progress = if (totalBytes > 0) ((downloadedBytes * 100) / totalBytes).toInt() else 0
                        val speed = if (timeDiff > 0) (bytesDownloadedInInterval * 1000) / timeDiff else 0L
                        val remaining = if (speed > 0) (totalBytes - downloadedBytes) / speed else 0L

                        db.downloadDao().updateProgress(
                            downloadId = downloadId,
                            downloadedBytes = downloadedBytes,
                            speed = speed,
                            remaining = remaining,
                            progress = progress,
                            status = "downloading"
                        )

                        lastUpdateTime = now
                        bytesDownloadedInInterval = 0L
                        currentProgress = progress
                    }
                }

                outputStream.close()
                inputStream.close()

                db.downloadDao().insert(
                    item.copy(
                        downloadedBytes = totalBytes,
                        sizeBytes = totalBytes,
                        status = "completed",
                        progress = 100,
                        speedBytesPerSec = 0,
                        remainingTimeSeconds = 0
                    )
                )
                Log.d("DownloadWorker", "Successfully finished downloading file: ${item.title}")
                Result.success()
            }
        } catch (e: Exception) {
            Log.e("DownloadWorker", "Error while downloading", e)
            val liveItem = db.downloadDao().getById(downloadId)
            if (liveItem != null && liveItem.status != "paused") {
                db.downloadDao().updateStatus(downloadId, "failed")
            }
            Result.retry()
        }
    }
}
