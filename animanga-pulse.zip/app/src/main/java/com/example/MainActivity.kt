package com.example

import android.os.Bundle
import android.content.Intent
import android.net.Uri
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.*
import androidx.navigation.navArgument
import androidx.navigation.navDeepLink
import com.example.ui.KageViewModel
import com.example.ui.screens.*
import com.example.ui.theme.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
            requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 101)
        }
        setContent {
            val viewModel: KageViewModel = viewModel()
            val darkThemeState by viewModel.darkThemeState.collectAsStateWithLifecycle()
            MyApplicationTheme(darkTheme = darkThemeState) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = if (darkThemeState) KageDeepAbyss else KageDarkSpace
                ) {
                    KageAppNavigator(viewModel = viewModel)
                }
            }
        }
    }
}

@Composable
fun KageAppNavigator(viewModel: KageViewModel) {
    val navController = rememberNavController()
    val profile by viewModel.profileState.collectAsStateWithLifecycle()
    val isProfileLoaded by viewModel.isProfileLoaded.collectAsStateWithLifecycle()

    if (!isProfileLoaded) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(KageDeepAbyss),
            contentAlignment = Alignment.Center
        ) {
            CircularProgressIndicator(color = KageNeonBlue)
        }
    } else {
        val isLoggedIn = profile?.isLoggedIn == true

        LaunchedEffect(isLoggedIn) {
            if (isLoggedIn) {
                navController.navigate("tabs") {
                    popUpTo("login") { inclusive = true }
                }
            } else {
                navController.navigate("login") {
                    popUpTo(0) { inclusive = true }
                }
            }
        }

        NavHost(
            navController = navController,
            startDestination = if (isLoggedIn) "tabs" else "login"
        ) {
            // Fullscreen Login/Register Screen Onboarding
            composable("login") {
                LoginScreen(
                    viewModel = viewModel,
                    onLoginSuccess = {
                        // Reactive navigation handled by LaunchedEffect
                    }
                )
            }

            // Main Tabs Container Route
            composable("tabs") {
                MainTabsContainer(
                    viewModel = viewModel,
                    onNavigateToAnime = { animeId -> navController.navigate("anime_details/$animeId") },
                    onNavigateToManga = { mangaId -> navController.navigate("manga_details/$mangaId") },
                    onNavigateToPlayer = { id, epIdx, offline -> navController.navigate("player/$id/$epIdx?offline=$offline") },
                    onNavigateToReader = { id, chapIdx -> navController.navigate("reader/$id/$chapIdx") },
                    onNavigateToNotifications = { navController.navigate("notifications") },
                    onNavigateToStorageManager = { navController.navigate("storage_manager") },
                    onNavigateToSettings = { navController.navigate("settings") }
                )
            }

        // Fullscreen Sub-Routes
        composable(
            route = "anime_details/{animeId}",
            arguments = listOf(navArgument("animeId") { type = NavType.StringType }),
            deepLinks = listOf(
                navDeepLink { uriPattern = "https://kagenet.com/anime/{animeId}" },
                navDeepLink { uriPattern = "kagenet://anime/{animeId}" }
            )
        ) { backStackEntry ->
            val animeId = backStackEntry.arguments?.getString("animeId") ?: ""
            AnimeDetailsScreen(
                animeId = animeId,
                viewModel = viewModel,
                onNavigateBack = { navController.popBackStack() },
                onNavigateToPlayer = { id, epIdx, offline -> navController.navigate("player/$id/$epIdx?offline=$offline") },
                onNavigateToRelatedAnime = { id -> navController.navigate("anime_details/$id") }
            )
        }

        composable(
            route = "player/{animeId}/{episodeIndex}?offline={offline}",
            arguments = listOf(
                navArgument("animeId") { type = NavType.StringType },
                navArgument("episodeIndex") { type = NavType.IntType },
                navArgument("offline") {
                    type = NavType.BoolType
                    defaultValue = false
                }
            )
        ) { backStackEntry ->
            val animeId = backStackEntry.arguments?.getString("animeId") ?: ""
            val episodeIndex = backStackEntry.arguments?.getInt("episodeIndex") ?: 0
            val playOffline = backStackEntry.arguments?.getBoolean("offline") ?: false
            PlayerScreen(
                animeId = animeId,
                episodeIndex = episodeIndex,
                viewModel = viewModel,
                playOffline = playOffline,
                onNavigateBack = { navController.popBackStack() }
            )
        }

        composable(
            route = "manga_details/{mangaId}",
            arguments = listOf(navArgument("mangaId") { type = NavType.StringType }),
            deepLinks = listOf(
                navDeepLink { uriPattern = "https://kagenet.com/manga/{mangaId}" },
                navDeepLink { uriPattern = "kagenet://manga/{mangaId}" }
            )
        ) { backStackEntry ->
            val mangaId = backStackEntry.arguments?.getString("mangaId") ?: ""
            MangaDetailsScreen(
                mangaId = mangaId,
                viewModel = viewModel,
                onNavigateBack = { navController.popBackStack() },
                onNavigateToReader = { id, chapIdx -> navController.navigate("reader/$id/$chapIdx") },
                onNavigateToRelatedManga = { id -> navController.navigate("manga_details/$id") }
            )
        }

        composable(
            route = "reader/{mangaId}/{chapterIndex}",
            arguments = listOf(
                navArgument("mangaId") { type = NavType.StringType },
                navArgument("chapterIndex") { type = NavType.IntType }
            )
        ) { backStackEntry ->
            val mangaId = backStackEntry.arguments?.getString("mangaId") ?: ""
            val chapterIndex = backStackEntry.arguments?.getInt("chapterIndex") ?: 0
            ReaderScreen(
                mangaId = mangaId,
                chapterIndex = chapterIndex,
                viewModel = viewModel,
                onNavigateBack = { navController.popBackStack() }
            )
        }

        composable("storage_manager") {
            StorageScreen(
                viewModel = viewModel,
                onNavigateBack = { navController.popBackStack() }
            )
        }

        composable("notifications") {
            NotificationScreen(
                viewModel = viewModel,
                onNavigateBack = { navController.popBackStack() }
            )
        }

        composable("settings") {
            SettingsScreen(
                viewModel = viewModel,
                onNavigateToStorageManager = { navController.navigate("storage_manager") }
            )
        }
    }
    }
}

@Composable
fun MainTabsContainer(
    viewModel: KageViewModel,
    onNavigateToAnime: (String) -> Unit,
    onNavigateToManga: (String) -> Unit,
    onNavigateToPlayer: (String, Int, Boolean) -> Unit,
    onNavigateToReader: (String, Int) -> Unit,
    onNavigateToNotifications: () -> Unit,
    onNavigateToStorageManager: () -> Unit,
    onNavigateToSettings: () -> Unit
) {
    var activeTab by remember { mutableStateOf("home") }
    val unreadNotifsCount by viewModel.unreadNotificationsCount.collectAsStateWithLifecycle()

    Scaffold(
        bottomBar = {
            NavigationBar(
                containerColor = KageDeepAbyss,
                modifier = Modifier
                    .fillMaxWidth()
                    .border(BorderStroke(0.5.dp, Color(0x1AFFFFFF)), RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp))
                    .clip(RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp)),
                tonalElevation = 8.dp
            ) {
                // Tab 1: Home
                NavigationBarItem(
                    selected = activeTab == "home",
                    onClick = { activeTab = "home" },
                    icon = { Icon(Icons.Filled.Home, contentDescription = "Home") },
                    label = { Text("Home", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = MaterialTheme.colorScheme.primary,
                        selectedTextColor = MaterialTheme.colorScheme.primary,
                        indicatorColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.2f),
                        unselectedIconColor = KageGray,
                        unselectedTextColor = KageGray
                    ),
                    modifier = Modifier.testTag("nav_tab_home")
                )

                // Tab 2: Search
                NavigationBarItem(
                    selected = activeTab == "search",
                    onClick = { activeTab = "search" },
                    icon = { Icon(Icons.Filled.Search, contentDescription = "Search") },
                    label = { Text("Search", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = MaterialTheme.colorScheme.primary,
                        selectedTextColor = MaterialTheme.colorScheme.primary,
                        indicatorColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.2f),
                        unselectedIconColor = KageGray,
                        unselectedTextColor = KageGray
                    ),
                    modifier = Modifier.testTag("nav_tab_search")
                )

                // Tab 3: Library
                NavigationBarItem(
                    selected = activeTab == "library",
                    onClick = { activeTab = "library" },
                    icon = { Icon(Icons.Filled.VideoLibrary, contentDescription = "Library") },
                    label = { Text("Library", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = MaterialTheme.colorScheme.primary,
                        selectedTextColor = MaterialTheme.colorScheme.primary,
                        indicatorColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.2f),
                        unselectedIconColor = KageGray,
                        unselectedTextColor = KageGray
                    ),
                    modifier = Modifier.testTag("nav_tab_library")
                )

                // Tab 4: Profile
                NavigationBarItem(
                    selected = activeTab == "profile",
                    onClick = { activeTab = "profile" },
                    icon = { Icon(Icons.Filled.AccountCircle, contentDescription = "Profile") },
                    label = { Text("Profile", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = MaterialTheme.colorScheme.primary,
                        selectedTextColor = MaterialTheme.colorScheme.primary,
                        indicatorColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.2f),
                        unselectedIconColor = KageGray,
                        unselectedTextColor = KageGray
                    ),
                    modifier = Modifier.testTag("nav_tab_profile")
                )
            }
        },
        containerColor = KageDeepAbyss
    ) { innerPadding ->
        Box(modifier = Modifier.padding(innerPadding)) {
            when (activeTab) {
                "home" -> HomeScreen(
                    viewModel = viewModel,
                    onNavigateToAnime = onNavigateToAnime,
                    onNavigateToManga = onNavigateToManga,
                    onNavigateToPlayer = onNavigateToPlayer,
                    onNavigateToReader = onNavigateToReader,
                    onNavigateToNotifications = onNavigateToNotifications,
                    onSearchTabClick = { activeTab = "search" },
                    onProfileTabClick = { activeTab = "profile" }
                )
                "search" -> SearchScreen(
                    viewModel = viewModel,
                    onNavigateToAnime = onNavigateToAnime,
                    onNavigateToManga = onNavigateToManga
                )
                "library" -> LibraryScreen(
                    viewModel = viewModel,
                    onNavigateToAnime = onNavigateToAnime,
                    onNavigateToManga = onNavigateToManga,
                    onNavigateToPlayer = onNavigateToPlayer,
                    onNavigateToReader = onNavigateToReader
                )
                "profile" -> ProfileScreen(
                    viewModel = viewModel,
                    onNavigateToStorageManager = onNavigateToStorageManager,
                    onNavigateToSettings = onNavigateToSettings
                )
            }
        }
    }
}
